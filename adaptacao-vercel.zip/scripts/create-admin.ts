// Cria (ou atualiza) um administrador com e-mail e senha no banco atual.
// Uso: DATABASE_URL="..." npx tsx scripts/create-admin.ts "email@dominio.com" "Nome" "SenhaForte123"
import "dotenv/config";
import { eq } from "drizzle-orm";
import { passwordCredentials, users } from "../drizzle/schema";
import { getDb, getUserByOpenId, upsertUser } from "../server/db";
import { hashPassword } from "../server/passwordAuth";

const [emailArg, name, password] = process.argv.slice(2);
if (!emailArg || !name || !password) {
  console.error('Uso: npx tsx scripts/create-admin.ts "email" "Nome" "Senha (mín. 8 caracteres)"');
  process.exit(1);
}

const email = emailArg.trim().toLowerCase();
const db = await getDb();
if (!db) {
  console.error("DATABASE_URL não configurada ou banco indisponível.");
  process.exit(1);
}

let user = (await db.select().from(users).where(eq(users.email, email)).limit(1))[0];
if (!user) {
  const openId = `local:${email}`;
  await upsertUser({ openId, name, email, loginMethod: "password", role: "admin", lastSignedIn: new Date() });
  user = await getUserByOpenId(openId);
} else {
  await db.update(users).set({ role: "admin" }).where(eq(users.id, user.id));
}
if (!user) {
  console.error("Não foi possível criar o usuário.");
  process.exit(1);
}

const passwordHash = await hashPassword(password);
await db.insert(passwordCredentials).values({ userId: user.id, passwordHash }).onDuplicateKeyUpdate({ set: { passwordHash } });
console.log(`Administrador pronto: ${email}`);
process.exit(0);
