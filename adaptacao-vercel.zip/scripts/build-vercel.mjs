// Build para o Vercel usando a "Build Output API":
//  - frontend (Vite)  -> .vercel/output/static
//  - API (Express/tRPC) empacotada com esbuild -> .vercel/output/functions/api.func
import { build } from "esbuild";
import { execSync } from "node:child_process";
import { cpSync, mkdirSync, rmSync, writeFileSync } from "node:fs";

const out = ".vercel/output";
rmSync(out, { recursive: true, force: true });

// 1) Frontend
execSync("npx vite build", { stdio: "inherit" });
mkdirSync(`${out}/static`, { recursive: true });
cpSync("dist/public", `${out}/static`, { recursive: true });

// 2) API como função serverless (tudo empacotado em um único arquivo)
const fn = `${out}/functions/api.func`;
mkdirSync(fn, { recursive: true });
await build({
  entryPoints: ["server/vercel.ts"],
  bundle: true,
  platform: "node",
  target: "node22",
  format: "cjs",
  outfile: `${fn}/index.js`,
  tsconfig: "tsconfig.json",
  footer: { js: "module.exports = module.exports.default || module.exports;" },
  logLevel: "info",
});
writeFileSync(`${fn}/package.json`, JSON.stringify({ type: "commonjs" }));
writeFileSync(
  `${fn}/.vc-config.json`,
  JSON.stringify({ runtime: "nodejs22.x", handler: "index.js", launcherType: "Nodejs", maxDuration: 30 })
);

// 3) Rotas: /api/* e /manus-storage/* vão para a função; o resto é o site (SPA)
writeFileSync(
  `${out}/config.json`,
  JSON.stringify({
    version: 3,
    routes: [
      { src: "/api/(.*)", dest: "/api" },
      { handle: "filesystem" },
      { src: "/manus-storage/(.*)", dest: "/api" },
      { src: "/(.*)", dest: "/index.html" },
    ],
  })
);
console.log("Build do Vercel concluído em .vercel/output");
