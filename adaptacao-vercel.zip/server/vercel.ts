import { createApp } from "./app";

// Função serverless do Vercel: exporta o app Express sem chamar listen().
export default createApp();
