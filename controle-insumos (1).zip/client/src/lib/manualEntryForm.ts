export type ManualEntryItemDraft = { materialId: string; quantity: string; unitPrice: string };

export type ManualEntryDraft = {
  supplierId: string;
  entryDate: string;
  reference: string;
  invoiceNumber: string;
  company: string;
  notes: string;
  items: ManualEntryItemDraft[];
};

export function blankManualEntryDraft(): ManualEntryDraft {
  return {
    supplierId: "",
    entryDate: new Date().toISOString().slice(0, 10),
    reference: "",
    invoiceNumber: "",
    company: "",
    notes: "",
    items: [{ materialId: "", quantity: "", unitPrice: "" }],
  };
}

export function manualEntryTotal(items: ManualEntryItemDraft[]) {
  return items.reduce((sum, item) => sum + (Number(item.quantity) || 0) * (Number(item.unitPrice) || 0), 0);
}

export function prepareManualEntrySubmission(entry: ManualEntryDraft) {
  const supplierId = Number(entry.supplierId);
  const entryDate = new Date(`${entry.entryDate}T12:00:00`);
  const items = entry.items.map(item => ({ materialId: Number(item.materialId), quantity: Number(item.quantity), unitPrice: Number(item.unitPrice) }));
  if (!Number.isInteger(supplierId) || supplierId <= 0) return { error: "Selecione o fornecedor." } as const;
  if (!entry.entryDate || Number.isNaN(entryDate.getTime())) return { error: "Informe uma data de entrada válida." } as const;
  if (items.length === 0 || items.some(item => !Number.isInteger(item.materialId) || item.materialId <= 0 || !Number.isFinite(item.quantity) || item.quantity <= 0 || !Number.isFinite(item.unitPrice) || item.unitPrice < 0)) return { error: "Preencha SKU, quantidade e custo unitário de todos os itens." } as const;
  if (new Set(items.map(item => item.materialId)).size !== items.length) return { error: "Não repita o mesmo insumo no pedido." } as const;
  return {
    data: {
      supplierId,
      entryDate,
      reference: entry.reference || null,
      invoiceNumber: entry.invoiceNumber || null,
      company: entry.company || null,
      notes: entry.notes || null,
      items,
    },
  } as const;
}
