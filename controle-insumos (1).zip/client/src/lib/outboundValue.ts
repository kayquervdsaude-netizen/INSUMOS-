export type OutboundValueItem = {
  requestedQuantity: string | number;
  pickedQuantity?: string | number;
  unitCost: string | number;
};

export function outboundLineValue(quantity: string | number, unitCost: string | number) {
  return Number(quantity) * Number(unitCost);
}

export function outboundOrderValue(items: OutboundValueItem[], quantity: "requested" | "picked" = "requested") {
  return items.reduce((total, item) => total + outboundLineValue(quantity === "picked" ? item.pickedQuantity ?? 0 : item.requestedQuantity, item.unitCost), 0);
}
