import { describe, expect, it } from "vitest";
import { manualEntryTotal, prepareManualEntrySubmission, type ManualEntryDraft } from "./manualEntryForm";

const completeDraft: ManualEntryDraft = {
  supplierId: "4",
  entryDate: "2026-08-26",
  reference: "REC-0028",
  invoiceNumber: "NF-351",
  company: "RVD Saúde",
  notes: "Recebimento conferido.",
  items: [{ materialId: "12", quantity: "2", unitPrice: "7.5" }],
};

describe("formulário de entrada manual", () => {
  it("prepara um envio válido com a data preservada ao meio-dia local", () => {
    const result = prepareManualEntrySubmission(completeDraft);
    expect(result).toHaveProperty("data");
    if ("data" in result) {
      expect(result.data).toMatchObject({ supplierId: 4, reference: "REC-0028", invoiceNumber: "NF-351", items: [{ materialId: 12, quantity: 2, unitPrice: 7.5 }] });
      expect(result.data.entryDate.getHours()).toBe(12);
    }
    expect(manualEntryTotal(completeDraft.items)).toBe(15);
  });

  it("impede envio sem fornecedor, item completo ou com SKU duplicado", () => {
    expect(prepareManualEntrySubmission({ ...completeDraft, supplierId: "" })).toEqual({ error: "Selecione o fornecedor." });
    expect(prepareManualEntrySubmission({ ...completeDraft, items: [{ materialId: "", quantity: "2", unitPrice: "7.5" }] })).toEqual({ error: "Preencha SKU, quantidade e custo unitário de todos os itens." });
    expect(prepareManualEntrySubmission({ ...completeDraft, items: [...completeDraft.items, { materialId: "12", quantity: "1", unitPrice: "3" }] })).toEqual({ error: "Não repita o mesmo insumo no pedido." });
  });
});
