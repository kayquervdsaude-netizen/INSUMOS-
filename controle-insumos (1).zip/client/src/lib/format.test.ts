import { describe, expect, it } from "vitest";
import { formatDateTime } from "./format";

describe("formatação de data e hora", () => {
  it("exibe data e horário completos em UTC", () => {
    expect(formatDateTime("2026-09-22T15:30:45.000Z")).toBe("22/09/2026, 15:30:45");
  });

  it("retorna marcador para data ausente", () => {
    expect(formatDateTime(null)).toBe("—");
  });
});
