import { describe, expect, it } from "vitest";
import { getSafeRedirectPath, loginPathFor } from "./routeGuard";

describe("proteção de rotas privadas", () => {
  it("mantém um destino interno válido após o login", () => {
    expect(getSafeRedirectPath("/pedidos-saida?pedido=7")).toBe("/pedidos-saida?pedido=7");
    expect(loginPathFor("/solicitacoes")).toBe("/login?next=%2Fsolicitacoes");
  });

  it("impede redirecionamentos externos ou malformados", () => {
    expect(getSafeRedirectPath("https://exemplo.com")).toBe("/");
    expect(getSafeRedirectPath("//exemplo.com")).toBe("/");
    expect(getSafeRedirectPath(null)).toBe("/");
  });
});
