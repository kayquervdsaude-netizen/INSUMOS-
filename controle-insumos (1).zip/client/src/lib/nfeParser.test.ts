import { DOMParser } from "@xmldom/xmldom";
import { describe, expect, it } from "vitest";
import { findExactMaterialId, parseNfeXml } from "./nfeParser";

globalThis.DOMParser = DOMParser as unknown as typeof globalThis.DOMParser;

describe("parseNfeXml", () => {
  it("extrai emitente, número, chave, valores e itens da NF-e", () => {
    const invoice = parseNfeXml(`<?xml version="1.0" encoding="UTF-8"?>
      <nfeProc><NFe><infNFe Id="NFe35260112345678000123550010000001231000000012">
        <ide><nNF>123</nNF><dhEmi>2026-08-25T10:15:00-03:00</dhEmi></ide>
        <emit><CNPJ>12345678000123</CNPJ><xNome>Fornecedor de Teste LTDA</xNome></emit>
        <det nItem="1"><prod><cProd>REF-001</cProd><xProd>GELOX 500</xProd><NCM>38249989</NCM><uCom>UND</uCom><qCom>10.0000</qCom><vUnCom>1.83</vUnCom><vProd>18.30</vProd></prod></det>
        <total><ICMSTot><vNF>18.30</vNF></ICMSTot></total>
      </infNFe></NFe></nfeProc>`);

    expect(invoice.number).toBe("123");
    expect(invoice.issuerName).toBe("Fornecedor de Teste LTDA");
    expect(invoice.issuerDocument).toBe("12345678000123");
    expect(invoice.accessKey).toBe("35260112345678000123550010000001231000000012");
    expect(invoice.totalAmount).toBe(18.3);
    expect(invoice.items).toEqual([
      expect.objectContaining({
        sourceCode: "REF-001",
        description: "GELOX 500",
        quantity: 10,
        unitPrice: 1.83,
        totalPrice: 18.3,
      }),
    ]);
  });

  it("vincula descrições equivalentes do XML a um insumo cadastrado", () => {
    expect(findExactMaterialId("CAIXA-1 (LLT)", [{ id: 18, name: "Caixa 1 LLT" }])).toBe(18);
    expect(findExactMaterialId("Produto sem cadastro", [{ id: 18, name: "Caixa 1 LLT" }])).toBeNull();
  });
});
