import { describe, expect, it } from "vitest";
import { outboundLineValue, outboundOrderValue } from "./outboundValue";

describe("valores dos pedidos de saída", () => {
  const items = [
    { requestedQuantity: "40.000", pickedQuantity: "38.000", unitCost: "3.50" },
    { requestedQuantity: 2, pickedQuantity: 2, unitCost: 10 },
  ];

  it("calcula o valor de cada item", () => {
    expect(outboundLineValue("40.000", "3.50")).toBe(140);
  });

  it("calcula valor solicitado e valor efetivamente expedido", () => {
    expect(outboundOrderValue(items)).toBe(160);
    expect(outboundOrderValue(items, "picked")).toBe(153);
  });
});
