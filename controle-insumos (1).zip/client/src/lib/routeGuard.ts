export function getSafeRedirectPath(value: string | null | undefined) {
  if (!value || !value.startsWith("/") || value.startsWith("//") || value.startsWith("/\\")) return "/";
  return value;
}

export function loginPathFor(destination: string) {
  return `/login?next=${encodeURIComponent(getSafeRedirectPath(destination))}`;
}
