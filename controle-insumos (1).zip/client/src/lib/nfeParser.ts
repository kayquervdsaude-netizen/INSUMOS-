export type ParsedNfeItem = {
  sourceCode: string | null;
  description: string;
  ncm: string | null;
  unit: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  materialId: number | null;
};

export type ParsedNfe = {
  number: string;
  accessKey: string | null;
  issuerName: string;
  issuerDocument: string | null;
  issueDate: Date | null;
  totalAmount: number;
  items: ParsedNfeItem[];
};

function childText(parent: Element | null | undefined, tagName: string) {
  if (!parent) return null;
  const child = Array.from(parent.children).find(child => child.localName === tagName || child.nodeName === tagName);
  return child?.textContent?.trim() || null;
}

function directChild(parent: Element | null | undefined, tagName: string) {
  if (!parent) return null;
  return Array.from(parent.children).find(child => child.localName === tagName || child.nodeName === tagName) ?? null;
}

function asNumber(value: string | null) {
  const amount = Number(value?.replace(",", ".") ?? 0);
  return Number.isFinite(amount) ? amount : 0;
}

function parseIssueDate(value: string | null) {
  if (!value) return null;
  const normalized = value.length === 10 ? `${value}T00:00:00` : value;
  const date = new Date(normalized);
  return Number.isNaN(date.valueOf()) ? null : date;
}

export function normalizeMaterialName(value: string) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/[^A-Z0-9]+/g, " ").trim();
}

export function findExactMaterialId(description: string, materials: Array<{ id: number; name: string }>) {
  return materials.find(material => normalizeMaterialName(material.name) === normalizeMaterialName(description))?.id ?? null;
}

export function parseNfeXml(xmlText: string): ParsedNfe {
  const document = new DOMParser().parseFromString(xmlText, "application/xml");
  if (document.getElementsByTagName("parsererror").length > 0) throw new Error("O arquivo não contém um XML de NF-e válido.");

  const infNfe = Array.from(document.getElementsByTagName("infNFe"))[0];
  if (!infNfe) throw new Error("Não foi encontrado o bloco principal da NF-e no XML.");
  const ide = directChild(infNfe, "ide");
  const issuer = directChild(infNfe, "emit");
  const total = directChild(directChild(infNfe, "total"), "ICMSTot");
  const accessKey = infNfe.getAttribute("Id")?.replace(/^NFe/, "") ?? null;
  const detNodes = Array.from(infNfe.children).filter(child => child.localName === "det" || child.nodeName === "det");
  const items = detNodes.map(det => {
    const product = directChild(det, "prod");
    const quantity = asNumber(childText(product, "qCom"));
    const unitPrice = asNumber(childText(product, "vUnCom"));
    return {
      sourceCode: childText(product, "cProd"),
      description: childText(product, "xProd") ?? "Item sem descrição",
      ncm: childText(product, "NCM"),
      unit: childText(product, "uCom") ?? "Und",
      quantity,
      unitPrice,
      totalPrice: asNumber(childText(product, "vProd")) || quantity * unitPrice,
      materialId: null,
    };
  });

  if (!items.length) throw new Error("A NF-e não possui itens de produto para conferência.");
  return {
    number: childText(ide, "nNF") ?? "Sem número",
    accessKey,
    issuerName: childText(issuer, "xNome") ?? "Emitente não identificado",
    issuerDocument: childText(issuer, "CNPJ") ?? childText(issuer, "CPF"),
    issueDate: parseIssueDate(childText(ide, "dhEmi") ?? childText(ide, "dEmi")),
    totalAmount: asNumber(childText(total, "vNF")) || items.reduce((sum, item) => sum + item.totalPrice, 0),
    items,
  };
}
