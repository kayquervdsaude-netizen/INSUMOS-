import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { loginPathFor } from "@/lib/routeGuard";
import { ArrowRight, BarChart3, Boxes, ClipboardCheck, ClipboardList, FileInput, KeyRound, LayoutDashboard, LogOut, Menu, Monitor, Moon, PackageSearch, ReceiptText, Search, ShieldCheck, Snowflake, Sun, Truck, UsersRound, X } from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { DashboardLayoutSkeleton } from "./DashboardLayoutSkeleton";
import { useTheme } from "@/contexts/ThemeContext";

const menuItems = [
  { icon: LayoutDashboard, label: "Visão geral", path: "/" },
  { icon: PackageSearch, label: "Insumos", path: "/insumos" },
  { icon: UsersRound, label: "Fornecedores", path: "/fornecedores", adminOrDirector: true },
  { icon: ReceiptText, label: "Compras", path: "/compras" },
  { icon: FileInput, label: "Entradas XML", path: "/notas", adminOrDirector: true },
  { icon: Boxes, label: "Movimentações", path: "/movimentacoes" },
  { icon: ClipboardList, label: "Solicitações", path: "/solicitacoes" },
  { icon: Snowflake, label: "Refrigerados", path: "/refrigerados", visitorHidden: true },
  { icon: ShieldCheck, label: "Usuários", path: "/equipe", ownerOnly: true },
  { icon: ClipboardCheck, label: "Pedidos", path: "/pedidos-saida" },
  { icon: BarChart3, label: "Relatórios", path: "/relatorios-saida" },
  { icon: ClipboardCheck, label: "Auditoria", path: "/auditoria", adminOrDirector: true },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { loading, user, logout } = useAuth();
  const { theme, setTheme } = useTheme();
  const [location, setLocation] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (!loading && !user) setLocation(loginPathFor(`${location}${window.location.search}`));
  }, [loading, location, setLocation, user]);

  if (loading) return <DashboardLayoutSkeleton />;
  if (!user) return null;

  const navigate = (path: string) => { setMobileOpen(false); setLocation(path); };
  const submitSearch = (event: React.FormEvent) => { event.preventDefault(); if (search.trim()) setLocation(`/insumos?busca=${encodeURIComponent(search.trim())}`); };

  const visibleMenuItems = menuItems.filter(item => (!(item as { adminOnly?: boolean }).adminOnly || user.role === "admin") && (!(item as { adminOrDirector?: boolean }).adminOrDirector || user.role === "admin" || user.role === "diretoria") && (!(item as { ownerOnly?: boolean }).ownerOnly || user.isOwner) && (!item.visitorHidden || user.loginMethod !== "visitor"));
  return <div className="min-h-screen bg-[#f7f7fb] text-black">
    <div className="hidden h-9 items-center justify-center gap-3 bg-[#7e258d] px-4 text-xs font-bold text-white sm:flex"><Truck className="h-4 w-4" />Controle operacional de insumos, compras e pedidos em tempo real <span className="hidden text-white/70 lg:inline">· acesso protegido por perfil</span></div>
    <header className="sticky top-0 z-40 border-b border-black/15 bg-white/95 backdrop-blur">
      <div className="mx-auto flex max-w-[1600px] items-center gap-4 px-4 py-3 lg:px-8">
        <button className="grid h-10 w-10 place-items-center border border-black bg-white lg:hidden" onClick={() => setMobileOpen(value => !value)} aria-label="Abrir menu">{mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}</button>
        <button className="flex shrink-0 items-center gap-3 text-left" onClick={() => navigate("/")} aria-label="Ir para visão geral"><img src="/manus-storage/llt-logo_3256230f.avif" alt="LLT" className="h-11 w-11 rounded-full border border-[#7e258d]/30 bg-white object-contain" /><div className="hidden sm:block"><img src="/manus-storage/rvd-saude-logo_cb473562.png" alt="RVD Saúde" className="h-5 w-auto max-w-28 object-contain object-left" /><p className="mt-1 text-[10px] font-black uppercase tracking-[0.16em] text-[#7e258d]">Controle de insumos</p></div></button>
        <form onSubmit={submitSearch} className="relative hidden flex-1 md:block"><Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-[#7e258d]" /><input value={search} onChange={event => setSearch(event.target.value)} className="h-11 w-full rounded-full border-0 bg-[#f3f0f7] pl-11 pr-5 text-sm outline-none ring-1 ring-transparent transition focus:ring-[#7e258d]" placeholder="Pesquise insumos, fornecedores ou compras" /></form>
        <label className="flex items-center gap-1 rounded-full bg-[#f3f0f7] px-2 py-2 text-xs font-bold" title="Escolher tema"><span className="text-[#7e258d]">{theme === "dark" ? <Moon className="h-4 w-4" /> : theme === "system" ? <Monitor className="h-4 w-4" /> : <Sun className="h-4 w-4" />}</span><select aria-label="Tema da aplicação" className="max-w-24 bg-transparent text-[11px] font-bold outline-none" value={theme} onChange={event => setTheme(event.target.value as "light" | "dark" | "system")}><option value="light">Claro</option><option value="dark">Escuro</option><option value="system">Automático</option></select></label>
        <DropdownMenu><DropdownMenuTrigger asChild><button className="ml-auto flex items-center gap-3 rounded-full px-2 py-1 text-left hover:bg-[#f4eafa]"><Avatar className="h-9 w-9 border border-[#7e258d]"><AvatarFallback className="bg-[#7e258d] text-xs font-bold text-white">{user.name?.charAt(0).toUpperCase() ?? "U"}</AvatarFallback></Avatar><span className="hidden max-w-32 truncate text-sm font-bold md:block">{user.name || "Usuário"}<small className="block text-[10px] font-semibold uppercase tracking-wide text-[#7e258d]">{user.loginMethod === "visitor" ? "Visitante" : user.isOwner ? "Desenvolvedor / Administrador" : user.role === "admin" ? "Administrador" : user.role === "diretoria" ? "Diretoria" : "Colaborador"}</small></span></button></DropdownMenuTrigger><DropdownMenuContent align="end" className="rounded-none border-black">{user.isOwner ? <DropdownMenuItem onClick={() => navigate("/equipe")} className="cursor-pointer rounded-none"><UsersRound className="mr-2 h-4 w-4" />Usuários</DropdownMenuItem> : null}<DropdownMenuItem onClick={() => navigate("/seguranca")} className="cursor-pointer rounded-none"><KeyRound className="mr-2 h-4 w-4" />Senha de acesso</DropdownMenuItem><DropdownMenuItem onClick={() => navigate("/privacidade")} className="cursor-pointer rounded-none"><ShieldCheck className="mr-2 h-4 w-4" />Privacidade e LGPD</DropdownMenuItem><DropdownMenuItem onClick={logout} className="cursor-pointer rounded-none text-destructive focus:text-destructive"><LogOut className="mr-2 h-4 w-4" />Sair</DropdownMenuItem></DropdownMenuContent></DropdownMenu>
      </div>
      <nav className="hidden border-t border-black/10 bg-white lg:block"><div className="mx-auto flex max-w-[1600px] items-center gap-1 overflow-x-auto px-5"><button onClick={() => setMobileOpen(value => !value)} className="mr-4 flex h-12 items-center gap-2 border-r border-black/10 pr-5 text-sm font-bold text-[#7e258d]"><Menu className="h-4 w-4" /> Todas as áreas</button>{visibleMenuItems.map(item => <button key={item.path} onClick={() => navigate(item.path)} className={`flex h-12 shrink-0 items-center gap-2 border-b-2 px-3 text-xs font-bold transition ${location === item.path ? "border-[#7e258d] text-[#7e258d]" : "border-transparent text-black/65 hover:border-[#b78ac2] hover:text-black"}`}><item.icon className="h-3.5 w-3.5" />{item.label}</button>)}</div></nav>
      {mobileOpen ? <div className="border-t border-black bg-white p-3 lg:hidden"><form onSubmit={submitSearch} className="relative mb-3"><Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#7e258d]" /><input value={search} onChange={event => setSearch(event.target.value)} className="h-10 w-full border border-black/20 bg-[#f4eafa] pl-10 pr-3 text-sm" placeholder="Pesquisar" /></form><div className="grid grid-cols-2 gap-2">{visibleMenuItems.map(item => <Button key={item.path} variant="outline" className={`justify-start rounded-none border-black text-xs ${location === item.path ? "bg-[#7e258d] text-white hover:bg-[#6b1d78] hover:text-white" : ""}`} onClick={() => navigate(item.path)}><item.icon className="h-3.5 w-3.5" />{item.label}</Button>)}</div></div> : null}
    </header>
    <div className={`${user.loginMethod === "visitor" ? "bg-amber-100" : "bg-[#f4eafa]"} border-b border-black/10`}><div className="mx-auto flex max-w-[1600px] items-center justify-between gap-4 px-4 py-2 text-xs text-black/65 lg:px-8"><span className="font-bold text-[#7e258d]">{user.loginMethod === "visitor" ? "Modo visitante · somente leitura" : user.role === "diretoria" ? "Modo Diretoria" : "Painel de acompanhamento"}</span><span className="hidden sm:inline">{user.loginMethod === "visitor" ? "Solicitações, alterações, valores e fornecedores estão bloqueados." : user.role === "diretoria" ? "Visualize todos os dados, incluindo valores e fornecedores, sem alterar a operação." : "Visualize compras, fornecedores e pedidos sem sair da operação."}</span><ArrowRight className="h-4 w-4 text-[#7e258d]" /></div></div>
    <main className="mx-auto min-h-screen max-w-[1600px] px-4 py-6 sm:px-6 lg:px-8 lg:py-9">{children}</main><footer className="border-t border-black/10 px-4 py-5 text-center text-xs font-semibold text-black/45"><p>Desenvolvido por Kayque Santos</p><div className="mt-1 flex flex-wrap justify-center gap-x-3 gap-y-1 font-bold"><span>E-mail para contato:</span><a href="mailto:Kayquesantos3520@gmail.com" className="transition hover:text-[#7e258d]">Kayquesantos3520@gmail.com</a><span aria-hidden="true">·</span><span>Telefone:</span><a href="tel:+5511986914206" className="transition hover:text-[#7e258d]">(11) 98691-4206</a></div></footer>
  </div>;
}
