import { ReactNode } from "react";

export function PageHeader({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: ReactNode }) {
  return (
    <header className="grid gap-6 border-b border-black pb-7 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-end">
      <div className="max-w-4xl">
        <p className="section-kicker">{eyebrow}</p>
        <h1 className="page-title">{title}</h1>
        <p className="mt-3 max-w-2xl text-sm leading-6 text-black/65">{description}</p>
      </div>
      {action ? <div className="shrink-0">{action}</div> : null}
    </header>
  );
}
