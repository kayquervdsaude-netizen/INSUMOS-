import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";
import { OutboundOrderManagementActions } from "./OutboundOrders";

function renderActions(status: "draft" | "picking" | "dispatched" | "cancelled", sourceRequestId: number | null) {
  return renderToStaticMarkup(createElement(OutboundOrderManagementActions, { status, sourceRequestId, isAdmin: true, onEdit: vi.fn(), onDelete: vi.fn(), onCancel: vi.fn() }));
}

describe("renderização da gestão administrativa de pedidos", () => {
  it("mostra editar e excluir em pedido manual rascunho", () => {
    const markup = renderActions("draft", null);
    expect(markup).toContain("Editar pedido");
    expect(markup).toContain("Excluir pedido");
    expect(markup).not.toContain("Cancelar pedido");
  });

  it("mostra exclusão em pedido manual em separação ou cancelado, sem permitir edição", () => {
    expect(renderActions("picking", null)).toContain("Excluir pedido");
    expect(renderActions("picking", null)).not.toContain("Editar pedido");
    expect(renderActions("cancelled", null)).toContain("Excluir pedido");
  });

  it("mostra cancelamento ou vínculo preservado para pedido de solicitação", () => {
    const draft = renderActions("draft", 12);
    expect(draft).toContain("Editar pedido");
    expect(draft).toContain("Cancelar pedido");
    expect(draft).not.toContain("Excluir pedido");
    expect(renderActions("cancelled", 12)).toContain("Vínculo da solicitação preservado");
  });

  it("não mostra gestão para pedido expedido", () => {
    expect(renderActions("dispatched", null)).toBe("");
  });
});
