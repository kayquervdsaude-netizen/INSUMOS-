import { useAuth } from "@/_core/hooks/useAuth";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { formatDate, formatQuantity } from "@/lib/format";
import { trpc } from "@/lib/trpc";
import { ArrowUpRight, Check, ClipboardList, PackagePlus, Pencil, Trash2, X } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";

type RequestDraft = {
  materialId: string;
  quantity: string;
  reason: string;
  notes: string;
};

const blankDraft: RequestDraft = {
  materialId: "",
  quantity: "",
  reason: "Uso interno",
  notes: "",
};

function statusLabel(status: "pending" | "approved" | "rejected") {
  if (status === "approved") return "Aprovada";
  if (status === "rejected") return "Recusada";
  return "Pendente";
}

function statusClass(status: "pending" | "approved" | "rejected") {
  if (status === "approved") return "bg-emerald-100 text-emerald-900";
  if (status === "rejected") return "bg-red-100 text-red-900";
  return "bg-amber-100 text-amber-950";
}

export function reviewStockRequestPayload(requestId: number, decision: "approved" | "rejected", reviewNotes: string) {
  return { requestId, decision, reviewNotes: reviewNotes || null };
}

export default function StockRequests() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const isAdmin = user?.role === "admin";
  const isDirector = user?.role === "diretoria";
  const canViewAll = isAdmin || isDirector;
  const [createOpen, setCreateOpen] = useState(false);
  const [reviewRequestId, setReviewRequestId] = useState<number | null>(() => {
    const id = Number(new URLSearchParams(window.location.search).get("analisar"));
    return Number.isInteger(id) && id > 0 ? id : null;
  });
  const [editRequestId, setEditRequestId] = useState<number | null>(null);
  const [deleteRequestId, setDeleteRequestId] = useState<number | null>(null);
  const [reviewNotes, setReviewNotes] = useState("");
  const [draft, setDraft] = useState<RequestDraft>(blankDraft);
  const { data: requests = [], isLoading } = trpc.stockRequests.list.useQuery();
  const { data: materials = [] } = trpc.materials.list.useQuery({ status: "active" });
  const utils = trpc.useUtils();
  const selectedMaterial = useMemo(
    () => materials.find(material => material.id === Number(draft.materialId)),
    [materials, draft.materialId]
  );
  const reviewTarget = useMemo(
    () => requests.find(request => request.id === reviewRequestId) ?? null,
    [requests, reviewRequestId]
  );
  const editTarget = useMemo(() => requests.find(request => request.id === editRequestId) ?? null, [requests, editRequestId]);
  const deleteTarget = useMemo(() => requests.find(request => request.id === deleteRequestId) ?? null, [requests, deleteRequestId]);
  const pendingCount = useMemo(
    () => requests.filter(request => request.status === "pending").length,
    [requests]
  );
  const [statusFilter, setStatusFilter] = useState(() => new URLSearchParams(window.location.search).get("status") ?? "all");
  const visibleRequests = useMemo(() => statusFilter === "all" ? requests : requests.filter(request => request.status === statusFilter), [requests, statusFilter]);

  const refreshData = async () => {
    await Promise.all([
      utils.stockRequests.list.invalidate(),
      utils.outboundOrders.list.invalidate(),
      utils.outboundOrders.report.invalidate(),
      utils.stock.movements.invalidate(),
      utils.materials.list.invalidate(),
      utils.dashboard.overview.invalidate(),
    ]);
  };

  const createMutation = trpc.stockRequests.create.useMutation({
    onSuccess: async () => {
      await refreshData();
      toast.success("Solicitação enviada para aprovação.");
      setCreateOpen(false);
      setDraft(blankDraft);
    },
    onError: error => toast.error(error.message),
  });

  const reviewMutation = trpc.stockRequests.review.useMutation({
    onSuccess: async result => {
      await refreshData();
      toast.success(
        result.status === "approved"
          ? "Solicitação aprovada e enviada para a aba de Pedidos para separação."
          : "Solicitação recusada."
      );
      setReviewRequestId(null);
      setReviewNotes("");
    },
    onError: error => toast.error(error.message),
  });

  const updateMutation = trpc.stockRequests.update.useMutation({
    onSuccess: async () => { await refreshData(); setEditRequestId(null); setDraft(blankDraft); toast.success("Solicitação atualizada."); },
    onError: error => toast.error(error.message),
  });
  const deleteMutation = trpc.stockRequests.remove.useMutation({
    onSuccess: async () => { await refreshData(); setDeleteRequestId(null); toast.success("Solicitação excluída."); },
    onError: error => toast.error(error.message),
  });

  const submitRequest = () => {
    const quantity = Number(draft.quantity);
    if (!draft.materialId || !Number.isFinite(quantity) || quantity <= 0) {
      return toast.error("Selecione um insumo e informe uma quantidade válida.");
    }
    if (selectedMaterial && quantity > Number(selectedMaterial.stockQuantity)) {
      return toast.error("A quantidade é maior que o saldo disponível.");
    }
    createMutation.mutate({
      materialId: Number(draft.materialId),
      quantity,
      reason: draft.reason,
      notes: draft.notes || null,
    });
  };

  const review = (decision: "approved" | "rejected") => {
    if (!reviewTarget) return;
    reviewMutation.mutate(reviewStockRequestPayload(reviewTarget.id, decision, reviewNotes));
  };

  const openEdit = (request: typeof requests[number]) => {
    setDraft({ materialId: String(request.materialId), quantity: String(request.quantity), reason: request.reason, notes: request.notes ?? "" });
    setEditRequestId(request.id);
  };
  const submitEdit = () => {
    if (!editTarget) return;
    const quantity = Number(draft.quantity);
    if (!draft.materialId || !Number.isFinite(quantity) || quantity <= 0) return toast.error("Selecione um insumo e informe uma quantidade válida.");
    updateMutation.mutate({ requestId: editTarget.id, data: { materialId: Number(draft.materialId), quantity, reason: draft.reason, notes: draft.notes || null } });
  };

  const closeReview = (open: boolean) => {
    if (!open) {
      setReviewRequestId(null);
      setReviewNotes("");
    }
  };

  const columns = canViewAll ? 8 : 7;

  return (
    <div className="page-stack">
      <PageHeader
        eyebrow="Estoque / 07"
        title="Solicitações de retirada"
        description={
          canViewAll
            ? isDirector ? "Acompanhe todos os pedidos dos colaboradores em modo somente leitura." : "Acompanhe os pedidos dos colaboradores. Ao aprovar, o sistema cria automaticamente um pedido de separação na aba Pedidos."
            : "Solicite a retirada de um insumo. Depois da aprovação, seu pedido seguirá para separação na aba Pedidos."
        }
        action={!isDirector ? (
          <Button className="button-red" onClick={() => setCreateOpen(true)}>
            <PackagePlus className="h-4 w-4" />
            Solicitar retirada
          </Button>
        ) : undefined}
      />

      {isAdmin ? (
        <section className="grid gap-px border border-black bg-black sm:grid-cols-3">
          <div className="bg-white p-4">
            <span className="section-kicker block text-black/55">Em análise</span>
            <strong className="mt-2 block text-3xl font-black tracking-[-0.06em]">{pendingCount}</strong>
          </div>
          <div className="bg-white p-4 sm:col-span-2">
            <span className="section-kicker block text-black/55">Regra de aprovação</span>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-black/70">
              Somente administradores analisam os pedidos. Ao aprovar, a solicitação vira um pedido de separação; a baixa acontece somente na expedição.
            </p>
          </div>
        </section>
      ) : null}

      <section className="overflow-hidden border border-black bg-white">
        <div className="flex justify-end border-b border-black bg-[#f4eafa] p-3"><select aria-label="Filtrar solicitações por status" className="h-10 border border-black bg-white px-3 text-sm font-bold" value={statusFilter} onChange={event => setStatusFilter(event.target.value)}><option value="all">Todos os status</option><option value="pending">Pendentes</option><option value="approved">Aprovadas</option><option value="rejected">Recusadas</option></select></div>
        {isLoading ? (
          <p className="px-6 py-12 text-center text-black/55">Carregando solicitações…</p>
        ) : visibleRequests.length === 0 ? (
          <div className="px-6 py-12 text-center">
            <ClipboardList className="mx-auto h-6 w-6 text-[#7e258d]" />
            <p className="mt-3 font-bold">{requests.length === 0 ? "Nenhuma solicitação registrada até o momento." : "Nenhuma solicitação encontrada neste filtro."}</p>
            <p className="mt-1 text-sm text-black/55">Use o botão “Solicitar retirada” para criar o primeiro pedido.</p>
          </div>
        ) : (
          <>
          <div className="grid gap-3 p-3 md:hidden">
            {visibleRequests.map(request => (
              <article key={request.id} className="rounded-xl border border-black bg-white p-4 shadow-sm">
                <div className="flex items-start justify-between gap-3">
                  <div><p className="section-kicker text-black/55">Solicitação #{request.id}</p><p className="mt-1 font-black">{request.materialName}</p></div>
                  <span className={`shrink-0 rounded-md px-2 py-1 text-xs font-bold ${statusClass(request.status)}`}>{statusLabel(request.status)}</span>
                </div>
                <dl className="mt-4 grid grid-cols-2 gap-x-3 gap-y-3 text-sm">
                  <div><dt className="section-kicker text-black/50">Quantidade</dt><dd className="mt-1 font-bold">{formatQuantity(request.quantity)} {request.unit}</dd></div>
                  <div><dt className="section-kicker text-black/50">Finalidade</dt><dd className="mt-1">{request.reason}</dd></div>
                  {canViewAll ? <div className="col-span-2"><dt className="section-kicker text-black/50">Colaborador</dt><dd className="mt-1 font-bold">{request.requesterName || "Colaborador"}</dd></div> : null}
                  <div className="col-span-2"><dt className="section-kicker text-black/50">Solicitado em</dt><dd className="mt-1">{formatDate(request.createdAt)}</dd></div>
                </dl>
                {request.notes ? <p className="mt-3 rounded-lg bg-[#f4edf7] p-3 text-xs leading-5 text-black/70">{request.notes}</p> : null}
                <div className="mt-4 flex flex-wrap gap-2">
                  {request.outboundOrderId ? <Button variant="outline" size="sm" className="rounded-lg border-black" onClick={() => setLocation(`/pedidos-saida?pedido=${request.outboundOrderId}`)}>Abrir pedido <ArrowUpRight className="h-3.5 w-3.5" /></Button> : null}
                  {isAdmin && request.status === "pending" ? <><Button variant="outline" size="sm" className="rounded-lg border-black" onClick={() => openEdit(request)}><Pencil className="h-3.5 w-3.5" /> Editar</Button><Button variant="outline" size="sm" className="rounded-lg border-red-600 text-red-700" onClick={() => setDeleteRequestId(request.id)}><Trash2 className="h-3.5 w-3.5" /> Excluir</Button><Button size="sm" className="button-red" onClick={() => setReviewRequestId(request.id)}><Check className="h-3.5 w-3.5" /> Aceitar ou recusar</Button></> : null}
                </div>
              </article>
            ))}
          </div>
          <div className="hidden overflow-x-auto md:block">
            <table className="data-table min-w-[1050px]">
              <thead>
                <tr>
                  <th>Solicitado em</th>
                  {canViewAll ? <th>Colaborador</th> : null}
                  <th>Insumo</th>
                  <th>Finalidade</th>
                  <th className="text-right">Quantidade</th>
                  <th>Status</th>
                  <th>Análise</th>
                  {isAdmin ? <th className="text-right">Ação</th> : null}
                </tr>
              </thead>
              <tbody>
                {visibleRequests.map(request => (
                  <tr key={request.id}>
                    <td>{formatDate(request.createdAt)}</td>
                    {canViewAll ? (
                      <td>
                        <p className="font-bold">{request.requesterName || "Colaborador"}</p>
                      </td>
                    ) : null}
                    <td>
                      <p className="font-bold">{request.materialName}</p>
                      <p className="text-xs text-black/50">
                        Saldo atual: {formatQuantity(request.availableStock)} {request.unit}
                      </p>
                    </td>
                    <td>
                      <p>{request.reason}</p>
                      {request.notes ? <p className="mt-1 max-w-xs text-xs text-black/55">{request.notes}</p> : null}
                    </td>
                    <td className="text-right font-bold">
                      {formatQuantity(request.quantity)} {request.unit}
                    </td>
                    <td>
                      <span className={`inline-flex px-2 py-1 text-xs font-bold ${statusClass(request.status)}`}>
                        {statusLabel(request.status)}
                      </span>
                    </td>
                    <td>
                      {request.outboundOrderId ? (
                        <Button variant="outline" size="sm" className="rounded-none border-black" onClick={() => setLocation(`/pedidos-saida?pedido=${request.outboundOrderId}`)}>
                          Pedido {request.outboundOrderCode || `#${request.outboundOrderId}`} <ArrowUpRight className="h-3.5 w-3.5" />
                        </Button>
                      ) : request.reviewedAt ? (
                        <div>
                          <p>{formatDate(request.reviewedAt)}</p>
                          {request.reviewNotes ? <p className="mt-1 max-w-xs text-xs text-black/55">{request.reviewNotes}</p> : null}
                        </div>
                      ) : (
                        <span className="text-black/45">Aguardando análise</span>
                      )}
                    </td>
                    {isAdmin ? (
                      <td className="text-right">
                        {request.status === "pending" ? (
                          <div className="flex justify-end gap-2"><Button variant="outline" size="sm" className="rounded-none border-black" onClick={() => openEdit(request)}><Pencil className="h-3.5 w-3.5" /> Editar</Button><Button variant="outline" size="sm" className="rounded-none border-red-600 text-red-700" onClick={() => setDeleteRequestId(request.id)}><Trash2 className="h-3.5 w-3.5" /> Excluir</Button><Button size="sm" className="button-red" onClick={() => setReviewRequestId(request.id)}><Check className="h-3.5 w-3.5" /> Aceitar ou recusar</Button></div>
                        ) : (
                          request.outboundOrderId ? <Button variant="outline" size="sm" className="rounded-none border-black" onClick={() => setLocation(`/pedidos-saida?pedido=${request.outboundOrderId}`)}>Abrir pedido</Button> : <span className="text-xs font-bold text-black/45">Concluída</span>
                        )}
                      </td>
                    ) : null}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          </>
        )}
      </section>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-xl rounded-none border-2 border-black bg-white">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black tracking-[-0.05em]">Solicitar retirada</DialogTitle>
          </DialogHeader>
          <div className="form-grid pt-4">
            <label className="form-label col-span-full">
              Insumo
              <select value={draft.materialId} onChange={event => setDraft({ ...draft, materialId: event.target.value })}>
                <option value="">Selecionar insumo…</option>
                {materials.map(material => (
                  <option key={material.id} value={material.id}>
                    {material.name} — disponível: {formatQuantity(material.stockQuantity)} {material.unit}
                  </option>
                ))}
              </select>
            </label>
            {selectedMaterial ? (
              <p className="col-span-full border-l-4 border-[#7e258d] bg-[#f4eafa] p-4 text-sm leading-6">
                Saldo disponível: <strong>{formatQuantity(selectedMaterial.stockQuantity)} {selectedMaterial.unit}</strong>. A quantidade será conferida novamente no momento da aprovação.
              </p>
            ) : null}
            <label className="form-label">
              Quantidade solicitada
              <input type="number" min="0.001" step="0.001" value={draft.quantity} onChange={event => setDraft({ ...draft, quantity: event.target.value })} />
            </label>
            <label className="form-label">
              Finalidade
              <select value={draft.reason} onChange={event => setDraft({ ...draft, reason: event.target.value })}>
                <option value="Uso interno">Uso interno</option>
                <option value="Consumo operacional">Consumo operacional</option>
                <option value="Reposição de setor">Reposição de setor</option>
                <option value="Outro">Outro</option>
              </select>
            </label>
            <label className="form-label col-span-full">
              Observação
              <textarea value={draft.notes} onChange={event => setDraft({ ...draft, notes: event.target.value })} placeholder="Informe detalhes, se necessário." />
            </label>
            <p className="col-span-full border-l-4 border-red-600 bg-red-50 p-4 text-sm leading-6">
              A solicitação não dá baixa imediata. Após a aprovação, ela será enviada para a aba Pedidos, onde a equipe fará a separação e a expedição.
            </p>
            <div className="col-span-full flex justify-end gap-3">
              <Button variant="outline" className="rounded-none border-black" onClick={() => setCreateOpen(false)}>Cancelar</Button>
              <Button className="button-red" disabled={createMutation.isPending || !selectedMaterial} onClick={submitRequest}>
                <PackagePlus className="h-4 w-4" />
                Enviar solicitação
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(reviewTarget)} onOpenChange={closeReview}>
        <DialogContent className="max-w-xl rounded-none border-2 border-black bg-white">
          <DialogHeader>
            <DialogTitle className="text-2xl font-black tracking-[-0.05em]">Aceitar ou recusar solicitação</DialogTitle>
            <DialogDescription className="sr-only">Defina se a solicitação será aceita para gerar um pedido ou recusada.</DialogDescription>
          </DialogHeader>
          {reviewTarget ? (
            <div className="space-y-5 pt-3">
              <div className="border border-black bg-[#f8f7ff] p-4">
                <p className="section-kicker text-black/55">Pedido #{reviewTarget.id}</p>
                <p className="mt-2 text-xl font-black">
                  {formatQuantity(reviewTarget.quantity)} {reviewTarget.unit} · {reviewTarget.materialName}
                </p>
                <p className="mt-2 text-sm text-black/65">
                  Solicitado por <strong>{reviewTarget.requesterName || "colaborador"}</strong> para {reviewTarget.reason.toLowerCase()}.
                </p>
                <p className="mt-2 text-sm text-black/65">
                  Saldo disponível agora: <strong>{formatQuantity(reviewTarget.availableStock)} {reviewTarget.unit}</strong>.
                </p>
              </div>
              <label className="form-label">
                Observação da análise
                <textarea value={reviewNotes} onChange={event => setReviewNotes(event.target.value)} placeholder="Opcional: informe o motivo da decisão." />
              </label>
              <p className="border-l-4 border-red-600 bg-red-50 p-4 text-sm leading-6">
                Ao aprovar, será criado um pedido de separação para {formatQuantity(reviewTarget.quantity)} {reviewTarget.unit}. A baixa será registrada somente na expedição, após a conferência física.
              </p>
              <div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
                <Button variant="outline" className="rounded-none border-black" onClick={() => setReviewRequestId(null)}>Cancelar</Button>
                <Button variant="outline" className="rounded-none border-red-600 text-red-700 hover:bg-red-50 hover:text-red-800" disabled={reviewMutation.isPending} onClick={() => review("rejected")}>
                  <X className="h-4 w-4" />
                  Recusar solicitação
                </Button>
                <Button className="button-red" disabled={reviewMutation.isPending} onClick={() => review("approved")}>
                  <Check className="h-4 w-4" />
                  Aceitar e criar pedido
                </Button>
              </div>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>
      <Dialog open={Boolean(editTarget)} onOpenChange={open => { if (!open) { setEditRequestId(null); setDraft(blankDraft); } }}>
        <DialogContent className="max-w-xl rounded-none border-2 border-black bg-white"><DialogHeader><DialogTitle className="text-2xl font-black tracking-[-0.05em]">Editar solicitação</DialogTitle></DialogHeader>{editTarget ? <div className="form-grid pt-4"><label className="form-label col-span-full">Insumo<select value={draft.materialId} onChange={event => setDraft({ ...draft, materialId: event.target.value })}>{materials.map(material => <option key={material.id} value={material.id}>{material.name}</option>)}</select></label><label className="form-label">Quantidade<input type="number" min="0.001" step="0.001" value={draft.quantity} onChange={event => setDraft({ ...draft, quantity: event.target.value })} /></label><label className="form-label">Finalidade<select value={draft.reason} onChange={event => setDraft({ ...draft, reason: event.target.value })}><option value="Uso interno">Uso interno</option><option value="Consumo operacional">Consumo operacional</option><option value="Reposição de setor">Reposição de setor</option><option value="Outro">Outro</option></select></label><label className="form-label col-span-full">Observação<textarea value={draft.notes} onChange={event => setDraft({ ...draft, notes: event.target.value })} /></label><p className="col-span-full border-l-4 border-[#7e258d] bg-[#f4eafa] p-4 text-sm">Somente solicitações pendentes e sem pedido vinculado podem ser alteradas.</p><div className="col-span-full flex justify-end gap-3"><Button variant="outline" className="rounded-none border-black" onClick={() => setEditRequestId(null)}>Cancelar</Button><Button className="button-red" disabled={updateMutation.isPending} onClick={submitEdit}>Salvar alterações</Button></div></div> : null}</DialogContent>
      </Dialog>
      <Dialog open={Boolean(deleteTarget)} onOpenChange={open => { if (!open) setDeleteRequestId(null); }}>
        <DialogContent className="max-w-lg rounded-none border-2 border-black bg-white"><DialogHeader><DialogTitle className="text-2xl font-black tracking-[-0.05em]">Excluir solicitação</DialogTitle></DialogHeader>{deleteTarget ? <div className="space-y-5 pt-3"><p className="text-sm leading-6 text-black/70">A solicitação de <strong>{deleteTarget.materialName}</strong> será removida. Solicitações aprovadas ou ligadas a pedido não podem ser excluídas.</p><div className="flex justify-end gap-3"><Button variant="outline" className="rounded-none border-black" onClick={() => setDeleteRequestId(null)}>Cancelar</Button><Button className="button-red" disabled={deleteMutation.isPending} onClick={() => deleteMutation.mutate({ requestId: deleteTarget.id })}>{deleteMutation.isPending ? "Excluindo…" : "Confirmar exclusão"}</Button></div></div> : null}</DialogContent>
      </Dialog>
    </div>
  );
}
