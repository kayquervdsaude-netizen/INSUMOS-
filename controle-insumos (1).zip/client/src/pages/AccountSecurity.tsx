import { useAuth } from "@/_core/hooks/useAuth";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { KeyRound, LockKeyhole, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function AccountSecurity() {
  const { user } = useAuth();
  const isOwner = user?.isOwner === true;
  const { data: status, isLoading } = trpc.auth.passwordStatus.useQuery();
  const [currentPassword, setCurrentPassword] = useState("");
  const [password, setPassword] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const utils = trpc.useUtils();
  const setPasswordMutation = trpc.auth.setPassword.useMutation({
    onSuccess: async () => {
      toast.success(status?.isConfigured ? "Senha atualizada com sucesso." : "Senha de acesso criada com sucesso.");
      setCurrentPassword(""); setPassword(""); setConfirmation("");
      await utils.auth.passwordStatus.invalidate();
    },
    onError: error => toast.error(error.message),
  });
  const submit = () => {
    if (password.length < 8) return toast.error("A nova senha deve ter pelo menos 8 caracteres.");
    if (password !== confirmation) return toast.error("A confirmação de senha não confere.");
    if (status?.isConfigured && !currentPassword) return toast.error("Informe sua senha atual.");
    setPasswordMutation.mutate({ password, currentPassword: currentPassword || null });
  };

  return <div className="page-stack"><PageHeader eyebrow="Acessos / Segurança" title="Senha de acesso" description={isOwner ? "Defina a senha da conta administradora proprietária." : "A senha e demais alterações de acesso são controladas pelo administrador proprietário."} />
    <section className="grid overflow-hidden border border-black bg-black lg:grid-cols-[0.9fr_1.1fr]"><div className="bg-[#7e258d] p-7 text-white sm:p-10"><div className="grid h-12 w-12 place-items-center border border-white/40"><ShieldCheck className="h-6 w-6" /></div><p className="section-kicker mt-9 text-white/60">Conta atual</p><h2 className="mt-3 text-4xl font-black tracking-[-0.07em]">{user?.name || "Conta interna"}</h2><p className="mt-3 text-sm text-white/75">{user?.email || "E-mail não disponível"}</p><p className="mt-10 border-t border-white/25 pt-6 text-sm leading-6 text-white/75">{isOwner ? status?.isConfigured ? "Sua conta já possui senha. Informe a senha atual para substituí-la." : "Sua conta ainda não possui uma senha local. Crie uma agora para acessar diretamente pela tela de login." : "Esta conta não pode alterar credenciais ou permissões. Solicite qualquer necessidade de acesso ao administrador proprietário."}</p></div><div className="bg-white p-7 sm:p-10">{isOwner ? <><p className="section-kicker">Credencial de acesso</p><h2 className="mt-3 text-2xl font-black tracking-[-0.05em]">{isLoading ? "Verificando…" : status?.isConfigured ? "Alterar senha" : "Criar senha"}</h2><div className="mt-8 grid gap-5"><label className={`form-label ${status?.isConfigured ? "" : "hidden"}`}>Senha atual<div className="relative"><LockKeyhole className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-black/45" /><input className="pl-10" type="password" autoComplete="current-password" value={currentPassword} onChange={event => setCurrentPassword(event.target.value)} /></div></label><label className="form-label">Nova senha<div className="relative"><KeyRound className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-black/45" /><input className="pl-10" type="password" autoComplete="new-password" value={password} onChange={event => setPassword(event.target.value)} placeholder="Mínimo de 8 caracteres" /></div></label><label className="form-label">Confirmar nova senha<input type="password" autoComplete="new-password" value={confirmation} onChange={event => setConfirmation(event.target.value)} /></label></div><Button className="button-red mt-8" disabled={isLoading || setPasswordMutation.isPending} onClick={submit}>{setPasswordMutation.isPending ? "Salvando…" : status?.isConfigured ? "Atualizar senha" : "Criar senha de acesso"}</Button></> : <div className="flex h-full flex-col justify-center"><LockKeyhole className="h-9 w-9 text-red-700" /><p className="section-kicker mt-6">Ação bloqueada</p><h2 className="mt-3 text-2xl font-black tracking-[-0.05em]">Credencial controlada</h2><p className="mt-4 max-w-md text-sm leading-6 text-black/65">Somente a conta administradora proprietária pode criar ou alterar senhas neste ambiente.</p></div>}</div></section>
  </div>;
}
