import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Boxes, ChevronLeft, ChevronRight, KeyRound, LockKeyhole, Mail, ShieldCheck } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { getSafeRedirectPath } from "@/lib/routeGuard";
import { startLogin } from "@/const";

const loginSlides = [
  { eyebrow: "Acesso interno", title: "Estoque sob controle.", text: "Acompanhe a operação em um só lugar: indicadores reais de estoque, compras, fornecedores e pedidos para apoiar decisões rápidas da rotina.", icon: ShieldCheck },
  { eyebrow: "Quem somos", title: "Saúde organizada para cuidar melhor.", text: "A RVD Saúde trabalha para tornar a rotina operacional mais segura, rastreável e eficiente para toda a equipe.", icon: ShieldCheck },
  { eyebrow: "O que o sistema faz", title: "Do estoque à expedição, tudo em um só lugar.", text: "Cadastre insumos, acompanhe compras, controle entradas e saídas, solicite materiais e mantenha o saldo sempre atualizado.", icon: Boxes },
  { eyebrow: "Acesso protegido", title: "Cada pessoa vê apenas o que precisa.", text: "Perfis de administrador, Diretoria, colaborador e visitante organizam as permissões e protegem informações sensíveis da operação.", icon: KeyRound },
] as const;

export default function Login() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();
  const nextPath = getSafeRedirectPath(new URLSearchParams(window.location.search).get("next"));
  const utils = trpc.useUtils();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [slideIndex, setSlideIndex] = useState(0);
  const slide = loginSlides[slideIndex];
  const loginMutation = trpc.auth.passwordLogin.useMutation({
    onSuccess: async user => {
      utils.auth.me.setData(undefined, user);
      await utils.auth.me.invalidate();
      setLocation(nextPath);
    },
    onError: error => toast.error(error.message),
  });
  const visitorMutation = trpc.auth.visitorLogin.useMutation({
    onSuccess: async user => {
      utils.auth.me.setData(undefined, user);
      await utils.auth.me.invalidate();
      setLocation(nextPath);
    },
    onError: error => toast.error(error.message),
  });

  useEffect(() => {
    if (!loading && user) setLocation(nextPath);
  }, [loading, nextPath, setLocation, user]);

  useEffect(() => {
    const timer = window.setInterval(() => setSlideIndex(current => (current + 1) % loginSlides.length), 6000);
    return () => window.clearInterval(timer);
  }, []);

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!email.trim() || !password) return toast.error("Informe seu e-mail e sua senha.");
    loginMutation.mutate({ email: email.trim().toLowerCase(), password });
  };

  return (
    <div className="grid min-h-screen bg-[#f5f4fb] lg:grid-cols-[1.1fr_0.9fr]">
      <section className="relative flex min-h-[430px] flex-col justify-between overflow-hidden bg-[#4f176a] p-6 text-white sm:p-10 lg:min-h-screen lg:p-12">
        <div className="absolute -right-20 -top-24 h-80 w-80 rounded-full border-[36px] border-white/10" />
        <div className="relative flex items-center justify-center gap-5 sm:justify-start sm:gap-7" aria-label="Logotipos LLT e RVD Saúde">
          <img src="/manus-storage/pasted_file_EBawAD_WhatsAppImage2026-09-22at12.39.12_0f30f21a.jpeg" alt="Logo RVD Saúde" className="h-28 w-28 rounded-full object-contain sm:h-32 sm:w-32" />
          <span className="h-14 w-px bg-white/30 sm:h-16" aria-hidden="true" />
          <img src="/manus-storage/pasted_file_REAFZ2_WhatsAppImage2026-09-22at12.38.48_22671914.jpeg" alt="Logo LLT" className="h-24 w-32 object-contain sm:h-28 sm:w-40" />
        </div>
        <section className="relative mx-auto w-full max-w-2xl overflow-hidden rounded-2xl bg-white/10 text-white shadow-[8px_8px_0_#7e258d] backdrop-blur-sm" aria-label="Informações sobre a empresa e o sistema">
          <div className="flex items-center justify-between gap-4 px-5 py-5 sm:px-7 sm:py-6">
            <div className="min-w-0">
              <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-[#e5c9ed]">{slide.eyebrow}</p>
              <h1 className="mt-2 text-2xl font-black leading-tight tracking-[-0.05em] sm:text-4xl">{slide.title}</h1>
              <p className="mt-3 max-w-xl text-sm leading-6 text-white/75">{slide.text}</p>
            </div>
            <span className="hidden h-14 w-14 shrink-0 place-items-center rounded-xl bg-white/15 sm:grid"><slide.icon className="h-7 w-7 text-[#e5c9ed]" /></span>
          </div>
          <div className="flex items-center justify-between border-t border-white/15 px-5 py-3 sm:px-7">
            <div className="flex gap-1.5" aria-label="Selecionar slide">{loginSlides.map((item, index) => <button key={item.eyebrow} type="button" aria-label={`Mostrar slide ${index + 1}`} aria-current={index === slideIndex} onClick={() => setSlideIndex(index)} className={`h-1.5 rounded-full transition-all ${index === slideIndex ? "w-8 bg-white" : "w-1.5 bg-white/40"}`} />)}</div>
            <div className="flex gap-1"><button type="button" aria-label="Slide anterior" onClick={() => setSlideIndex(current => (current - 1 + loginSlides.length) % loginSlides.length)} className="grid h-8 w-8 place-items-center rounded-full text-white/75 transition hover:bg-white/15 hover:text-white"><ChevronLeft className="h-4 w-4" /></button><button type="button" aria-label="Próximo slide" onClick={() => setSlideIndex(current => (current + 1) % loginSlides.length)} className="grid h-8 w-8 place-items-center rounded-full text-white/75 transition hover:bg-white/15 hover:text-white"><ChevronRight className="h-4 w-4" /></button></div>
          </div>
        </section>
        <div className="relative hidden items-center gap-3 border-t border-white/20 pt-6 text-sm text-white/70 sm:flex"><ShieldCheck className="h-5 w-5" />Credenciais protegidas e acesso por perfil</div>
      </section>
      <main className="flex min-h-screen flex-col items-center justify-center gap-8 p-5 sm:p-10">
        <form onSubmit={submit} className="w-full max-w-md border-2 border-black bg-white p-7 shadow-[8px_8px_0_#7e258d] sm:p-10">
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="section-kicker text-[#7e258d]">Acesso ao sistema</p>
              <h2 className="mt-3 text-4xl font-black tracking-[-0.07em]">Entrar</h2>
            </div>
            <div className="grid h-12 w-12 place-items-center bg-[#7e258d] text-white"><KeyRound className="h-5 w-5" /></div>
          </div>
          <p className="mt-5 text-sm leading-6 text-black/60">Use o e-mail e a senha cadastrados para sua conta.</p>
          <div className="mt-8 space-y-5">
            <label className="form-label">E-mail de acesso<div className="relative"><Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-black/45" /><input className="pl-10" type="email" autoComplete="email" value={email} onChange={event => setEmail(event.target.value)} placeholder="nome@empresa.com.br" /></div></label>
            <label className="form-label">Senha<div className="relative"><LockKeyhole className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-black/45" /><input className="pl-10" type="password" autoComplete="current-password" value={password} onChange={event => setPassword(event.target.value)} placeholder="Sua senha" /></div></label>
          </div>
          <Button type="submit" className="button-red mt-8 w-full" size="lg" disabled={loginMutation.isPending}>{loginMutation.isPending ? "Entrando…" : "Entrar no sistema"}</Button>
          <div className="mt-7 border-t border-black/15 pt-5 text-center"><Button type="button" variant="outline" className="w-full rounded-none border-[#7e258d] text-[#7e258d] hover:bg-[#f4eafa]" onClick={() => startLogin()}>Entrar com conta do proprietário</Button><p className="mt-2 text-xs leading-5 text-black/50">Use esta opção para o Desenvolvedor + Administrador. Os demais colaboradores devem usar o e-mail e a senha cadastrados.</p><Button type="button" variant="outline" className="mt-4 w-full rounded-none border-[#7e258d] text-[#7e258d] hover:bg-[#f4eafa]" disabled={visitorMutation.isPending} onClick={() => visitorMutation.mutate()}>{visitorMutation.isPending ? "Abrindo acesso…" : "Entrar como visitante"}</Button><p className="mt-2 text-[11px] text-black/45">Acesso somente para consulta, sem solicitações, alterações, valores ou fornecedores.</p></div>
        </form>
        <footer className="text-center text-xs font-semibold text-black/45"><p>Desenvolvido por Kayque Santos</p><div className="mt-1 flex flex-wrap justify-center gap-x-3 gap-y-1 font-bold"><span>E-mail para contato:</span><a href="mailto:Kayquesantos3520@gmail.com" className="transition hover:text-[#7e258d]">Kayquesantos3520@gmail.com</a><span aria-hidden="true">·</span><span>Telefone:</span><a href="tel:+5511986914206" className="transition hover:text-[#7e258d]">(11) 98691-4206</a></div></footer>
      </main>
    </div>
  );
}
