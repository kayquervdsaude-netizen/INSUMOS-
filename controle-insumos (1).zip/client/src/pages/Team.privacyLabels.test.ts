import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("identificação de perfis e minimização de dados", () => {
  it("mantém rótulos distintos de proprietário, administrador e colaborador na gestão de usuários", () => {
    const source = readFileSync(new URL("./Team.tsx", import.meta.url), "utf8");
    expect(source).toContain('"Administrador proprietário"');
    expect(source).toContain("Proprietário</span>");
    expect(source).toContain("Administrador</span>");
    expect(source).toContain("Colaborador</span>");
  });

  it("não expõe e-mail na fila administrativa de solicitações nem na auditoria exibida", () => {
    const stockRequests = readFileSync(new URL("./StockRequests.tsx", import.meta.url), "utf8");
    const privacy = readFileSync(new URL("./Privacy.tsx", import.meta.url), "utf8");
    expect(stockRequests).not.toContain("request.requesterEmail");
    expect(privacy).not.toContain("actorEmail");
  });
});
