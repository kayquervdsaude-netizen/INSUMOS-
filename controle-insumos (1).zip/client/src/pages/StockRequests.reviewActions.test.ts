import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { reviewStockRequestPayload } from "./StockRequests";

describe("ações de aprovação de solicitações", () => {
  it("expõe ao administrador uma decisão explícita de aceitar ou recusar", () => {
    const source = readFileSync(new URL("./StockRequests.tsx", import.meta.url), "utf8");
    expect(source).toContain("Aceitar ou recusar");
    expect(source).toContain('review("rejected")');
    expect(source).toContain('review("approved")');
    expect(source).toContain("Aceitar e criar pedido");
  });

  it("envia a decisão e a justificativa corretas para aceitar ou recusar", () => {
    expect(reviewStockRequestPayload(12, "approved", "Separar hoje")).toEqual({ requestId: 12, decision: "approved", reviewNotes: "Separar hoje" });
    expect(reviewStockRequestPayload(12, "rejected", "")).toEqual({ requestId: 12, decision: "rejected", reviewNotes: null });
  });
});
