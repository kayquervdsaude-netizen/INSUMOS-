// @vitest-environment jsdom
import "@testing-library/jest-dom/vitest";
import React from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ review: vi.fn(), toastError: vi.fn(), toastSuccess: vi.fn() }));
const request = { id: 60001, materialId: 12, materialName: "Caixa 04", unit: "Und", quantity: "2", reason: "Uso interno", notes: null, status: "pending" as const, requesterName: "Colaborador", createdAt: new Date("2026-08-26T12:00:00") };

vi.mock("@/_core/hooks/useAuth", () => ({ useAuth: () => ({ user: { role: "admin" } }) }));
vi.mock("wouter", () => ({ useLocation: () => ["/solicitacoes", vi.fn()] }));
vi.mock("sonner", () => ({ toast: { error: mocks.toastError, success: mocks.toastSuccess } }));
vi.mock("@/lib/trpc", () => ({
  trpc: {
    stockRequests: {
      list: { useQuery: () => ({ data: [request], isLoading: false }), invalidate: vi.fn() },
      create: { useMutation: () => ({ mutate: vi.fn(), isPending: false }) },
      review: { useMutation: () => ({ mutate: mocks.review, isPending: false }) },
      update: { useMutation: () => ({ mutate: vi.fn(), isPending: false }) },
      remove: { useMutation: () => ({ mutate: vi.fn(), isPending: false }) },
    },
    materials: { list: { useQuery: () => ({ data: [{ id: 12, stockQuantity: "20" }] }), invalidate: vi.fn() } },
    outboundOrders: { list: { invalidate: vi.fn() }, report: { invalidate: vi.fn() } },
    stock: { movements: { invalidate: vi.fn() } },
    dashboard: { overview: { invalidate: vi.fn() } },
    useUtils: () => ({ stockRequests: { list: { invalidate: vi.fn() } }, outboundOrders: { list: { invalidate: vi.fn() }, report: { invalidate: vi.fn() } }, stock: { movements: { invalidate: vi.fn() } }, materials: { list: { invalidate: vi.fn() } }, dashboard: { overview: { invalidate: vi.fn() } } }),
  },
}));

import StockRequests from "./StockRequests";

describe("análise administrativa de solicitações", () => {
  beforeEach(() => mocks.review.mockReset());

  it("abre a análise e envia decisões explícitas de aceite e recusa", async () => {
    const user = userEvent.setup();
    render(<StockRequests />);
    await user.click(screen.getAllByRole("button", { name: "Aceitar ou recusar" })[0]);
    expect(screen.getByRole("heading", { name: "Aceitar ou recusar solicitação" })).toBeVisible();
    await user.type(screen.getByLabelText("Observação da análise"), "Conferido");
    await user.click(screen.getByRole("button", { name: "Aceitar e criar pedido" }));
    expect(mocks.review).toHaveBeenLastCalledWith({ requestId: 60001, decision: "approved", reviewNotes: "Conferido" });
    await user.click(screen.getByRole("button", { name: "Recusar solicitação" }));
    expect(mocks.review).toHaveBeenLastCalledWith({ requestId: 60001, decision: "rejected", reviewNotes: "Conferido" });
  });
});
