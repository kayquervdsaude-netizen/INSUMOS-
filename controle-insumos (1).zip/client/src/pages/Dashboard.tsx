import { AlertTriangle, ArrowDownRight, Boxes, ClipboardCheck, FileText, Landmark, PackageSearch, ShoppingBag, TrendingUp, UsersRound } from "lucide-react";
import { Area, AreaChart, Bar, BarChart, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { PageHeader } from "@/components/PageHeader";
import { trpc } from "@/lib/trpc";
import { formatCurrency, formatDate, formatDateTime, formatQuantity } from "@/lib/format";
import { useAuth } from "@/_core/hooks/useAuth";
import { useState } from "react";
import { useLocation } from "wouter";

const statusLabels = { draft: "Aguardando", picking: "Em separação", dispatched: "Expedidos", cancelled: "Cancelados" } as const;
const statusColors = ["#7e258d", "#b78ac2", "#83c7df", "#e3a6b0"];

function Metric({ icon: Icon, label, value, detail, accent = "purple" }: { icon: typeof Boxes; label: string; value: string | number; detail: string; accent?: "purple" | "blue" | "dark" | "white" }) {
  const colors = { purple: "border-[#7e258d]/20 bg-[#f4eafa]", blue: "border-[#83c7df]/40 bg-[#effaff]", dark: "border-black bg-[#231126] text-white", white: "border-black/10 bg-white" };
  return <article className={`rounded-2xl border p-5 shadow-sm ${colors[accent]}`}><div className="flex items-start justify-between"><p className={`text-xs font-black uppercase tracking-[0.14em] ${accent === "dark" ? "text-white/60" : "text-black/50"}`}>{label}</p><span className={`grid h-9 w-9 place-items-center rounded-xl ${accent === "dark" ? "bg-white/15" : "bg-white"}`}><Icon className={`h-4 w-4 ${accent === "dark" ? "text-white" : "text-[#7e258d]"}`} /></span></div><p className="mt-6 text-4xl font-black tracking-[-0.07em]">{value}</p><p className={`mt-2 text-xs leading-5 ${accent === "dark" ? "text-white/65" : "text-black/55"}`}>{detail}</p></article>;
}

function ChartHeader({ eyebrow, title, icon: Icon }: { eyebrow: string; title: string; icon: typeof TrendingUp }) {
  return <div className="flex items-start justify-between border-b border-black/10 p-5"><div><p className="section-kicker text-[#7e258d]">{eyebrow}</p><h2 className="mt-1 text-xl font-black tracking-[-0.05em]">{title}</h2></div><span className="grid h-9 w-9 place-items-center rounded-xl bg-[#f4eafa]"><Icon className="h-4 w-4 text-[#7e258d]" /></span></div>;
}

export default function Dashboard() {
  const { user } = useAuth();
  const canViewFinancial = user?.role === "admin" || user?.role === "diretoria";
  const [months, setMonths] = useState(6);
  const [, navigate] = useLocation();
  const { data, isLoading } = trpc.dashboard.overview.useQuery({ months });
  const metrics = data?.metrics;
  const charts = data?.charts;
  const statusData = (charts?.orderStatusDistribution ?? []).map(row => ({ ...row, name: statusLabels[row.status] }));

  return <div className="page-stack">
    <PageHeader eyebrow="Central operacional" title="Acompanhe a operação em um só lugar." description="Indicadores reais de estoque, compras, fornecedores e pedidos para apoiar decisões rápidas da rotina." action={<label className="form-label min-w-44">Período<select value={months} onChange={event => setMonths(Number(event.target.value))}><option value="3">Últimos 3 meses</option><option value="6">Últimos 6 meses</option><option value="12">Últimos 12 meses</option></select></label>} />

    <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
      <Metric icon={PackageSearch} label="Insumos" value={isLoading ? "—" : metrics?.materials ?? 0} detail="Cadastros ativos na base" />
      {canViewFinancial ? <Metric icon={UsersRound} label="Fornecedores" value={isLoading ? "—" : metrics?.suppliers ?? 0} detail="Parceiros cadastrados" accent="blue" /> : null}
      <Metric icon={ShoppingBag} label="Compras" value={isLoading ? "—" : metrics?.purchases ?? 0} detail="Pedidos históricos importados" accent="white" />
      {canViewFinancial ? <Metric icon={FileText} label="Notas fiscais" value={isLoading ? "—" : metrics?.invoices ?? 0} detail="Importações realizadas" accent="white" /> : null}
      {canViewFinancial ? <Metric icon={Boxes} label="Estoque estimado" value={isLoading ? "—" : formatCurrency(metrics?.stockValue)} detail={isLoading ? "Somando o saldo dos materiais ativos…" : `${formatQuantity(metrics?.stockQuantityTotal)} unidades somadas · saldo × custo médio`} accent="dark" /> : null}
    </section>

    <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
      <button type="button" onClick={() => navigate("/insumos?baixoEstoque=1&nivel=atencao")} className="flex items-center gap-4 rounded-xl border border-amber-300 bg-amber-50 p-4 text-left transition hover:bg-amber-100"><AlertTriangle className="h-6 w-6 text-amber-700" /><span><strong className="block text-2xl font-black">{metrics?.lowStock ?? 0}</strong><span className="text-xs font-bold text-amber-900/70">Atenção: abaixo do mínimo</span></span></button>
      <button type="button" onClick={() => navigate("/insumos?baixoEstoque=1&nivel=critico")} className="flex items-center gap-4 rounded-xl border border-red-300 bg-red-50 p-4 text-left transition hover:bg-red-100"><AlertTriangle className="h-6 w-6 text-red-700" /><span><strong className="block text-2xl font-black">{metrics?.criticalStock ?? 0}</strong><span className="text-xs font-bold text-red-900/70">Crítico: abaixo do limite</span></span></button>
      <button type="button" onClick={() => navigate("/solicitacoes?status=pending")} className="flex items-center gap-4 rounded-xl border border-[#7e258d]/25 bg-[#f4eafa] p-4 text-left transition hover:bg-[#eadcf0]"><ClipboardCheck className="h-6 w-6 text-[#7e258d]" /><span><strong className="block text-2xl font-black">{metrics?.pendingRequests ?? 0}</strong><span className="text-xs font-bold text-[#571c68]/70">Solicitações pendentes</span></span></button>
      <button type="button" onClick={() => navigate("/compras?status=awaiting_confirmation")} className="flex items-center gap-4 rounded-xl border border-sky-200 bg-sky-50 p-4 text-left transition hover:bg-sky-100"><ShoppingBag className="h-6 w-6 text-sky-700" /><span><strong className="block text-2xl font-black">{metrics?.awaitingPurchases ?? 0}</strong><span className="text-xs font-bold text-sky-900/70">Compras aguardando conferência</span></span></button>
    </section>

    <section className="grid gap-5 xl:grid-cols-[1.25fr_0.75fr]">
      {canViewFinancial ? <article className="overflow-hidden rounded-2xl border border-black/10 bg-white shadow-sm"><ChartHeader eyebrow="Compras / 6 meses" title="Evolução do valor comprado" icon={TrendingUp} /><div className="h-72 p-5">{charts?.purchaseTrend.length ? <ResponsiveContainer width="100%" height="100%"><AreaChart data={charts.purchaseTrend}><XAxis dataKey="label" /><YAxis /><Tooltip formatter={(value: number) => formatCurrency(value)} /><Area type="monotone" dataKey="total" stroke="#7e258d" fill="#f4eafa" /></AreaChart></ResponsiveContainer> : <p className="grid h-full place-items-center text-sm text-black/50">Nenhuma compra registrada no período.</p>}</div></article> : null}
      <article className="overflow-hidden rounded-2xl border border-black/10 bg-white shadow-sm"><ChartHeader eyebrow="Pedidos de saída" title="Situação da operação" icon={ClipboardCheck} /><div className="flex h-72 items-center gap-4 p-5">{statusData.length ? <><div className="h-full min-w-0 flex-1"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={statusData} dataKey="total" nameKey="name" innerRadius="58%" outerRadius="82%" paddingAngle={3}>{statusData.map((row, index) => <Cell key={row.status} fill={statusColors[index]} />)}</Pie><Tooltip formatter={(value: number) => [value, "Pedidos"]} contentStyle={{ borderRadius: 12, borderColor: "#7e258d" }} /></PieChart></ResponsiveContainer></div><div className="space-y-3 text-xs">{statusData.map((row, index) => <div key={row.status} className="flex items-center gap-2"><span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: statusColors[index] }} /><span className="text-black/60">{row.name}</span><strong className="ml-auto">{row.total}</strong></div>)}</div></> : <p className="w-full text-center text-sm text-black/50">Nenhum pedido de saída registrado.</p>}</div></article>
    </section>

    <section className="grid gap-5 xl:grid-cols-[0.82fr_1.18fr]">
      {canViewFinancial ? <article className="overflow-hidden rounded-2xl border border-black/10 bg-white shadow-sm"><ChartHeader eyebrow="Fornecedores" title="Maiores compras por parceiro" icon={UsersRound} /><div className="h-72 p-5">{charts?.topSuppliers.length ? <ResponsiveContainer width="100%" height="100%"><BarChart data={charts.topSuppliers}><XAxis dataKey="name" /><YAxis /><Tooltip formatter={(value: number) => formatCurrency(value)} /><Bar dataKey="total" fill="#83c7df" /></BarChart></ResponsiveContainer> : <p className="grid h-full place-items-center text-sm text-black/50">Nenhuma compra vinculada a fornecedor.</p>}</div></article> : null}
      {canViewFinancial ? <article className="overflow-hidden rounded-2xl border border-black/10 bg-white shadow-sm"><ChartHeader eyebrow="Compras / últimas" title="Pedidos importados recentemente" icon={Landmark} /><div className="overflow-x-auto"><table className="data-table min-w-[650px]"><thead><tr><th>Data</th><th>Fornecedor</th><th>NF</th><th>Empresa</th><th className="text-right">Total</th></tr></thead><tbody>{data?.recentPurchases.length ? data.recentPurchases.map(row => <tr key={row.id}><td>{formatDate(row.orderDate)}</td><td className="font-bold">{row.supplierName ?? "Não informado"}</td><td>{row.invoiceNumber ?? "—"}</td><td>{row.company ?? "—"}</td><td className="text-right font-bold">{formatCurrency(row.totalPrice)}</td></tr>) : <tr><td colSpan={5} className="py-12 text-center text-black/50">Nenhuma compra registrada.</td></tr>}</tbody></table></div></article> : null}
    </section>

    <section className="overflow-hidden rounded-2xl border border-black/10 bg-[#231126] text-white shadow-sm"><div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/15 p-5"><div><p className="section-kicker text-white/50">Movimentações / recentes</p><h2 className="mt-1 text-xl font-black tracking-[-0.05em]">Fluxo de estoque</h2></div><span className="rounded-full bg-white/10 px-3 py-1 text-xs font-bold text-white/70">Atualizado com as entradas confirmadas</span></div><div className="grid divide-y divide-white/10 md:grid-cols-3 md:divide-x md:divide-y-0">{data?.recentMovements.length ? data.recentMovements.slice(0, 3).map(movement => <div className="flex gap-3 p-5" key={movement.id}><span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-[#7e258d]"><ArrowDownRight className="h-4 w-4" /></span><div><p className="font-bold">{movement.materialName}</p><p className="mt-1 text-xs leading-5 text-white/55">{movement.reference ?? "Movimentação"} · {formatDateTime(movement.occurredAt)}</p><p className="mt-2 text-sm font-black">{formatQuantity(movement.quantity)}</p></div></div>) : <p className="col-span-3 p-6 text-sm text-white/60">As entradas e saídas de estoque aparecerão aqui após as operações confirmadas.</p>}</div></section>
  </div>;
}
