import { describe, expect, it } from "vitest";
import { canCancelSourceOutboundOrder, canDeleteOutboundOrder, canEditOutboundOrder } from "./OutboundOrders";

describe("ações administrativas de pedidos por status", () => {
  it("permite editar somente pedidos em rascunho", () => {
    expect(canEditOutboundOrder("draft")).toBe(true);
    expect(canEditOutboundOrder("picking")).toBe(false);
    expect(canEditOutboundOrder("cancelled")).toBe(false);
    expect(canEditOutboundOrder("dispatched")).toBe(false);
  });

  it("permite excluir pedidos manuais não expedidos e bloqueia pedidos de solicitação", () => {
    expect(canDeleteOutboundOrder("draft", null)).toBe(true);
    expect(canDeleteOutboundOrder("picking", null)).toBe(true);
    expect(canDeleteOutboundOrder("cancelled", null)).toBe(true);
    expect(canDeleteOutboundOrder("dispatched", null)).toBe(false);
    expect(canDeleteOutboundOrder("draft", 12)).toBe(false);
  });

  it("orienta cancelamento para pedidos de solicitação antes da expedição", () => {
    expect(canCancelSourceOutboundOrder("draft", 12)).toBe(true);
    expect(canCancelSourceOutboundOrder("picking", 12)).toBe(true);
    expect(canCancelSourceOutboundOrder("cancelled", 12)).toBe(false);
    expect(canCancelSourceOutboundOrder("dispatched", 12)).toBe(false);
  });
});
