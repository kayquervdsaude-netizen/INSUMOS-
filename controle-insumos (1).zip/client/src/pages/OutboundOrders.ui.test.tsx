// @vitest-environment jsdom
import "@testing-library/jest-dom/vitest";
import React from "react";
import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  mutations: { create: vi.fn(), startPicking: vi.fn(), updatePicking: vi.fn(), dispatch: vi.fn(), cancel: vi.fn(), update: vi.fn(), remove: vi.fn() },
}));

const detail = {
  id: 7,
  code: "PS-20260901-ABC123",
  recipientName: "Unidade Centro",
  recipientDocument: null,
  destination: "Enfermagem",
  contact: null,
  notes: null,
  status: "dispatched" as const,
  createdAt: new Date("2026-09-01T12:00:00Z"),
  pickingStartedAt: new Date("2026-09-01T12:10:00Z"),
  dispatchedAt: new Date("2026-09-01T13:00:00Z"),
  cancelledAt: null,
  items: [{ id: 3, materialId: 4, materialName: "Caixa 04", unit: "Und", requestedQuantity: "40.000", pickedQuantity: "40.000", unitCost: "3.50", availableStock: "60.000" }],
  statusHistory: [],
};

vi.mock("@/_core/hooks/useAuth", () => ({ useAuth: () => ({ user: { role: "admin" } }) }));
vi.mock("sonner", () => ({ toast: { error: vi.fn(), success: vi.fn() } }));
vi.mock("@/lib/trpc", () => ({
  trpc: {
    outboundOrders: {
      list: { useQuery: () => ({ data: [{ id: 7, code: detail.code, recipientName: detail.recipientName, destination: detail.destination, status: detail.status, createdAt: detail.createdAt, pickingStartedAt: detail.pickingStartedAt, dispatchedAt: detail.dispatchedAt, sourceRequestId: null, itemCount: 1, requestedQuantity: "40.000", pickedQuantity: "40.000", totalValue: "140.00", dispatchedValue: "140.00" }], isLoading: false }) },
      getById: { useQuery: () => ({ data: detail }) },
      report: { useQuery: () => ({ data: { summary: { orderCount: 1, requestedQuantity: "40.000", pickedQuantity: "40.000", requestedValue: "140.00", dispatchedValue: "140.00" }, statuses: [{ status: "dispatched", count: 1 }], materials: [{ materialId: 4, materialName: "Caixa 04", unit: "Und", quantity: "40.000", cost: "140.00" }], orders: [{ id: 7, code: detail.code, recipientName: detail.recipientName, createdAt: detail.createdAt, itemCount: 1, pickedQuantity: "40.000", requestedQuantity: "40.000", status: detail.status, totalValue: "140.00", dispatchedValue: "140.00", dispatchedAt: detail.dispatchedAt }] }, isLoading: false }) },
      create: { useMutation: () => ({ mutate: mocks.mutations.create, isPending: false }) },
      startPicking: { useMutation: () => ({ mutate: mocks.mutations.startPicking, isPending: false }) },
      updatePicking: { useMutation: () => ({ mutate: mocks.mutations.updatePicking, isPending: false }) },
      dispatch: { useMutation: () => ({ mutate: mocks.mutations.dispatch, isPending: false }) },
      cancel: { useMutation: () => ({ mutate: mocks.mutations.cancel, isPending: false }) },
      update: { useMutation: () => ({ mutate: mocks.mutations.update, isPending: false }) },
      remove: { useMutation: () => ({ mutate: mocks.mutations.remove, isPending: false }) },
    },
    materials: { list: { useQuery: () => ({ data: [] }) } },
    useUtils: () => ({ outboundOrders: { list: { invalidate: vi.fn() }, getById: { invalidate: vi.fn() } }, stock: { movements: { invalidate: vi.fn() } }, materials: { list: { invalidate: vi.fn() } }, dashboard: { overview: { invalidate: vi.fn() } } }),
  },
}));

import OutboundOrders from "./OutboundOrders";
import OutboundReports from "./OutboundReports";

describe("valores financeiros dos pedidos de saída", () => {
  afterEach(() => { cleanup(); window.history.replaceState({}, "", "/pedidos-saida"); });
  beforeEach(() => { Object.values(mocks.mutations).forEach(mutation => mutation.mockReset()); });

  it("exibe o valor de saída na fila operacional", () => {
    render(<OutboundOrders />);
    expect(screen.getByRole("button", { name: "Novo pedido" })).toBeVisible();
    expect(screen.getAllByRole("columnheader", { name: "Valor de saída" }).length).toBeGreaterThan(0);
    expect(screen.getAllByText(/140,00/).length).toBeGreaterThan(0);
  });

  it("exibe custo unitário, valor por item e total no detalhe", async () => {
    window.history.replaceState({}, "", "/pedidos-saida?pedido=7");
    render(<OutboundOrders />);
    expect(screen.getByText("Custo unitário de referência")).toBeVisible();
    expect(screen.getByText("Valor por item")).toBeVisible();
    expect(screen.getByText("Total do pedido")).toBeVisible();
    expect(screen.getAllByText("Valor de saída").length).toBeGreaterThan(0);
    expect(screen.getAllByText(/140,00/).length).toBeGreaterThan(0);
  });

  it("exibe valores solicitados e expedidos no relatório", () => {
    render(<OutboundReports />);
    expect(screen.getByText("Valor solicitado")).toBeVisible();
    expect(screen.getAllByText("Valor expedido").length).toBeGreaterThan(0);
    expect(screen.getAllByText("Valor de saída").length).toBeGreaterThan(0);
    expect(screen.getAllByText(/140,00/).length).toBeGreaterThan(0);
  });
});
