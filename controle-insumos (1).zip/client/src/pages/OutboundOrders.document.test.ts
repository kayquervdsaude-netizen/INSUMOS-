import { readFileSync } from "node:fs";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { DispatchDocument, type OutboundOrderDetail } from "./OutboundOrders";

const order: OutboundOrderDetail = {
  id: 18,
  code: "PS-20260826-AB12CD",
  recipientName: "Unidade Centro",
  recipientDocument: "00.000.000/0000-00",
  destination: "Setor de Enfermagem",
  contact: "Maria Silva",
  notes: "Separação conferida para entrega interna.",
  status: "dispatched",
  createdAt: new Date("2026-08-26T12:00:00.000Z"),
  pickingStartedAt: new Date("2026-08-26T13:00:00.000Z"),
  dispatchedAt: new Date("2026-08-26T14:00:00.000Z"),
  cancelledAt: null,
  items: [{ id: 2, materialId: 4, materialName: "Caixa 04", unit: "Und", requestedQuantity: "40.000", pickedQuantity: "40.000", unitCost: "3.50", availableStock: "30.000" }],
  statusHistory: [],
};

describe("comprovante interno de saída", () => {
  it("renderiza destinatário, itens, quantidades e aviso de documento não fiscal", () => {
    const markup = renderToStaticMarkup(createElement(DispatchDocument, { order }));
    expect(markup).toContain("Documento interno de saída");
    expect(markup).toContain("Não possui valor fiscal");
    expect(markup).toContain("PS-20260826-AB12CD");
    expect(markup).toContain("Unidade Centro");
    expect(markup).toContain("Caixa 04");
    expect(markup).toContain("40");
    expect(markup).toContain("Custo unit.");
    expect(markup).toContain("Valor de saída");
    expect(markup).toContain("R$\u00a0140,00");
  });

  it("mantém o comprovante como o único conteúdo visível no modo de impressão", () => {
    const stylesheet = readFileSync(new URL("../index.css", import.meta.url), "utf8");
    const pageSource = readFileSync(new URL("./OutboundOrders.tsx", import.meta.url), "utf8");
    expect(stylesheet).toContain("@media print");
    expect(stylesheet).toContain(".print-document, .print-document * { visibility: visible !important; }");
    expect(pageSource).toContain("selectedOrder && canViewFinancial ? <DispatchDocument");
  });

});
