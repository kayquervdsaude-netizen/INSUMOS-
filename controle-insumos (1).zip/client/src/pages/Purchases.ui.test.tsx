// @vitest-environment jsdom
import "@testing-library/jest-dom/vitest";
import React from "react";
import { cleanup, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ createEntry: vi.fn(), updateStatus: vi.fn(), toastError: vi.fn(), toastSuccess: vi.fn() }));

vi.mock("@/_core/hooks/useAuth", () => ({ useAuth: () => ({ user: { role: "admin" } }) }));
vi.mock("sonner", () => ({ toast: { error: mocks.toastError, success: mocks.toastSuccess } }));
vi.mock("@/lib/trpc", () => ({
  trpc: {
    purchases: {
      list: { useQuery: () => ({ data: [{ id: 21, source: "manual_entry", status: "received", stockAppliedAt: null, supplierName: "Fornecedor de teste", orderDate: new Date("2026-08-28T12:00:00Z"), invoiceNumber: "REC-21", company: "RVD", purchaseType: "Entrada manual", itemCount: 1, totalPrice: "14.00" }], isLoading: false }), invalidate: vi.fn() },
      details: { useQuery: () => ({ data: null, isLoading: false }) },
      createManualEntry: { useMutation: () => ({ mutate: mocks.createEntry, isPending: false }) },
      updateStatus: { useMutation: () => ({ mutate: mocks.updateStatus, isPending: false }) },
    },
    suppliers: { list: { useQuery: () => ({ data: [{ id: 2, name: "Fornecedor de teste" }] }) } },
    materials: { list: { useQuery: () => ({ data: [{ id: 12, sku: "INS-000012", name: "Caixa 04", unit: "Und" }] }), invalidate: vi.fn() } },
    stock: { movements: { invalidate: vi.fn() } },
    dashboard: { overview: { invalidate: vi.fn() } },
    useUtils: () => ({ purchases: { list: { invalidate: vi.fn() }, details: { invalidate: vi.fn() } }, materials: { list: { invalidate: vi.fn() } }, stock: { movements: { invalidate: vi.fn() } }, dashboard: { overview: { invalidate: vi.fn() } } }),
  },
}));

import Purchases from "./Purchases";

describe("formulário visual de entrada manual", () => {
  afterEach(() => cleanup());
  beforeEach(() => { mocks.createEntry.mockReset(); mocks.updateStatus.mockReset(); mocks.toastError.mockReset(); vi.stubGlobal("confirm", vi.fn(() => true)); });

  it("abre o diálogo, valida campos obrigatórios e envia um item selecionado por SKU", async () => {
    const user = userEvent.setup();
    render(<Purchases />);
    await user.click(screen.getByRole("button", { name: "Novo pedido de entrada" }));
    expect(screen.getByRole("heading", { name: "Pedido de entrada manual" })).toBeVisible();

    await user.click(screen.getByRole("button", { name: "Salvar entrada" }));
    expect(mocks.toastError).toHaveBeenCalledWith("Selecione o fornecedor.");

    await user.selectOptions(screen.getByLabelText("Fornecedor"), "2");
    await user.selectOptions(screen.getByLabelText("SKU e produto do item 1"), "12");
    await user.type(screen.getByLabelText("Quantidade do item 1"), "2");
    await user.type(screen.getByLabelText("Preço unitário do item 1"), "7.5");
    await user.click(screen.getByRole("button", { name: "Salvar entrada" }));

    expect(mocks.createEntry).toHaveBeenCalledWith(expect.objectContaining({ supplierId: 2, items: [{ materialId: 12, quantity: 2, unitPrice: 7.5 }] }));
  });

  it("permite avançar a compra até conferido e solicita confirmação para lançar saldo", async () => {
    const user = userEvent.setup();
    render(<Purchases />);
    const status = screen.getByLabelText("Status da compra 21");
    expect(screen.getByRole("option", { name: "Recebido" })).toBeVisible();
    expect(screen.getByRole("option", { name: "Aguardando conferência" })).toBeVisible();
    expect(screen.getByRole("option", { name: "Conferido" })).toBeVisible();
    await user.selectOptions(status, "awaiting_confirmation");
    expect(mocks.updateStatus).toHaveBeenCalledWith({ purchaseOrderId: 21, status: "awaiting_confirmation" });
    await user.selectOptions(status, "confirmed");
    expect(window.confirm).toHaveBeenCalled();
    expect(mocks.updateStatus).toHaveBeenCalledWith({ purchaseOrderId: 21, status: "confirmed" });
  });
});
