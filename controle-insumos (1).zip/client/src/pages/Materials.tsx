import { useMemo, useState } from "react";
import { Eye, Plus, Search, SquarePen } from "lucide-react";
import { toast } from "sonner";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { formatCurrency, formatQuantity } from "@/lib/format";
import { useAuth } from "@/_core/hooks/useAuth";

type MaterialRow = { id: number; sku: string | null; name: string; category: string | null; unit: string; defaultSupplierId: number | null; supplierName: string | null; averageCost: string | number; stockQuantity: string | number; minimumStock: string | number; criticalStock: string | number; status: "active" | "inactive" };
type MaterialDraft = { name: string; category: string; unit: string; defaultSupplierId: string; averageCost: string; stockQuantity: string; minimumStock: string; criticalStock: string; status: "active" | "inactive" };

const blankDraft: MaterialDraft = { name: "", category: "", unit: "Und", defaultSupplierId: "", averageCost: "0", stockQuantity: "0", minimumStock: "0", criticalStock: "0", status: "active" };

export default function Materials() {
  const { user } = useAuth();
  const canEdit = user?.role === "admin";
  const canViewFinancial = canEdit || user?.role === "diretoria";
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");
  const [status, setStatus] = useState<"all" | "active" | "inactive">("active");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<MaterialRow | null>(null);
  const [detailMaterial, setDetailMaterial] = useState<MaterialRow | null>(null);
  const [draft, setDraft] = useState<MaterialDraft>(blankDraft);
  const lowStockOnly = new URLSearchParams(window.location.search).get("baixoEstoque") === "1";
  const stockLevel = new URLSearchParams(window.location.search).get("nivel");
  const input = useMemo(() => ({ search: search || undefined, category: category === "all" ? undefined : category, status: status === "all" ? undefined : status }), [search, category, status]);
  const { data: rows = [], isLoading } = trpc.materials.list.useQuery(input);
  const visibleRows = lowStockOnly ? rows.filter(row => stockLevel === "critico" ? Number(row.stockQuantity) <= Number(row.criticalStock) : Number(row.stockQuantity) > Number(row.criticalStock) && Number(row.stockQuantity) <= Number(row.minimumStock)) : rows;
  const { data: suppliers = [] } = trpc.suppliers.list.useQuery(undefined, { enabled: canEdit });
  const utils = trpc.useUtils();
  const createMutation = trpc.materials.create.useMutation({ onSuccess: async () => { await utils.materials.list.invalidate(); await utils.dashboard.overview.invalidate(); toast.success("Insumo cadastrado."); setDialogOpen(false); } });
  const updateMutation = trpc.materials.update.useMutation({ onSuccess: async () => { await utils.materials.list.invalidate(); toast.success("Insumo atualizado."); setDialogOpen(false); } });
  const categories = Array.from(new Set(visibleRows.map(row => row.category).filter((value): value is string => Boolean(value))));

  const openEditor = (material?: MaterialRow) => {
    setEditing(material ?? null);
    setDraft(material ? { name: material.name, category: material.category ?? "", unit: material.unit, defaultSupplierId: material.defaultSupplierId?.toString() ?? "", averageCost: String(material.averageCost), stockQuantity: String(material.stockQuantity), minimumStock: String(material.minimumStock), criticalStock: String(material.criticalStock), status: material.status } : blankDraft);
    setDialogOpen(true);
  };

  const submit = () => {
    if (!draft.name.trim()) return toast.error("Informe o nome do insumo.");
    const data = { name: draft.name, category: draft.category || null, unit: draft.unit, defaultSupplierId: draft.defaultSupplierId ? Number(draft.defaultSupplierId) : null, averageCost: Number(draft.averageCost) || 0, stockQuantity: Number(draft.stockQuantity) || 0, minimumStock: Number(draft.minimumStock) || 0, criticalStock: Number(draft.criticalStock) || 0, status: draft.status };
    if (editing) updateMutation.mutate({ id: editing.id, data }); else createMutation.mutate(data);
  };

  return <div className="page-stack">
    <PageHeader eyebrow="Cadastros / 02" title="Insumos" description="Catálogo operacional com custo médio, fornecedor principal e leitura de disponibilidade em estoque." action={canEdit ? <Button className="button-red" onClick={() => openEditor()}><Plus className="h-4 w-4" /> Novo insumo</Button> : undefined} />
    <section className="grid gap-px border border-black bg-black md:grid-cols-[minmax(0,1fr)_13rem_11rem]">
      <label className="flex items-center gap-3 bg-white px-4"><Search className="h-4 w-4" /><Input className="h-12 border-0 bg-transparent shadow-none focus-visible:ring-0" placeholder="Pesquisar por insumo ou SKU" value={search} onChange={event => setSearch(event.target.value)} /></label>
      <select className="h-14 bg-white px-4 text-sm font-bold outline-none" value={category} onChange={event => setCategory(event.target.value)}><option value="all">Todas as categorias</option>{categories.map(item => <option key={item} value={item}>{item}</option>)}</select>
      <select className="h-14 bg-white px-4 text-sm font-bold outline-none" value={status} onChange={event => setStatus(event.target.value as typeof status)}><option value="all">Todos os status</option><option value="active">Ativos</option><option value="inactive">Inativos</option></select>
    </section>
    <section className="overflow-hidden border border-black bg-white">
      <div className="overflow-x-auto"><table className="data-table min-w-[780px]"><thead><tr><th>SKU</th><th>Insumo</th><th>Categoria</th><th>Unidade</th>{canViewFinancial ? <><th>Fornecedor</th><th className="text-right">Custo médio</th></> : null}<th className="text-right">Em estoque</th><th>Status</th><th aria-label="Ações" /></tr></thead><tbody>
        {isLoading ? <tr><td colSpan={canViewFinancial ? 9 : 7} className="py-12 text-center">Carregando cadastros…</td></tr> : visibleRows.length ? visibleRows.map(row => <tr key={row.id}><td className="font-mono text-xs font-bold text-[#7e258d]">{row.sku ?? "Gerando…"}</td><td className="font-bold">{row.name}</td><td>{row.category ?? "—"}</td><td>{row.unit}</td>{canViewFinancial ? <><td>{row.supplierName ?? "—"}</td><td className="text-right">{formatCurrency(row.averageCost)}</td></> : null}<td className={`text-right font-bold ${Number(row.stockQuantity) <= Number(row.minimumStock) ? "text-amber-700" : ""}`}>{formatQuantity(row.stockQuantity)}</td><td><span className={row.status === "active" ? "status-active" : "status-muted"}>{row.status === "active" ? "Ativo" : "Inativo"}</span></td><td className="text-right">{canEdit ? <span className="inline-flex gap-1"><button className="icon-button" aria-label={`Detalhar ${row.name}`} onClick={() => setDetailMaterial(row as MaterialRow)}><Eye className="h-4 w-4" /></button><button className="icon-button" aria-label={`Editar ${row.name}`} onClick={() => openEditor(row as MaterialRow)}><SquarePen className="h-4 w-4" /></button></span> : null}</td></tr>) : <tr><td colSpan={canViewFinancial ? 9 : 7} className="py-12 text-center text-black/55">{lowStockOnly ? "Nenhum insumo abaixo do estoque mínimo." : "Nenhum insumo localizado."}</td></tr>}
      </tbody></table></div>
    </section>
    {canViewFinancial ? <Dialog open={Boolean(detailMaterial)} onOpenChange={open => !open && setDetailMaterial(null)}><DialogContent className="max-w-2xl rounded-none border-2 border-black bg-white"><DialogHeader><DialogTitle className="text-2xl font-black tracking-[-0.05em]">Detalhes completos do insumo</DialogTitle></DialogHeader>{detailMaterial ? <div className="space-y-5"><div className="border-b border-black pb-4"><p className="font-mono text-sm font-bold text-[#7e258d]">{detailMaterial.sku ?? "SKU pendente"}</p><h3 className="mt-2 text-3xl font-black tracking-[-0.06em]">{detailMaterial.name}</h3><p className="mt-2 text-sm text-black/60">Cadastro operacional com posição atual, parâmetros de reposição e dados comerciais.</p></div><div className="grid gap-px border border-black bg-black sm:grid-cols-2"><p className="bg-white p-4"><span className="section-kicker block text-black/50">Categoria / unidade</span><strong className="mt-2 block">{detailMaterial.category ?? "Sem categoria"} · {detailMaterial.unit}</strong></p><p className="bg-white p-4"><span className="section-kicker block text-black/50">Status</span><strong className="mt-2 block">{detailMaterial.status === "active" ? "Ativo" : "Inativo"}</strong></p><p className="bg-[#f4eafa] p-4"><span className="section-kicker block text-[#571c68]/70">Saldo atual</span><strong className="mt-2 block text-2xl">{formatQuantity(detailMaterial.stockQuantity)} {detailMaterial.unit}</strong></p><p className="bg-[#f4eafa] p-4"><span className="section-kicker block text-[#571c68]/70">Estoque mínimo</span><strong className="mt-2 block text-2xl">{formatQuantity(detailMaterial.minimumStock)} {detailMaterial.unit}</strong></p><p className="bg-red-50 p-4"><span className="section-kicker block text-red-900/65">Estoque crítico</span><strong className="mt-2 block text-2xl text-red-900">{formatQuantity(detailMaterial.criticalStock)} {detailMaterial.unit}</strong></p><p className="bg-[#231126] p-4 text-white"><span className="section-kicker block text-white/60">Custo médio</span><strong className="mt-2 block text-2xl">{formatCurrency(detailMaterial.averageCost)}</strong></p><p className="bg-white p-4"><span className="section-kicker block text-black/50">Fornecedor principal</span><strong className="mt-2 block">{detailMaterial.supplierName ?? "Não definido"}</strong></p></div><div className="flex justify-end"><Button variant="outline" className="rounded-none border-black" onClick={() => setDetailMaterial(null)}>Fechar</Button></div></div> : null}</DialogContent></Dialog> : null}
    {canEdit ? <Dialog open={dialogOpen} onOpenChange={setDialogOpen}><DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto rounded-none border-2 border-black bg-white"><DialogHeader><DialogTitle className="text-2xl font-black tracking-[-0.05em]">{editing ? "Editar insumo" : "Novo insumo"}</DialogTitle></DialogHeader><div className="form-grid pt-4">
      <label className="form-label col-span-full">Nome<input value={draft.name} onChange={event => setDraft({ ...draft, name: event.target.value })} /></label>
      <label className="form-label">Categoria<input value={draft.category} onChange={event => setDraft({ ...draft, category: event.target.value })} placeholder="Ex.: Insumos Operacional" /></label>
      <label className="form-label">Unidade<input value={draft.unit} onChange={event => setDraft({ ...draft, unit: event.target.value })} /></label>
      <label className="form-label col-span-full">Fornecedor principal<select value={draft.defaultSupplierId} onChange={event => setDraft({ ...draft, defaultSupplierId: event.target.value })}><option value="">Não definido</option>{suppliers.map(supplier => <option key={supplier.id} value={supplier.id}>{supplier.name}</option>)}</select></label>
      <label className="form-label">Custo médio (R$)<input type="number" min="0" step="0.01" value={draft.averageCost} onChange={event => setDraft({ ...draft, averageCost: event.target.value })} /></label>
      <label className="form-label">Saldo inicial / ajuste<input type="number" min="0" step="0.001" value={draft.stockQuantity} onChange={event => setDraft({ ...draft, stockQuantity: event.target.value })} /></label>
      <label className="form-label">Estoque mínimo<input type="number" min="0" step="0.001" value={draft.minimumStock} onChange={event => setDraft({ ...draft, minimumStock: event.target.value })} /></label>
      <label className="form-label">Estoque crítico<input type="number" min="0" step="0.001" value={draft.criticalStock} onChange={event => setDraft({ ...draft, criticalStock: event.target.value })} /></label>
      <label className="form-label">Status<select value={draft.status} onChange={event => setDraft({ ...draft, status: event.target.value as MaterialDraft["status"] })}><option value="active">Ativo</option><option value="inactive">Inativo</option></select></label>
      <div className="col-span-full mt-2 flex justify-end gap-3"><Button variant="outline" className="rounded-none border-black" onClick={() => setDialogOpen(false)}>Cancelar</Button><Button className="button-red" disabled={createMutation.isPending || updateMutation.isPending} onClick={submit}>{editing ? "Salvar alterações" : "Cadastrar insumo"}</Button></div>
    </div></DialogContent></Dialog> : null}
  </div>;
}
