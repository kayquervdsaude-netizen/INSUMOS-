import { Snowflake } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { trpc } from "@/lib/trpc";
import { formatCurrency, formatQuantity } from "@/lib/format";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Refrigerated() {
  const { user } = useAuth();
  const canViewFinancial = user?.role === "admin" || user?.role === "diretoria";
  const { data: rows = [], isLoading } = trpc.refrigerated.list.useQuery();
  const totalQuantity = rows.reduce((sum, row) => sum + Number(row.totalQuantity), 0);
  const totalValue = rows.reduce((sum, row) => sum + Number(row.totalConsumptionValue), 0);
  return <div className="page-stack"><PageHeader eyebrow="Indicadores / 07" title="Insumos refrigerados" description="Resumo histórico preservado da aba Insumos Refrigerados, com quantidade total e valor total de consumo por material." />
    <section className={`grid gap-px border border-black bg-black ${canViewFinancial ? "lg:grid-cols-2" : "lg:grid-cols-1"}`}><div className="bg-white p-6"><p className="section-kicker">Quantidade total</p><p className="mt-4 text-5xl font-black tracking-[-0.07em]">{formatQuantity(totalQuantity)}</p><p className="mt-2 text-xs text-black/55">Soma consolidada dos insumos refrigerados</p></div>{canViewFinancial ? <div className="bg-red-600 p-6 text-white"><p className="section-kicker text-white/70">Valor total de consumo</p><p className="mt-4 text-5xl font-black tracking-[-0.07em]">{formatCurrency(totalValue)}</p><p className="mt-2 text-xs text-white/75">Base histórica importada da planilha</p></div> : null}</section>
    <section className="overflow-hidden border border-black bg-white"><div className="flex items-center justify-between border-b border-black p-5"><div><p className="section-kicker">Visão analítica</p><h2 className="mt-1 text-xl font-black tracking-[-0.05em]">Consumo por insumo</h2></div><Snowflake className="h-5 w-5 text-red-600" /></div><div className="overflow-x-auto"><table className="data-table min-w-[720px]"><thead><tr><th>Insumo</th><th className="text-right">Quantidade total</th>{canViewFinancial ? <><th className="text-right">Valor total de consumo</th><th className="text-right">Custo médio histórico</th></> : null}</tr></thead><tbody>{isLoading ? <tr><td colSpan={canViewFinancial ? 4 : 2} className="py-12 text-center">Carregando indicadores…</td></tr> : rows.length ? rows.map(row => <tr key={row.id}><td className="font-bold">{row.materialName ?? row.materialLabel}</td><td className="text-right">{formatQuantity(row.totalQuantity)}</td>{canViewFinancial ? <><td className="text-right font-bold">{formatCurrency(row.totalConsumptionValue)}</td><td className="text-right">{Number(row.totalQuantity) ? formatCurrency(Number(row.totalConsumptionValue) / Number(row.totalQuantity)) : "—"}</td></> : null}</tr>) : <tr><td colSpan={canViewFinancial ? 4 : 2} className="py-12 text-center text-black/55">{canViewFinancial ? "Não há indicadores refrigerados disponíveis." : "Nenhum indicador refrigerado disponível para este perfil."}</td></tr>}</tbody></table></div></section>
  </div>;
}
