import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import { useEffect, type ReactNode } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "./components/DashboardLayout";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Dashboard from "./pages/Dashboard";
import Invoices from "./pages/Invoices";
import Login from "./pages/Login";
import Materials from "./pages/Materials";
import Movements from "./pages/Movements";
import NotFound from "./pages/NotFound";
import Purchases from "./pages/Purchases";
import Refrigerated from "./pages/Refrigerated";
import AccountSecurity from "./pages/AccountSecurity";
import OutboundOrders from "./pages/OutboundOrders";
import OutboundReports from "./pages/OutboundReports";
import StockRequests from "./pages/StockRequests";
import Suppliers from "./pages/Suppliers";
import Team from "./pages/Team";
import Privacy from "./pages/Privacy";
import StockAudits from "./pages/StockAudits";

function DashboardRoute() { return <DashboardLayout><Dashboard /></DashboardLayout>; }
function MaterialsRoute() { return <DashboardLayout><Materials /></DashboardLayout>; }
function AdminRoute({ children }: { children: ReactNode }) {
  const { loading, user } = useAuth();
  const [, setLocation] = useLocation();
  useEffect(() => {
    if (!loading && user && user.role !== "admin" && user.role !== "diretoria") setLocation("/");
  }, [loading, setLocation, user]);
  return <DashboardLayout>{!loading && (user?.role === "admin" || user?.role === "diretoria") ? children : null}</DashboardLayout>;
}
function InvoicesRoute() { return <AdminRoute><Invoices /></AdminRoute>; }
function SuppliersRoute() { return <AdminRoute><Suppliers /></AdminRoute>; }
function TeamRoute() {
  const { loading, user } = useAuth();
  const [, setLocation] = useLocation();
  useEffect(() => { if (!loading && user && !user.isOwner) setLocation("/"); }, [loading, setLocation, user]);
  return <DashboardLayout>{!loading && user?.isOwner ? <Team /> : null}</DashboardLayout>;
}
function PurchasesRoute() { return <DashboardLayout><Purchases /></DashboardLayout>; }
function RefrigeratedRoute() { return <DashboardLayout><Refrigerated /></DashboardLayout>; }
function MovementsRoute() { return <DashboardLayout><Movements /></DashboardLayout>; }
function StockRequestsRoute() { return <DashboardLayout><StockRequests /></DashboardLayout>; }
function AccountSecurityRoute() { return <DashboardLayout><AccountSecurity /></DashboardLayout>; }
function OutboundOrdersRoute() { return <DashboardLayout><OutboundOrders /></DashboardLayout>; }
function OutboundReportsRoute() { return <DashboardLayout><OutboundReports /></DashboardLayout>; }
function PrivacyRoute() { return <DashboardLayout><Privacy /></DashboardLayout>; }
function StockAuditsRoute() { return <AdminRoute><StockAudits /></AdminRoute>; }

function Router() {
  return <Switch>
    <Route path="/" component={DashboardRoute} />
    <Route path="/login" component={Login} />
    <Route path="/insumos" component={MaterialsRoute} />
    <Route path="/notas" component={InvoicesRoute} />
    <Route path="/fornecedores" component={SuppliersRoute} />
    <Route path="/equipe" component={TeamRoute} />
    <Route path="/compras" component={PurchasesRoute} />
    <Route path="/refrigerados" component={RefrigeratedRoute} />
    <Route path="/movimentacoes" component={MovementsRoute} />
    <Route path="/solicitacoes" component={StockRequestsRoute} />
    <Route path="/seguranca" component={AccountSecurityRoute} />
    <Route path="/pedidos-saida" component={OutboundOrdersRoute} />
    <Route path="/relatorios-saida" component={OutboundReportsRoute} />
    <Route path="/privacidade" component={PrivacyRoute} />
    <Route path="/auditoria" component={StockAuditsRoute} />
    <Route path="/404" component={NotFound} />
    <Route component={NotFound} />
  </Switch>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="system" switchable><TooltipProvider><Toaster /><Router /></TooltipProvider></ThemeProvider></ErrorBoundary>;
}
