import { beforeEach, describe, expect, it, vi } from "vitest";
import { COOKIE_NAME } from "@shared/const";

const mocks = vi.hoisted(() => ({
  getUserByOpenId: vi.fn(),
  upsertUser: vi.fn(),
}));

vi.mock("./db", () => mocks);

import { sdk } from "./_core/sdk";

const requestFor = (token: string) => ({ headers: { cookie: `${COOKIE_NAME}=${token}` } }) as never;

describe("revogação de sessões", () => {
  beforeEach(() => {
    mocks.getUserByOpenId.mockReset();
    mocks.upsertUser.mockReset();
  });

  it("rejeita token legado sem sessionVersion em procedimento protegido", async () => {
    mocks.getUserByOpenId.mockResolvedValue({ id: 4, openId: "password:user-4", name: "Colaborador", role: "user", sessionVersion: 1 });
    const token = await sdk.signSession({ openId: "password:user-4", appId: "app", name: "Colaborador" });
    await expect(sdk.authenticateRequest(requestFor(token))).rejects.toThrow("Session revoked");
  });

  it("rejeita token com versão anterior após revogação", async () => {
    mocks.getUserByOpenId.mockResolvedValue({ id: 4, openId: "password:user-4", name: "Colaborador", role: "user", sessionVersion: 3 });
    const token = await sdk.signSession({ openId: "password:user-4", appId: "app", name: "Colaborador", sessionVersion: 2 });
    await expect(sdk.authenticateRequest(requestFor(token))).rejects.toThrow("Session revoked");
  });

  it("aceita token que corresponda à versão persistida", async () => {
    const user = { id: 4, openId: "password:user-4", name: "Colaborador", role: "user", sessionVersion: 3, email: "colaborador@empresa.com", loginMethod: "password", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() };
    mocks.getUserByOpenId.mockResolvedValue(user);
    const token = await sdk.signSession({ openId: user.openId, appId: "app", name: user.name, sessionVersion: 3 });
    await expect(sdk.authenticateRequest(requestFor(token))).resolves.toMatchObject({ id: 4, sessionVersion: 3 });
  });
});
