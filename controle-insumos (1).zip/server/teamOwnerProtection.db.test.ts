import { describe, expect, it, vi } from "vitest";
import { deleteCollaborator, resetUserPasswordByAdmin, updateCollaboratorRole } from "./db";
import { ENV } from "./_core/env";

function query(rows: unknown[]) {
  const result = Object.assign(Promise.resolve(rows), { limit: async () => rows });
  const chain = { where: () => result };
  return { from: () => chain };
}

describe("proteção da conta proprietária nos serviços de equipe", () => {
  const ownerOpenId = ENV.ownerOpenId;
  const adminInput = { actorUserId: 8, actorOpenId: "additional-admin" };

  it("bloqueia a redefinição de senha da conta proprietária por outro administrador", async () => {
    const database = { select: vi.fn().mockReturnValue(query([{ id: 1, openId: ownerOpenId }])) };
    await expect(resetUserPasswordByAdmin({ ...adminInput, userId: 1, password: "Senha-nova-2026" }, { db: database as never })).rejects.toThrow("conta proprietária");
  });

  it("bloqueia a alteração de perfil da conta proprietária por outro administrador", async () => {
    const database = { select: vi.fn().mockReturnValue(query([{ openId: ownerOpenId }])) };
    await expect(updateCollaboratorRole({ ...adminInput, kind: "user", id: 1, role: "user" }, { db: database as never })).rejects.toThrow("conta proprietária");
  });

  it("bloqueia a exclusão da conta proprietária por outro administrador", async () => {
    const transaction = { select: vi.fn().mockReturnValue(query([{ id: 1, openId: ownerOpenId, role: "admin", email: "owner@empresa.com" }])) };
    const database = { transaction: vi.fn(callback => callback(transaction)) };
    await expect(deleteCollaborator({ kind: "user", id: 1, actorUserId: 8 }, { db: database as never })).rejects.toThrow("administrador proprietário");
  });
});
