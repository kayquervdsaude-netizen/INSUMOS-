import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { ENV } from "./_core/env";

function createAdminContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: ENV.ownerOpenId,
      name: "Administrador",
      email: "admin@example.com",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {} as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("validação controlada dos formulários", () => {
  it("rejeita o envio de colaborador com e-mail inválido antes de tocar no banco", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    await expect(caller.team.create({ name: "Ana Souza", email: "email-invalido", role: "user" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejeita a baixa com quantidade inválida antes de tocar no estoque", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    await expect(caller.stock.recordExit({ materialId: 1, quantity: 0, reason: "Uso interno" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejeita estoque crítico acima do estoque mínimo", async () => {
    const caller = appRouter.createCaller(createAdminContext());
    await expect(caller.materials.create({ name: "Material de teste", unit: "Und", minimumStock: 5, criticalStock: 8 })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});
