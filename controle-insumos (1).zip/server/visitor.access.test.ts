import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({
  getOrCreateVisitor: vi.fn(),
  listRefrigeratedUsage: vi.fn(),
  createStockRequest: vi.fn(),
  createSessionToken: vi.fn(),
}));

vi.mock("./db", () => mocks);
vi.mock("./_core/sdk", () => ({ sdk: { createSessionToken: mocks.createSessionToken } }));

import { appRouter } from "./routers";

const visitor = { id: 99, openId: "visitor:readonly", name: "Visitante", email: null, loginMethod: "visitor", role: "user" as const, sessionVersion: 1, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() };
const context = (user: typeof visitor = visitor): TrpcContext => ({ user, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: { cookie: vi.fn() } as unknown as TrpcContext["res"] });

describe("acesso visitante somente leitura", () => {
  beforeEach(() => Object.values(mocks).forEach(mock => mock.mockReset()));

  it("cria sessão visitante sem senha", async () => {
    mocks.getOrCreateVisitor.mockResolvedValue(visitor);
    mocks.createSessionToken.mockResolvedValue("visitor-session");
    const result = await appRouter.createCaller(context(null as never)).auth.visitorLogin();
    expect(result).toMatchObject({ openId: "visitor:readonly", loginMethod: "visitor" });
    expect(mocks.createSessionToken).toHaveBeenCalledWith("visitor:readonly", { name: "Visitante" });
  });

  it("rejeita solicitações para visitante antes de tocar no banco", async () => {
    await expect(appRouter.createCaller(context()).stockRequests.create({ materialId: 1, quantity: 2, reason: "Consulta" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(mocks.createStockRequest).not.toHaveBeenCalled();
  });

  it("não retorna dados de refrigerados", async () => {
    mocks.listRefrigeratedUsage.mockResolvedValue([{ id: 1, totalCost: "99.00" }]);
    await expect(appRouter.createCaller(context()).refrigerated.list()).resolves.toEqual([]);
    expect(mocks.listRefrigeratedUsage).not.toHaveBeenCalled();
  });
});
