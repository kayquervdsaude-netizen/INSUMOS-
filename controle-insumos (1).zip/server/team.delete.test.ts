import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({ deleteCollaborator: vi.fn(), recordAccessAudit: vi.fn() }));

vi.mock("./db", () => ({ deleteCollaborator: mocks.deleteCollaborator, recordAccessAudit: mocks.recordAccessAudit }));

import { appRouter } from "./routers";
import { ENV } from "./_core/env";

function createContext(options: { isOwner: boolean }): TrpcContext {
  return {
    user: { id: options.isOwner ? 1 : 2, openId: options.isOwner ? ENV.ownerOpenId : "other-admin", name: "Administrador", email: "admin@empresa.com", loginMethod: "password", role: "admin", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
    req: {} as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("team.remove", () => {
  beforeEach(() => mocks.deleteCollaborator.mockReset());

  it("permite que o proprietário remova uma conta", async () => {
    mocks.deleteCollaborator.mockResolvedValue({ kind: "user", id: 8 });
    await expect(appRouter.createCaller(createContext({ isOwner: true })).team.remove({ kind: "user", id: 8 })).resolves.toEqual({ kind: "user", id: 8 });
    expect(mocks.deleteCollaborator).toHaveBeenCalledWith({ kind: "user", id: 8, actorUserId: 1 });
  });

  it("bloqueia que outro administrador remova uma conta", async () => {
    mocks.deleteCollaborator.mockResolvedValue({ kind: "user", id: 8 });
    await expect(appRouter.createCaller(createContext({ isOwner: false })).team.remove({ kind: "user", id: 8 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(mocks.deleteCollaborator).not.toHaveBeenCalled();
  });
});
