export type CollaboratorRole = "admin" | "user" | "diretoria";

export function prepareCollaborator(input: { name: string; email: string; role: CollaboratorRole }) {
  return {
    name: input.name.trim(),
    email: input.email.trim().toLocaleLowerCase(),
    role: input.role,
  };
}

export function assertRoleChangeAllowed(input: { kind: "user" | "invite"; targetId: number; actorUserId: number }) {
  if (input.kind === "user" && input.targetId === input.actorUserId) {
    throw new Error("Seu próprio perfil administrativo não pode ser alterado nesta tela.");
  }
}

export function assertAdministratorDemotionAllowed(input: { currentRole: CollaboratorRole; nextRole: CollaboratorRole; administratorCount: number }) {
  if (input.currentRole === "admin" && input.nextRole !== "admin" && input.administratorCount <= 1) {
    throw new Error("Mantenha ao menos um administrador ativo no sistema.");
  }
}
