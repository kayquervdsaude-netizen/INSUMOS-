import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({ resetUserPasswordByAdmin: vi.fn(), recordAccessAudit: vi.fn() }));

vi.mock("./db", () => ({ resetUserPasswordByAdmin: mocks.resetUserPasswordByAdmin, recordAccessAudit: mocks.recordAccessAudit }));

import { appRouter } from "./routers";
import { ENV } from "./_core/env";

function createContext(role: "admin" | "user"): TrpcContext {
  return { user: { id: 1, openId: role === "admin" ? ENV.ownerOpenId : "collaborator", name: "Administrador", email: "admin@empresa.com", loginMethod: "password", role, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }, req: {} as TrpcContext["req"], res: {} as TrpcContext["res"] };
}

describe("team.resetPassword", () => {
  beforeEach(() => mocks.resetUserPasswordByAdmin.mockReset());

  it("permite que um administrador redefina a senha de outra conta", async () => {
    mocks.resetUserPasswordByAdmin.mockResolvedValue(undefined);
    await expect(appRouter.createCaller(createContext("admin")).team.resetPassword({ userId: 8, password: "Senha-nova-2026" })).resolves.toBeUndefined();
    expect(mocks.resetUserPasswordByAdmin).toHaveBeenCalledWith({ userId: 8, actorUserId: 1, actorOpenId: ENV.ownerOpenId, password: "Senha-nova-2026" });
  });

  it("bloqueia colaboradores antes de alcançar a operação de redefinição", async () => {
    await expect(appRouter.createCaller(createContext("user")).team.resetPassword({ userId: 8, password: "Senha-nova-2026" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(mocks.resetUserPasswordByAdmin).not.toHaveBeenCalled();
  });
});
