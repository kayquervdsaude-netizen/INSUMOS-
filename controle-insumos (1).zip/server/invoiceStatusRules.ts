export type InvoiceStatus = "draft" | "confirmed";

export function assertInvoiceStatusTransition(currentStatus: InvoiceStatus, nextStatus: InvoiceStatus) {
  if (currentStatus === "confirmed" && nextStatus === "draft") {
    throw new Error("Uma nota confirmada não pode voltar para conferência, pois a entrada já foi registrada no estoque.");
  }
}
