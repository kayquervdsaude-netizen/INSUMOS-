export type OutboundOrderStatus = "draft" | "picking" | "dispatched" | "cancelled";

export function assertOutboundOrderTransition(currentStatus: OutboundOrderStatus, nextStatus: OutboundOrderStatus) {
  const allowed: Record<OutboundOrderStatus, OutboundOrderStatus[]> = {
    draft: ["picking", "cancelled"],
    picking: ["dispatched", "cancelled"],
    dispatched: [],
    cancelled: [],
  };
  if (!allowed[currentStatus].includes(nextStatus)) throw new Error("Esta transição de status não é permitida para o pedido.");
}

export function assertOutboundOrderReadyForDispatch(input: { status: OutboundOrderStatus; items: Array<{ requestedQuantity: number; pickedQuantity: number }> }) {
  if (input.status !== "picking") throw new Error("O pedido deve estar em separação antes da expedição.");
  if (!input.items.length) throw new Error("O pedido não possui itens para expedição.");
  if (input.items.some(item => item.pickedQuantity !== item.requestedQuantity)) throw new Error("Todos os itens devem ser separados na quantidade solicitada antes da expedição.");
}
