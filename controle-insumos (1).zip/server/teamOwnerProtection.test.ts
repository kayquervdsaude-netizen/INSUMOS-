import { describe, expect, it } from "vitest";
import { assertOwnerAccountCanBeManaged } from "./teamOwnerProtection";

describe("proteção da conta proprietária", () => {
  it("bloqueia administrador adicional ao tentar gerenciar a conta proprietária", () => {
    expect(() => assertOwnerAccountCanBeManaged({ targetOpenId: "owner", actorOpenId: "other-admin", ownerOpenId: "owner" })).toThrow("conta proprietária");
  });

  it("permite ao proprietário gerenciar a própria conta e a outros administradores gerenciar contas não proprietárias", () => {
    expect(() => assertOwnerAccountCanBeManaged({ targetOpenId: "owner", actorOpenId: "owner", ownerOpenId: "owner" })).not.toThrow();
    expect(() => assertOwnerAccountCanBeManaged({ targetOpenId: "collaborator", actorOpenId: "other-admin", ownerOpenId: "owner" })).not.toThrow();
  });
});
