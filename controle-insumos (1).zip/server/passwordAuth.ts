import { randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";

const scrypt = promisify(scryptCallback);
const MIN_PASSWORD_LENGTH = 8;
const KEY_LENGTH = 64;

export function assertValidPassword(password: string) {
  if (password.length < MIN_PASSWORD_LENGTH) {
    throw new Error(`A senha deve ter ao menos ${MIN_PASSWORD_LENGTH} caracteres.`);
  }
  if (password.length > 128) {
    throw new Error("A senha deve ter no máximo 128 caracteres.");
  }
}

export async function hashPassword(password: string) {
  assertValidPassword(password);
  const salt = randomBytes(16).toString("base64url");
  const derivedKey = (await scrypt(password, salt, KEY_LENGTH)) as Buffer;
  return `scrypt$${salt}$${derivedKey.toString("base64url")}`;
}

export async function verifyPassword(password: string, storedHash: string) {
  const [algorithm, salt, encodedKey] = storedHash.split("$");
  if (algorithm !== "scrypt" || !salt || !encodedKey) return false;

  const expectedKey = Buffer.from(encodedKey, "base64url");
  const derivedKey = (await scrypt(password, salt, expectedKey.length)) as Buffer;
  return expectedKey.length === derivedKey.length && timingSafeEqual(expectedKey, derivedKey);
}
