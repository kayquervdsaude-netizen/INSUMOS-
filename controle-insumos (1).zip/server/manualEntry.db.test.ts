import { describe, expect, it, vi } from "vitest";
import { createManualEntry, updatePurchaseStatus } from "./db";

function query(rows: unknown[]) {
  const result = Object.assign(Promise.resolve(rows), { limit: async () => rows });
  return { from: () => ({ where: () => result }) };
}

describe("entrada manual de estoque", () => {
  it("cria pedido e itens como recebido, sem lançar saldo antes da conferência", async () => {
    const purchaseValues = vi.fn().mockReturnValue({ $returningId: async () => [{ id: 50 }] });
    const itemValues = vi.fn().mockResolvedValue(undefined);
    const tx = {
      select: vi.fn()
        .mockReturnValueOnce(query([{ id: 4 }]))
        .mockReturnValueOnce(query([{ id: 7, name: "Luva", unit: "Caixa", status: "active", stockQuantity: "10.000", averageCost: "2.00" }])),
      insert: vi.fn()
        .mockReturnValueOnce({ values: purchaseValues })
        .mockReturnValueOnce({ values: itemValues }),
      update: vi.fn(),
    };
    const database = { transaction: vi.fn(callback => callback(tx)) };

    await expect(createManualEntry({ supplierId: 4, entryDate: new Date("2026-08-26T12:00:00.000Z"), reference: "REC-20", company: "RVD", items: [{ materialId: 7, quantity: 5, unitPrice: 4 }] }, { db: database as never, skipInitialData: true })).resolves.toEqual({ id: 50, totalPrice: 20 });
    expect(purchaseValues).toHaveBeenCalledWith(expect.objectContaining({ source: "manual_entry", status: "received", supplierId: 4, invoiceNumber: "REC-20", totalPrice: "20.00" }));
    expect(itemValues).toHaveBeenCalledWith([expect.objectContaining({ purchaseOrderId: 50, materialId: 7, quantity: "5.000", unitPrice: "4.00" })]);
    expect(tx.update).not.toHaveBeenCalled();
  });

  it("lança saldo, custo médio e movimento uma única vez ao conferir", async () => {
    const materialSet = vi.fn().mockReturnValue({ where: async () => [{ affectedRows: 1 }] });
    const historyValues = vi.fn().mockResolvedValue(undefined);
    const movementValues = vi.fn().mockResolvedValue(undefined);
    const tx = {
      select: vi.fn()
        .mockReturnValueOnce(query([{ id: 50, status: "awaiting_confirmation", stockAppliedAt: null, supplierId: 4, invoiceNumber: "REC-20" }]))
        .mockReturnValueOnce(query([{ id: 7, materialId: 7, quantity: "5.000", unitPrice: "4.00" }]))
        .mockReturnValueOnce(query([{ id: 7, name: "Luva", unit: "Caixa", status: "active", stockQuantity: "10.000", averageCost: "2.00" }])),
      insert: vi.fn()
        .mockReturnValueOnce({ values: movementValues })
        .mockReturnValueOnce({ values: historyValues }),
      update: vi.fn().mockReturnValue({ set: materialSet }),
    };
    const database = { transaction: vi.fn(callback => callback(tx)) };

    await expect(updatePurchaseStatus(50, "confirmed", 99, { db: database as never, skipInitialData: true })).resolves.toEqual(expect.objectContaining({ status: "confirmed", stockAppliedAt: expect.any(Date) }));
    expect(materialSet).toHaveBeenCalledWith(expect.objectContaining({ stockQuantity: "15.000", averageCost: "2.67" }));
    expect(movementValues).toHaveBeenCalledWith(expect.objectContaining({ type: "entry", balanceAfter: "15.000", reference: "Compra #50 / NF REC-20" }));
    expect(historyValues).toHaveBeenCalledWith(expect.objectContaining({ previousStatus: "awaiting_confirmation", nextStatus: "confirmed", changedByUserId: 99 }));
    expect(tx.update).toHaveBeenCalledTimes(2);
  });

  it("não duplica movimentação ao confirmar novamente uma compra já aplicada", async () => {
    const tx = {
      select: vi.fn().mockReturnValueOnce(query([{ id: 51, status: "confirmed", stockAppliedAt: new Date("2026-08-28T12:00:00Z") }])),
      insert: vi.fn(),
      update: vi.fn(),
    };
    const database = { transaction: vi.fn(callback => callback(tx)) };
    await expect(updatePurchaseStatus(51, "confirmed", 99, { db: database as never, skipInitialData: true })).resolves.toEqual(expect.objectContaining({ id: 51, status: "confirmed" }));
    expect(tx.insert).not.toHaveBeenCalled();
    expect(tx.update).not.toHaveBeenCalled();
  });

  it("recusa itens repetidos antes de abrir uma transação", async () => {
    await expect(createManualEntry({ supplierId: 4, entryDate: new Date(), items: [{ materialId: 7, quantity: 1, unitPrice: 1 }, { materialId: 7, quantity: 2, unitPrice: 1 }] }, { db: {} as never, skipInitialData: true })).rejects.toThrow("apenas uma vez");
  });
});
