import { describe, expect, it, vi } from "vitest";
import { updateCollaboratorRole, type RoleUpdateRepository } from "./teamRoleUpdate";

function createRepository(options?: { role?: "admin" | "user" | null; administrators?: number }) {
  const repository: RoleUpdateRepository = {
    getUserRole: vi.fn().mockResolvedValue(options?.role ?? "user"),
    countAdministrators: vi.fn().mockResolvedValue(options?.administrators ?? 2),
    updateUserRole: vi.fn().mockResolvedValue(undefined),
    updateInviteRole: vi.fn().mockResolvedValue(undefined),
  };
  return repository;
}

describe("updateCollaboratorRole", () => {
  it("altera o perfil de um convite pendente", async () => {
    const repository = createRepository();
    await updateCollaboratorRole({ kind: "invite", id: 3, role: "admin", actorUserId: 1 }, repository);
    expect(repository.updateInviteRole).toHaveBeenCalledWith(3, "admin");
    expect(repository.updateUserRole).not.toHaveBeenCalled();
  });

  it("altera o perfil de um usuário existente", async () => {
    const repository = createRepository({ role: "user" });
    await updateCollaboratorRole({ kind: "user", id: 3, role: "admin", actorUserId: 1 }, repository);
    expect(repository.updateUserRole).toHaveBeenCalledWith(3, "admin");
  });

  it("bloqueia autoalteração e o rebaixamento do último administrador", async () => {
    await expect(updateCollaboratorRole({ kind: "user", id: 1, role: "user", actorUserId: 1 }, createRepository())).rejects.toThrow("próprio perfil administrativo");
    await expect(updateCollaboratorRole({ kind: "user", id: 3, role: "user", actorUserId: 1 }, createRepository({ role: "admin", administrators: 1 }))).rejects.toThrow("ao menos um administrador");
  });
});
