import { describe, expect, it } from "vitest";
import initialData from "./initial-data.json";
import { normalizeName } from "./db";

describe("dados iniciais importados da planilha", () => {
  it("preserva as quantidades esperadas e os campos essenciais de cada cadastro", () => {
    expect(initialData.suppliers).toHaveLength(20);
    expect(initialData.materials).toHaveLength(52);
    expect(initialData.purchases).toHaveLength(239);
    expect(initialData.refrigeratedUsage).toHaveLength(7);
    expect(initialData.suppliers.every(supplier => Boolean(supplier.name) && Object.hasOwn(supplier, "updatedAt"))).toBe(true);
    expect(initialData.materials.every(material => Boolean(material.name) && Boolean(material.unit))).toBe(true);
    expect(initialData.purchases.every(purchase => Boolean(purchase.materialName) && purchase.quantity > 0 && purchase.totalPrice >= 0)).toBe(true);
  });

  it("mantém chaves normalizadas únicas para os insumos cadastrados", () => {
    const keys = initialData.materials.map(material => normalizeName(material.name));
    expect(new Set(keys).size).toBe(keys.length);
  });
});
