import { describe, expect, it, vi } from "vitest";
import { createStockRequest, getOutboundOrderById, reviewStockRequest } from "./db";

function selectRows(rows: unknown[]) {
  const where = () => ({
    limit: async () => rows,
    orderBy: async () => rows,
  });
  return {
    from: () => ({
      where,
      leftJoin: () => ({ where }),
    }),
  };
}

function affectedRows(count: number) {
  return {
    set: () => ({
      where: async () => [{ affectedRows: count }],
    }),
  };
}

describe("operações persistentes de solicitações de retirada", () => {
  it("cria uma solicitação para 40 unidades quando o saldo disponível é suficiente", async () => {
    const values = vi.fn().mockReturnValue({ $returningId: async () => [{ id: 37 }] });
    const database = {
      select: vi.fn().mockReturnValue(selectRows([{ id: 4, stockQuantity: "100.000", status: "active" }])),
      insert: vi.fn().mockReturnValue({ values }),
    };

    await expect(
      createStockRequest(
        { materialId: 4, requestedByUserId: 9, quantity: 40, reason: "Uso interno", notes: "Setor de embalagem" },
        { db: database as never, skipInitialData: true }
      )
    ).resolves.toEqual({ id: 37 });
    expect(values).toHaveBeenCalledWith(expect.objectContaining({ materialId: 4, requestedByUserId: 9, quantity: "40.000" }));
  });

  it("bloqueia a criação quando a quantidade é maior que o saldo e não persiste o pedido", async () => {
    const values = vi.fn();
    const database = {
      select: vi.fn().mockReturnValue(selectRows([{ id: 4, stockQuantity: "20.000", status: "active" }])),
      insert: vi.fn().mockReturnValue({ values }),
    };

    await expect(
      createStockRequest(
        { materialId: 4, requestedByUserId: 9, quantity: 40, reason: "Uso interno" },
        { db: database as never, skipInitialData: true }
      )
    ).rejects.toThrow("saldo disponível");
    expect(values).not.toHaveBeenCalled();
  });

  it("aprova e cria o pedido de separação sem dar baixa imediata no estoque", async () => {
    const orderValues = vi.fn().mockReturnValue({ $returningId: async () => [{ id: 48 }] });
    const itemValues = vi.fn().mockResolvedValue(undefined);
    const historyValues = vi.fn().mockResolvedValue(undefined);
    const transaction = {
      select: vi
        .fn()
        .mockReturnValueOnce(selectRows([{ id: 12, materialId: 4, requestedByUserId: 9, quantity: "40.000", reason: "Uso interno", notes: "Setor de embalagem", status: "pending", requesterName: "Ana Silva", requesterEmail: "ana@empresa.com" }]))
        .mockReturnValueOnce(selectRows([{ id: 4, unit: "Und", averageCost: "5.00", stockQuantity: "60.000", status: "active" }])),
      update: vi.fn().mockReturnValue(affectedRows(1)),
      insert: vi.fn().mockReturnValueOnce({ values: orderValues }).mockReturnValueOnce({ values: itemValues }).mockReturnValueOnce({ values: historyValues }),
    };
    const database = { transaction: vi.fn(callback => callback(transaction)) };

    await expect(
      reviewStockRequest(
        { requestId: 12, decision: "approved", reviewedByUserId: 2, reviewerName: "Administrador" },
        { db: database as never, skipInitialData: true }
      )
    ).resolves.toEqual({ id: 12, status: "approved", outboundOrderId: 48 });
    expect(transaction.update).toHaveBeenCalledTimes(1);
    expect(orderValues).toHaveBeenCalledWith(expect.objectContaining({ recipientName: "Ana Silva", destination: "Uso interno", createdByUserId: 2 }));
    expect(itemValues).toHaveBeenCalledWith(expect.objectContaining({ outboundOrderId: 48, materialId: 4, requestedQuantity: "40.000", unit: "Und" }));
    expect(historyValues).toHaveBeenCalledWith(expect.objectContaining({ outboundOrderId: 48, nextStatus: "draft", changedByUserId: 2 }));
  });

  it("recusa sem criar pedido de separação nem movimentação de estoque", async () => {
    const values = vi.fn();
    const transaction = {
      select: vi.fn().mockReturnValue(selectRows([{ id: 12, materialId: 4, requestedByUserId: 9, quantity: "40.000", reason: "Uso interno", status: "pending" }])),
      update: vi.fn().mockReturnValue(affectedRows(1)),
      insert: vi.fn().mockReturnValue({ values }),
    };
    const database = { transaction: vi.fn(callback => callback(transaction)) };

    await expect(
      reviewStockRequest(
        { requestId: 12, decision: "rejected", reviewedByUserId: 2, reviewerName: "Administrador" },
        { db: database as never, skipInitialData: true }
      )
    ).resolves.toEqual({ id: 12, status: "rejected", outboundOrderId: null });
    expect(transaction.update).toHaveBeenCalledTimes(1);
    expect(values).not.toHaveBeenCalled();
  });

  it("bloqueia a aprovação sem saldo suficiente e não cria pedido", async () => {
    const values = vi.fn();
    const transaction = {
      select: vi
        .fn()
        .mockReturnValueOnce(selectRows([{ id: 12, materialId: 4, requestedByUserId: 9, quantity: "40.000", reason: "Uso interno", notes: null, status: "pending", requesterName: "Ana Silva", requesterEmail: "ana@empresa.com" }]))
        .mockReturnValueOnce(selectRows([{ id: 4, unit: "Und", averageCost: "5.00", stockQuantity: "20.000", status: "active" }])),
      update: vi.fn(),
      insert: vi.fn().mockReturnValue({ values }),
    };
    const database = { transaction: vi.fn(callback => callback(transaction)) };

    await expect(
      reviewStockRequest(
        { requestId: 12, decision: "approved", reviewedByUserId: 2, reviewerName: "Administrador" },
        { db: database as never, skipInitialData: true }
      )
    ).rejects.toThrow("saldo disponível");
    expect(values).not.toHaveBeenCalled();
  });

  it("recupera o pedido vinculado para abrir a picking list e imprimir o comprovante", async () => {
    const database = {
      select: vi
        .fn()
        .mockReturnValueOnce({ from: () => ({ where: () => ({ limit: async () => [{ id: 48, code: "PS-20260826-AB12CD", recipientName: "Ana Silva", status: "draft" }] }) }) })
        .mockReturnValueOnce({ from: () => ({ innerJoin: () => ({ where: () => ({ orderBy: async () => [{ id: 6, materialId: 4, materialName: "Caixa 04", unit: "Und", requestedQuantity: "40.000", pickedQuantity: "0.000", unitCost: "5.00", availableStock: "60.000" }] }) }) }) })
        .mockReturnValueOnce({ from: () => ({ leftJoin: () => ({ where: () => ({ orderBy: async () => [] }) }) }) }),
    };

    await expect(getOutboundOrderById(48, { db: database as never, skipInitialData: true })).resolves.toMatchObject({
      id: 48,
      code: "PS-20260826-AB12CD",
      recipientName: "Ana Silva",
      items: [expect.objectContaining({ materialName: "Caixa 04", requestedQuantity: "40.000" })],
    });
  });
});
