import { describe, expect, it } from "vitest";
import { assertPurchaseStatusTransition, purchaseStatusLabel, shouldApplyPurchaseStock } from "./purchaseStatusRules";

describe("regras de status de compras", () => {
  it("apresenta os três estados em português", () => {
    expect(purchaseStatusLabel("received")).toBe("Recebido");
    expect(purchaseStatusLabel("awaiting_confirmation")).toBe("Aguardando conferência");
    expect(purchaseStatusLabel("confirmed")).toBe("Conferido");
  });

  it("permite avançar e bloqueia voltar depois da conferência", () => {
    expect(() => assertPurchaseStatusTransition("received", "awaiting_confirmation")).not.toThrow();
    expect(() => assertPurchaseStatusTransition("awaiting_confirmation", "confirmed")).not.toThrow();
    expect(() => assertPurchaseStatusTransition("confirmed", "awaiting_confirmation")).toThrow();
    expect(() => assertPurchaseStatusTransition("awaiting_confirmation", "received")).toThrow();
  });

  it("aplica estoque apenas na confirmação e somente uma vez", () => {
    expect(shouldApplyPurchaseStock("received", null)).toBe(false);
    expect(shouldApplyPurchaseStock("awaiting_confirmation", null)).toBe(false);
    expect(shouldApplyPurchaseStock("confirmed", null)).toBe(true);
    expect(shouldApplyPurchaseStock("confirmed", new Date())).toBe(false);
  });
});
