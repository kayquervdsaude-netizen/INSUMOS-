import { describe, expect, it, vi } from "vitest";
import { deleteOutboundOrder, deleteStockRequest, updateOutboundOrder, updateStockRequest } from "./db";

function query(rows: unknown[]) {
  const result = Object.assign(Promise.resolve(rows), { limit: async () => rows });
  const chain = { where: () => result };
  return { from: () => chain };
}

describe("edição e exclusão segura de solicitações e pedidos", () => {
  it("impede editar solicitação já aprovada ou vinculada a pedido", async () => {
    const transaction = { select: vi.fn().mockReturnValue(query([{ status: "approved", outboundOrderId: 4 }])) };
    const database = { transaction: vi.fn(callback => callback(transaction)) };
    await expect(updateStockRequest(8, { materialId: 3, quantity: 2, reason: "Uso interno" }, { db: database as never, skipInitialData: true })).rejects.toThrow("pendentes");
  });

  it("impede excluir solicitação aprovada para preservar o pedido vinculado", async () => {
    const database = { select: vi.fn().mockReturnValue(query([{ status: "approved", outboundOrderId: 4 }])) };
    await expect(deleteStockRequest(8, { db: database as never, skipInitialData: true })).rejects.toThrow("não podem ser excluídas");
  });

  it("impede alterar ou excluir pedido após expedição", async () => {
    const updateTransaction = { select: vi.fn().mockReturnValue(query([{ status: "dispatched" }])) };
    const updateDatabase = { transaction: vi.fn(callback => callback(updateTransaction)) };
    await expect(updateOutboundOrder(4, { recipientName: "Setor", items: [{ materialId: 2, quantity: 1 }] }, { db: updateDatabase as never, skipInitialData: true })).rejects.toThrow("rascunho");

    const deleteTransaction = { select: vi.fn().mockReturnValue(query([{ id: 4, status: "dispatched" }])) };
    const deleteDatabase = { transaction: vi.fn(callback => callback(deleteTransaction)) };
    await expect(deleteOutboundOrder(4, { db: deleteDatabase as never, skipInitialData: true })).rejects.toThrow("expedidos");
  });

  it("impede excluir pedido originado de solicitação e orienta o cancelamento", async () => {
    const transaction = { select: vi.fn().mockReturnValueOnce(query([{ id: 4, status: "draft" }])).mockReturnValueOnce(query([{ id: 8 }])) };
    const database = { transaction: vi.fn(callback => callback(transaction)) };
    await expect(deleteOutboundOrder(4, { db: database as never, skipInitialData: true })).rejects.toThrow("Cancele o pedido");
  });
});
