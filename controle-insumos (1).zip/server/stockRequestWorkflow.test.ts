import { describe, expect, it } from "vitest";
import { assertStockRequestCanBeCreated, getStockRequestReviewOutcome } from "./stockRequestWorkflow";

describe("fluxo de solicitações de retirada", () => {
  it("aceita uma solicitação válida, como 40 unidades de Caixa 04 com saldo de 100", () => {
    expect(() => assertStockRequestCanBeCreated({ quantity: 40, availableStock: 100 })).not.toThrow();
  });

  it("bloqueia a criação quando a quantidade solicitada supera o saldo", () => {
    expect(() => assertStockRequestCanBeCreated({ quantity: 40, availableStock: 20 })).toThrow("saldo disponível");
  });

  it("aprova a solicitação para separação, sem dar baixa imediata", () => {
    expect(getStockRequestReviewOutcome({ decision: "approved", quantity: 40, availableStock: 100 })).toEqual({
      status: "approved",
      requiresPicking: true,
    });
  });

  it("recusa a solicitação sem iniciar separação", () => {
    expect(getStockRequestReviewOutcome({ decision: "rejected", quantity: 40, availableStock: 100 })).toEqual({
      status: "rejected",
      requiresPicking: false,
    });
  });

  it("bloqueia a aprovação quando o saldo já não é suficiente", () => {
    expect(() => getStockRequestReviewOutcome({ decision: "approved", quantity: 40, availableStock: 20 })).toThrow("saldo disponível");
  });
});
