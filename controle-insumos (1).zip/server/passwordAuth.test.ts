import { describe, expect, it } from "vitest";
import { assertValidPassword, hashPassword, verifyPassword } from "./passwordAuth";

describe("credenciais por senha", () => {
  it("gera um hash sem armazenar a senha em texto puro e valida a senha correta", async () => {
    const password = "Senha-forte-2026";
    const hash = await hashPassword(password);

    expect(hash).not.toContain(password);
    await expect(verifyPassword(password, hash)).resolves.toBe(true);
  });

  it("rejeita senha incorreta e hashes malformados", async () => {
    const hash = await hashPassword("Senha-forte-2026");
    await expect(verifyPassword("senha-incorreta", hash)).resolves.toBe(false);
    await expect(verifyPassword("Senha-forte-2026", "invalido")).resolves.toBe(false);
  });

  it("exige uma senha com pelo menos oito caracteres", () => {
    expect(() => assertValidPassword("1234567")).toThrow("ao menos 8 caracteres");
  });
});
