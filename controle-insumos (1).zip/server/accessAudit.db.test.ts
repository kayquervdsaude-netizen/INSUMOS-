import { describe, expect, it, vi } from "vitest";
import { recordAccessAudit } from "./db";

describe("registro de auditoria de acesso", () => {
  it("persiste apenas identificador do responsável, perfil e nome técnico da ação", async () => {
    const values = vi.fn().mockResolvedValue(undefined);
    const database = { insert: vi.fn().mockReturnValue({ values }) };

    await recordAccessAudit({ actorUserId: 12, role: "admin", action: "outboundOrders.dispatch" }, { db: database as never });

    expect(values).toHaveBeenCalledWith({ actorUserId: 12, role: "admin", action: "outboundOrders.dispatch" });
  });
});
