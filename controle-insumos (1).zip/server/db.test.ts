import { describe, expect, it } from "vitest";
import { normalizeName } from "./db";

describe("normalizeName", () => {
  it("remove acentos, unifica caixa e normaliza separadores", () => {
    expect(normalizeName("Etiqueta 100x70 – Lilás")).toBe("ETIQUETA 100X70 LILAS");
  });

  it("produz a mesma chave para descrições equivalentes de produto", () => {
    expect(normalizeName("CAIXA 1 (LLT)")).toBe(normalizeName("caixa-1 llt"));
  });
});
