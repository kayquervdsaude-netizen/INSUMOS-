export type TeamMemberKind = "user" | "invite";

type AccountTarget = { id: number; openId: string; email?: string | null; role: "admin" | "user" | "diretoria" } | null;

export type TeamDeletionRepository = {
  countAdministrators: () => Promise<number>;
};

export async function assertCollaboratorCanBeDeleted(
  input: { kind: TeamMemberKind; id: number; actorUserId: number; ownerOpenId: string },
  target: AccountTarget,
  repository: TeamDeletionRepository
) {
  if (input.kind === "invite") return;
  if (!target) throw new Error("Usuário não encontrado.");
  if (target.id === input.actorUserId || target.openId === input.ownerOpenId || target.email?.trim().toLowerCase() === "kayque.santos@rvdsaude.com.br") {
    throw new Error("A conta do administrador proprietário não pode ser excluída.");
  }
  if (target.role === "admin" && await repository.countAdministrators() <= 1) {
    throw new Error("Mantenha ao menos um administrador cadastrado antes de excluir esta conta.");
  }
}
