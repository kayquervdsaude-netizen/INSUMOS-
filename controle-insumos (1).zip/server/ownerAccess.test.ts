import { describe, expect, it } from "vitest";
import { ENV } from "./_core/env";
import { isOwnerIdentity } from "./ownerAccess";

describe("identidade do proprietário", () => {
  it("reconhece o e-mail kayque.santos@rvdsaude.com.br", () => {
    expect(isOwnerIdentity({ openId: "password:owner", email: "kayque.santos@rvdsaude.com.br" })).toBe(true);
  });

  it("mantém o reconhecimento por OWNER_OPEN_ID", () => {
    expect(isOwnerIdentity({ openId: ENV.ownerOpenId, email: "outro@example.com" })).toBe(true);
  });

  it("não promove outros administradores ao proprietário", () => {
    expect(isOwnerIdentity({ openId: "password:admin", email: "emily.oliveira@rvdsaude.com.br" })).toBe(false);
  });
});
