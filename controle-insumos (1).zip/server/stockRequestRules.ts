export type StockRequestStatus = "pending" | "approved" | "rejected";

type ReviewInput = {
  status: StockRequestStatus;
  requestedByUserId: number;
  reviewedByUserId: number;
  allowSelfReview?: boolean;
};

export function assertStockRequestCanBeReviewed(input: ReviewInput) {
  if (input.status !== "pending") {
    throw new Error("Esta solicitação já foi analisada.");
  }

  if (input.requestedByUserId === input.reviewedByUserId && !input.allowSelfReview) {
    throw new Error("O solicitante não pode aprovar ou recusar a própria solicitação.");
  }
}
