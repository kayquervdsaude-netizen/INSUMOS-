import { ENV } from "./_core/env";

type OwnerIdentity = { openId: string; email?: string | null };

const OWNER_EMAILS = ["kayque.santos@rvdsaude.com.br"];

export function isOwnerIdentity(identity: OwnerIdentity | null | undefined) {
  if (!identity) return false;
  const email = identity.email?.trim().toLowerCase();
  return identity.openId === ENV.ownerOpenId || Boolean(email && OWNER_EMAILS.includes(email));
}

export const ownerEmails = [...OWNER_EMAILS];
