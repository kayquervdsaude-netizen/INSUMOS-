import { describe, expect, it, vi } from "vitest";
import { assertCollaboratorCanBeDeleted } from "./teamDeletion";

describe("exclusão segura de colaboradores", () => {
  it("protege a conta proprietária e o último administrador", async () => {
    const repository = { countAdministrators: vi.fn().mockResolvedValue(1) };
    await expect(assertCollaboratorCanBeDeleted({ kind: "user", id: 1, actorUserId: 9, ownerOpenId: "owner" }, { id: 1, openId: "owner", role: "admin" }, repository)).rejects.toThrow("proprietário");
    await expect(assertCollaboratorCanBeDeleted({ kind: "user", id: 3, actorUserId: 1, ownerOpenId: "owner" }, { id: 3, openId: "other-admin", role: "admin" }, repository)).rejects.toThrow("ao menos um administrador");
  });

  it("permite excluir usuário comum ou convite pendente", async () => {
    const repository = { countAdministrators: vi.fn().mockResolvedValue(2) };
    await expect(assertCollaboratorCanBeDeleted({ kind: "user", id: 3, actorUserId: 1, ownerOpenId: "owner" }, { id: 3, openId: "password:3", role: "user" }, repository)).resolves.toBeUndefined();
    await expect(assertCollaboratorCanBeDeleted({ kind: "invite", id: 4, actorUserId: 1, ownerOpenId: "owner" }, null, repository)).resolves.toBeUndefined();
  });
});
