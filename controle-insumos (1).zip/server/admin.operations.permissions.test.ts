import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({ createMaterial: vi.fn(), updateMaterial: vi.fn(), createSupplier: vi.fn(), updateSupplier: vi.fn(), createManualEntry: vi.fn(), updatePurchaseStatus: vi.fn(), recordStockExit: vi.fn(), reviewStockRequest: vi.fn(), updateStockRequest: vi.fn(), deleteStockRequest: vi.fn(), createOutboundOrder: vi.fn(), updateOutboundOrder: vi.fn(), deleteOutboundOrder: vi.fn(), beginOutboundOrderPicking: vi.fn(), updateOutboundOrderItemPicking: vi.fn(), dispatchOutboundOrder: vi.fn(), cancelOutboundOrder: vi.fn(), recordAccessAudit: vi.fn() }));
vi.mock("./db", () => mocks);

import { appRouter } from "./routers";

function createContext(role: "admin" | "user"): TrpcContext {
  return { user: { id: role === "admin" ? 7 : 8, openId: role === "admin" ? "other-admin" : "collaborator", name: "Conta de teste", email: "teste@empresa.com", loginMethod: "password", role, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }, req: {} as TrpcContext["req"], res: {} as TrpcContext["res"] };
}

describe("permissões de administradores adicionais", () => {
  beforeEach(() => Object.values(mocks).forEach(mock => mock.mockReset()));

  it("permite que outro administrador edite cadastros, estoque, solicitações e pedidos", async () => {
    mocks.createMaterial.mockResolvedValue({ id: 1 });
    mocks.updateMaterial.mockResolvedValue({ id: 1 });
    mocks.createSupplier.mockResolvedValue({ id: 2 });
    mocks.updateSupplier.mockResolvedValue({ id: 2 });
    mocks.createManualEntry.mockResolvedValue({ id: 9, totalPrice: 12 });
    mocks.updatePurchaseStatus.mockResolvedValue({ id: 9, status: "confirmed" });
    mocks.recordStockExit.mockResolvedValue({ id: 3 });
    mocks.reviewStockRequest.mockResolvedValue({ id: 4 });
    mocks.updateStockRequest.mockResolvedValue({ id: 4, updated: true });
    mocks.deleteStockRequest.mockResolvedValue({ id: 4, deleted: true });
    mocks.createOutboundOrder.mockResolvedValue({ id: 5 });
    mocks.updateOutboundOrder.mockResolvedValue({ id: 5 });
    mocks.deleteOutboundOrder.mockResolvedValue({ id: 5, deleted: true });
    mocks.beginOutboundOrderPicking.mockResolvedValue({ id: 5 });
    mocks.updateOutboundOrderItemPicking.mockResolvedValue({ id: 6 });
    mocks.dispatchOutboundOrder.mockResolvedValue({ id: 5 });
    mocks.cancelOutboundOrder.mockResolvedValue({ id: 5 });
    const caller = appRouter.createCaller(createContext("admin"));

    await expect(caller.materials.create({ name: "Material teste", unit: "Und" })).resolves.toEqual({ id: 1 });
    await expect(caller.materials.update({ id: 1, data: { name: "Material atualizado", unit: "Und" } })).resolves.toEqual({ id: 1 });
    await expect(caller.suppliers.create({ name: "Fornecedor teste" })).resolves.toEqual({ id: 2 });
    await expect(caller.suppliers.update({ id: 2, data: { name: "Fornecedor atualizado" } })).resolves.toEqual({ id: 2 });
    await expect(caller.purchases.createManualEntry({ supplierId: 2, entryDate: new Date(), items: [{ materialId: 1, quantity: 2, unitPrice: 6 }] })).resolves.toEqual({ id: 9, totalPrice: 12 });
    await expect(caller.purchases.updateStatus({ purchaseOrderId: 9, status: "confirmed" })).resolves.toEqual({ id: 9, status: "confirmed" });
    await expect(caller.stock.recordExit({ materialId: 1, quantity: 1, reason: "Uso interno" })).resolves.toEqual({ id: 3 });
    await expect(caller.stockRequests.review({ requestId: 4, decision: "rejected" })).resolves.toEqual({ id: 4 });
    await expect(caller.stockRequests.update({ requestId: 4, data: { materialId: 1, quantity: 1, reason: "Uso interno" } })).resolves.toEqual({ id: 4, updated: true });
    await expect(caller.stockRequests.remove({ requestId: 4 })).resolves.toEqual({ id: 4, deleted: true });
    await expect(caller.outboundOrders.create({ recipientName: "Setor teste", items: [{ materialId: 1, quantity: 1 }] })).resolves.toEqual({ id: 5 });
    await expect(caller.outboundOrders.update({ orderId: 5, data: { recipientName: "Setor atualizado", items: [{ materialId: 1, quantity: 1 }] } })).resolves.toEqual({ id: 5 });
    await expect(caller.outboundOrders.remove({ orderId: 5 })).resolves.toEqual({ id: 5, deleted: true });
    await expect(caller.outboundOrders.startPicking({ orderId: 5 })).resolves.toEqual({ id: 5 });
    await expect(caller.outboundOrders.updatePicking({ orderItemId: 6, pickedQuantity: 1 })).resolves.toEqual({ id: 6 });
    await expect(caller.outboundOrders.dispatch({ orderId: 5 })).resolves.toEqual({ id: 5 });
    await expect(caller.outboundOrders.cancel({ orderId: 5 })).resolves.toEqual({ id: 5 });
    expect(mocks.createMaterial).toHaveBeenCalled();
    expect(mocks.createSupplier).toHaveBeenCalled();
    expect(mocks.createManualEntry).toHaveBeenCalledWith(expect.objectContaining({ supplierId: 2 }), { actorUserId: 7 });
    expect(mocks.updatePurchaseStatus).toHaveBeenCalledWith(9, "confirmed", 7);
    expect(mocks.updateMaterial).toHaveBeenCalledWith(1, { name: "Material atualizado", unit: "Und" });
    expect(mocks.updateSupplier).toHaveBeenCalledWith(2, { name: "Fornecedor atualizado" });
    expect(mocks.recordStockExit).toHaveBeenCalled();
    expect(mocks.reviewStockRequest).toHaveBeenCalledWith(expect.objectContaining({ reviewedByUserId: 7, reviewerOpenId: "other-admin" }));
    expect(mocks.updateStockRequest).toHaveBeenCalledWith(4, { materialId: 1, quantity: 1, reason: "Uso interno" });
    expect(mocks.deleteStockRequest).toHaveBeenCalledWith(4);
    expect(mocks.cancelOutboundOrder).toHaveBeenCalledWith(5, 7);
    expect(mocks.createOutboundOrder).toHaveBeenCalledWith(expect.objectContaining({ createdByUserId: 7 }));
    expect(mocks.updateOutboundOrder).toHaveBeenCalledWith(5, { recipientName: "Setor atualizado", items: [{ materialId: 1, quantity: 1 }] });
    expect(mocks.deleteOutboundOrder).toHaveBeenCalledWith(5);
    expect(mocks.beginOutboundOrderPicking).toHaveBeenCalledWith(5, 7);
    expect(mocks.updateOutboundOrderItemPicking).toHaveBeenCalledWith({ outboundOrderItemId: 6, pickedQuantity: 1 });
    expect(mocks.dispatchOutboundOrder).toHaveBeenCalledWith(5, "Conta de teste", 7);
    expect(mocks.recordAccessAudit).toHaveBeenCalledTimes(17);
  });

  it("bloqueia colaboradores antes de qualquer alteração operacional", async () => {
    const caller = appRouter.createCaller(createContext("user"));
    await expect(caller.materials.create({ name: "Material teste", unit: "Und" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.materials.update({ id: 1, data: { name: "Material atualizado", unit: "Und" } })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.suppliers.create({ name: "Fornecedor teste" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.suppliers.update({ id: 2, data: { name: "Fornecedor atualizado" } })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.purchases.createManualEntry({ supplierId: 2, entryDate: new Date(), items: [{ materialId: 1, quantity: 2, unitPrice: 6 }] })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.stock.recordExit({ materialId: 1, quantity: 1, reason: "Uso interno" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.stockRequests.review({ requestId: 4, decision: "rejected" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.stockRequests.update({ requestId: 4, data: { materialId: 1, quantity: 1, reason: "Uso interno" } })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.stockRequests.remove({ requestId: 4 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.outboundOrders.cancel({ orderId: 5 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.outboundOrders.create({ recipientName: "Setor teste", items: [{ materialId: 1, quantity: 1 }] })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.outboundOrders.update({ orderId: 5, data: { recipientName: "Setor atualizado", items: [{ materialId: 1, quantity: 1 }] } })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.outboundOrders.remove({ orderId: 5 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.outboundOrders.startPicking({ orderId: 5 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.outboundOrders.updatePicking({ orderItemId: 6, pickedQuantity: 1 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.outboundOrders.dispatch({ orderId: 5 })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("bloqueia colaborador de alterar status de compra", async () => {
    const caller = appRouter.createCaller(createContext("user"));
    await expect(caller.purchases.updateStatus({ purchaseOrderId: 9, status: "confirmed" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(mocks.updatePurchaseStatus).not.toHaveBeenCalled();
  });
});
