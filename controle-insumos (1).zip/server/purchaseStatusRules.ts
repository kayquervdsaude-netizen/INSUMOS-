export type PurchaseStatus = "received" | "awaiting_confirmation" | "confirmed";

export const PURCHASE_STATUS_OPTIONS: Array<{ value: PurchaseStatus; label: string }> = [
  { value: "received", label: "Recebido" },
  { value: "awaiting_confirmation", label: "Aguardando conferência" },
  { value: "confirmed", label: "Conferido" },
];

export function purchaseStatusLabel(status: PurchaseStatus) {
  return PURCHASE_STATUS_OPTIONS.find(option => option.value === status)?.label ?? status;
}

export function assertPurchaseStatusTransition(currentStatus: PurchaseStatus, nextStatus: PurchaseStatus) {
  if (currentStatus === "confirmed" && nextStatus !== "confirmed") {
    throw new Error("Uma compra conferida não pode voltar de status porque sua entrada já foi registrada no estoque.");
  }
  if (currentStatus === "awaiting_confirmation" && nextStatus === "received") {
    throw new Error("Uma compra aguardando conferência não pode voltar para recebida.");
  }
}

export function shouldApplyPurchaseStock(status: PurchaseStatus, stockAppliedAt: Date | string | null | undefined) {
  return status === "confirmed" && !stockAppliedAt;
}

export function purchaseStatusCanBeChanged(status: PurchaseStatus) {
  return status !== "confirmed";
}
