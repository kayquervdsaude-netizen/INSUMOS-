import { describe, expect, it } from "vitest";
import { assertStockRequestCanBeReviewed } from "./stockRequestRules";

describe("assertStockRequestCanBeReviewed", () => {
  it("permite que um administrador diferente analise uma solicitação pendente", () => {
    expect(() =>
      assertStockRequestCanBeReviewed({ status: "pending", requestedByUserId: 8, reviewedByUserId: 2 })
    ).not.toThrow();
  });

  it("bloqueia nova análise de uma solicitação já decidida", () => {
    expect(() =>
      assertStockRequestCanBeReviewed({ status: "approved", requestedByUserId: 8, reviewedByUserId: 2 })
    ).toThrow("já foi analisada");
  });

  it("bloqueia a autoaprovação", () => {
    expect(() =>
      assertStockRequestCanBeReviewed({ status: "pending", requestedByUserId: 8, reviewedByUserId: 8 })
    ).toThrow("própria solicitação");
  });

  it("permite autoaprovação apenas quando a exceção do administrador proprietário é explicitamente autorizada", () => {
    expect(() =>
      assertStockRequestCanBeReviewed({ status: "pending", requestedByUserId: 8, reviewedByUserId: 8, allowSelfReview: true })
    ).not.toThrow();
  });
});
