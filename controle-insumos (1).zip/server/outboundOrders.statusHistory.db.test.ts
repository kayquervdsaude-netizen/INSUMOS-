import { describe, expect, it, vi } from "vitest";
import { beginOutboundOrderPicking, cancelOutboundOrder } from "./db";

function query(rows: unknown[]) {
  const result = Object.assign(Promise.resolve(rows), { limit: async () => rows, orderBy: async () => rows });
  const chain: { where: () => typeof result; innerJoin: () => typeof chain; leftJoin: () => typeof chain; orderBy: () => Promise<unknown[]> } = {
    where: () => result,
    innerJoin: () => chain,
    leftJoin: () => chain,
    orderBy: async () => rows,
  };
  return { from: () => chain };
}

function updateResult() {
  return { set: () => ({ where: async () => [{ affectedRows: 1 }] }) };
}

function detailDatabase(order: Record<string, unknown>) {
  return {
    select: vi.fn()
      .mockReturnValueOnce(query([order]))
      .mockReturnValueOnce(query([]))
      .mockReturnValueOnce(query([])),
  };
}

describe("histórico persistente dos pedidos de saída", () => {
  it("registra o início da separação como draft para picking", async () => {
    const historyValues = vi.fn().mockResolvedValue(undefined);
    const database = {
      ...detailDatabase({ id: 15, status: "picking", code: "PS-20260826-ABC123" }),
      update: vi.fn().mockReturnValue(updateResult()),
      insert: vi.fn().mockReturnValue({ values: historyValues }),
    };

    await expect(beginOutboundOrderPicking(15, 1, { db: database as never, skipInitialData: true })).resolves.toMatchObject({ id: 15, status: "picking" });
    expect(historyValues).toHaveBeenCalledWith(expect.objectContaining({ outboundOrderId: 15, previousStatus: "draft", nextStatus: "picking", changedByUserId: 1 }));
  });

  it("registra o cancelamento com o status anterior", async () => {
    const historyValues = vi.fn().mockResolvedValue(undefined);
    const database = {
      select: vi.fn()
        .mockReturnValueOnce(query([{ status: "draft" }]))
        .mockReturnValueOnce(query([{ id: 15, status: "cancelled", code: "PS-20260826-ABC123" }]))
        .mockReturnValueOnce(query([]))
        .mockReturnValueOnce(query([])),
      update: vi.fn().mockReturnValue(updateResult()),
      insert: vi.fn().mockReturnValue({ values: historyValues }),
    };

    await expect(cancelOutboundOrder(15, 1, { db: database as never, skipInitialData: true })).resolves.toMatchObject({ id: 15, status: "cancelled" });
    expect(historyValues).toHaveBeenCalledWith(expect.objectContaining({ outboundOrderId: 15, previousStatus: "draft", nextStatus: "cancelled", changedByUserId: 1 }));
  });
});
