type RequestQuantityInput = {
  quantity: number;
  availableStock: number;
};

type ReviewOutcomeInput = RequestQuantityInput & {
  decision: "approved" | "rejected";
};

export function assertStockRequestCanBeCreated(input: RequestQuantityInput) {
  if (input.quantity <= 0) throw new Error("A quantidade solicitada deve ser maior que zero.");
  if (input.quantity > input.availableStock) throw new Error("A quantidade solicitada é maior que o saldo disponível.");
}

export function getStockRequestReviewOutcome(input: ReviewOutcomeInput) {
  if (input.decision === "rejected") {
    return { status: "rejected" as const, requiresPicking: false };
  }

  assertStockRequestCanBeCreated(input);
  return { status: "approved" as const, requiresPicking: true };
}
