import { assertAdministratorDemotionAllowed, assertRoleChangeAllowed, type CollaboratorRole } from "./teamAccess";

export type RoleUpdateInput = { kind: "user" | "invite"; id: number; role: CollaboratorRole; actorUserId: number };
export type RoleUpdateRepository = {
  getUserRole: (id: number) => Promise<CollaboratorRole | null>;
  countAdministrators: () => Promise<number>;
  updateUserRole: (id: number, role: CollaboratorRole) => Promise<void>;
  updateInviteRole: (id: number, role: CollaboratorRole) => Promise<void>;
};

export async function updateCollaboratorRole(input: RoleUpdateInput, repository: RoleUpdateRepository) {
  if (input.kind === "invite") {
    await repository.updateInviteRole(input.id, input.role);
    return;
  }

  assertRoleChangeAllowed({ kind: input.kind, targetId: input.id, actorUserId: input.actorUserId });
  const currentRole = await repository.getUserRole(input.id);
  if (!currentRole) throw new Error("Colaborador não encontrado.");
  if (currentRole === "admin" && input.role !== "admin") {
    assertAdministratorDemotionAllowed({ currentRole, nextRole: input.role, administratorCount: await repository.countAdministrators() });
  }
  await repository.updateUserRole(input.id, input.role);
}
