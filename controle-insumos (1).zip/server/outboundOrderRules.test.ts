import { describe, expect, it } from "vitest";
import { assertOutboundOrderReadyForDispatch, assertOutboundOrderTransition } from "./outboundOrderRules";

describe("regras de pedidos de saída", () => {
  it("permite a sequência de criação, separação e expedição", () => {
    expect(() => assertOutboundOrderTransition("draft", "picking")).not.toThrow();
    expect(() => assertOutboundOrderTransition("picking", "dispatched")).not.toThrow();
    expect(() => assertOutboundOrderReadyForDispatch({ status: "picking", items: [{ requestedQuantity: 40, pickedQuantity: 40 }] })).not.toThrow();
  });

  it("bloqueia a expedição com item separado parcialmente", () => {
    expect(() => assertOutboundOrderReadyForDispatch({ status: "picking", items: [{ requestedQuantity: 40, pickedQuantity: 20 }] })).toThrow("Todos os itens");
  });

  it("bloqueia alterações após expedição ou cancelamento", () => {
    expect(() => assertOutboundOrderTransition("dispatched", "picking")).toThrow("não é permitida");
    expect(() => assertOutboundOrderTransition("cancelled", "picking")).toThrow("não é permitida");
  });
});
