import { describe, expect, it } from "vitest";
import { assertAdministratorDemotionAllowed, assertRoleChangeAllowed, prepareCollaborator } from "./teamAccess";

describe("team access", () => {
  it("prepara um convite com e-mail normalizado e perfil definido", () => {
    expect(prepareCollaborator({ name: "  Ana Souza ", email: " ANA@EMPRESA.COM.BR ", role: "admin" })).toEqual({ name: "Ana Souza", email: "ana@empresa.com.br", role: "admin" });
  });

  it("impede que um administrador altere seu próprio perfil pela lista de equipe", () => {
    expect(() => assertRoleChangeAllowed({ kind: "user", targetId: 4, actorUserId: 4 })).toThrow("próprio perfil administrativo");
    expect(() => assertRoleChangeAllowed({ kind: "invite", targetId: 4, actorUserId: 4 })).not.toThrow();
  });

  it("mantém ao menos um administrador ativo ao alterar perfis", () => {
    expect(() => assertAdministratorDemotionAllowed({ currentRole: "admin", nextRole: "user", administratorCount: 1 })).toThrow("ao menos um administrador");
    expect(() => assertAdministratorDemotionAllowed({ currentRole: "admin", nextRole: "user", administratorCount: 2 })).not.toThrow();
    expect(() => assertAdministratorDemotionAllowed({ currentRole: "user", nextRole: "user", administratorCount: 1 })).not.toThrow();
  });
});
