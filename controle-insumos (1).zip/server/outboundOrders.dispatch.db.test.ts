import { describe, expect, it, vi } from "vitest";
import { dispatchOutboundOrder } from "./db";

function query(rows: unknown[]) {
  const result = Object.assign(Promise.resolve(rows), { limit: async () => rows, orderBy: async () => rows });
  const chain: { where: () => typeof result; innerJoin: () => typeof chain; leftJoin: () => typeof chain; orderBy: () => Promise<unknown[]> } = {
    where: () => result,
    innerJoin: () => chain,
    leftJoin: () => chain,
    orderBy: async () => rows,
  };
  return { from: () => chain };
}

function updateResult(affectedRows = 1) {
  return { set: () => ({ where: async () => [{ affectedRows }] }) };
}

describe("expedição transacional do pedido de saída", () => {
  it("registra uma única baixa por item e vincula a movimentação ao pedido", async () => {
    const movementValues = vi.fn().mockResolvedValue(undefined);
    const statusHistoryValues = vi.fn().mockResolvedValue(undefined);
    const transaction = {
      select: vi
        .fn()
        .mockReturnValueOnce(query([{ id: 15, code: "PS-20260826-ABC123", recipientName: "Unidade Centro", status: "picking" }]))
        .mockReturnValueOnce(query([{ id: 22, materialId: 4, requestedQuantity: "40.000", pickedQuantity: "40.000", unitCost: "3.50" }]))
        .mockReturnValueOnce(query([{ id: 4, stockQuantity: "70.000", averageCost: "3.50" }])),
      update: vi.fn().mockReturnValue(updateResult()),
      insert: vi.fn().mockReturnValueOnce({ values: movementValues }).mockReturnValueOnce({ values: statusHistoryValues }),
    };
    const database = {
      transaction: vi.fn(callback => callback(transaction)),
      select: vi
        .fn()
        .mockReturnValueOnce(query([{ id: 15, code: "PS-20260826-ABC123", recipientName: "Unidade Centro", status: "dispatched" }]))
        .mockReturnValueOnce(query([{ id: 22, materialId: 4, materialName: "Caixa 04", unit: "Und", requestedQuantity: "40.000", pickedQuantity: "40.000", unitCost: "3.50", availableStock: "30.000" }]))
        .mockReturnValueOnce(query([])),
    };

    await expect(dispatchOutboundOrder(15, "Conferente", { db: database as never, skipInitialData: true })).resolves.toMatchObject({ id: 15, status: "dispatched" });
    expect(movementValues).toHaveBeenCalledTimes(1);
    expect(movementValues).toHaveBeenCalledWith(expect.objectContaining({ outboundOrderId: 15, materialId: 4, type: "exit", quantity: "-40.000", balanceAfter: "30.000" }));
    expect(statusHistoryValues).toHaveBeenCalledWith(expect.objectContaining({ outboundOrderId: 15, previousStatus: "picking", nextStatus: "dispatched" }));
  });

  it("bloqueia uma nova expedição antes de tocar no estoque", async () => {
    const movementValues = vi.fn();
    const transaction = { select: vi.fn().mockReturnValue(query([{ id: 15, status: "dispatched" }])), update: vi.fn(), insert: vi.fn().mockReturnValue({ values: movementValues }) };
    const database = { transaction: vi.fn(callback => callback(transaction)) };

    await expect(dispatchOutboundOrder(15, "Conferente", { db: database as never, skipInitialData: true })).rejects.toThrow("deve estar em separação");
    expect(movementValues).not.toHaveBeenCalled();
  });
});
