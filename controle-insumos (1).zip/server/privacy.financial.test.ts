import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({
  listSuppliers: vi.fn(),
  listMaterials: vi.fn(),
  listPurchases: vi.fn(),
  getPurchaseDetails: vi.fn(),
  listStockMovements: vi.fn(),
  listRefrigeratedUsage: vi.fn(),
  recordAccessAudit: vi.fn(),
}));

vi.mock("./db", () => mocks);

import { appRouter } from "./routers";

function context(role: "admin" | "user"): TrpcContext {
  return { user: { id: role === "admin" ? 1 : 2, openId: role, name: "Teste", email: `${role}@empresa.com`, loginMethod: "password", role, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }, req: {} as TrpcContext["req"], res: {} as TrpcContext["res"] };
}

describe("privacidade de valores e fornecedores", () => {
  beforeEach(() => Object.values(mocks).forEach(mock => mock.mockReset()));

  it("bloqueia a consulta de fornecedores para colaboradores", async () => {
    await expect(appRouter.createCaller(context("user")).suppliers.list()).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(mocks.listSuppliers).not.toHaveBeenCalled();
  });

  it("mascara fornecedor e custo de insumos para colaboradores", async () => {
    mocks.listMaterials.mockResolvedValue([{ id: 1, name: "Caixa 04", supplierName: "Fornecedor reservado", averageCost: "12.50" }]);
    const result = await appRouter.createCaller(context("user")).materials.list();
    expect(result[0]).toMatchObject({ supplierName: null, averageCost: "0" });
  });

  it("mascara fornecedor, total e preços dos detalhes de compras", async () => {
    mocks.listPurchases.mockResolvedValue([{ id: 1, supplierName: "Fornecedor reservado", totalPrice: "500.00" }]);
    mocks.getPurchaseDetails.mockResolvedValue({ id: 1, supplierName: "Fornecedor reservado", totalPrice: "500.00", items: [{ id: 2, unitPrice: "10.00", totalPrice: "20.00" }] });
    const caller = appRouter.createCaller(context("user"));
    const rows = await caller.purchases.list();
    const detail = await caller.purchases.details({ id: 1 });
    expect(rows[0]).toMatchObject({ supplierName: null, totalPrice: "0" });
    expect(detail).toMatchObject({ supplierName: null, totalPrice: "0" });
    expect(detail.items[0]).toMatchObject({ unitPrice: "0", totalPrice: "0" });
  });

  it("mascara custo unitário das movimentações para colaboradores", async () => {
    mocks.listStockMovements.mockResolvedValue([{ id: 1, unitCost: "12.50", quantity: "2" }]);
    const result = await appRouter.createCaller(context("user")).stock.movements();
    expect(result[0]).toMatchObject({ unitCost: "0", quantity: "2" });
  });

  it("não entrega nenhum dado da área refrigerada a colaboradores", async () => {
    mocks.listRefrigeratedUsage.mockResolvedValue([{ id: 1, totalConsumptionValue: "500.00" }]);
    const result = await appRouter.createCaller(context("user")).refrigerated.list();
    expect(result).toEqual([]);
    expect(mocks.listRefrigeratedUsage).not.toHaveBeenCalled();
  });
});
