import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { getSessionCookieOptions } from "./_core/cookies";
import { ENV } from "./_core/env";
import { isOwnerIdentity } from "./ownerAccess";
import { sdk } from "./_core/sdk";
import { systemRouter } from "./_core/systemRouter";
import { adminOrDiretoriaProcedure, adminProcedure, ownerProcedure, protectedProcedure, publicProcedure, router } from "./_core/trpc";
import * as db from "./db";
import type { PurchaseStatus } from "./purchaseStatusRules";

const materialInput = z.object({
  name: z.string().trim().min(2).max(255),
  category: z.string().trim().max(255).nullable().optional(),
  unit: z.string().trim().min(1).max(32),
  defaultSupplierId: z.number().int().positive().nullable().optional(),
  averageCost: z.number().min(0).optional(),
  stockQuantity: z.number().min(0).optional(),
  minimumStock: z.number().min(0).optional(),
  criticalStock: z.number().min(0).optional(),
  status: z.enum(["active", "inactive"]).optional(),
}).superRefine((value, context) => {
  if (value.criticalStock !== undefined && value.minimumStock !== undefined && value.criticalStock > value.minimumStock) {
    context.addIssue({ code: z.ZodIssueCode.custom, path: ["criticalStock"], message: "O estoque crítico não pode ser maior que o estoque mínimo." });
  }
});

const supplierInput = z.object({
  name: z.string().trim().min(2).max(255),
  email: z.string().trim().max(1000).nullable().optional(),
  phone: z.string().trim().max(255).nullable().optional(),
  contact: z.string().trim().max(255).nullable().optional(),
  category: z.string().trim().max(255).nullable().optional(),
  leadTime: z.string().trim().max(255).nullable().optional(),
  notes: z.string().trim().max(5000).nullable().optional(),
});

const invoiceItemInput = z.object({
  materialId: z.number().int().positive().nullable().optional(),
  sourceCode: z.string().trim().max(64).nullable().optional(),
  description: z.string().trim().min(1).max(255),
  ncm: z.string().trim().max(32).nullable().optional(),
  unit: z.string().trim().min(1).max(32),
  quantity: z.number().positive(),
  unitPrice: z.number().min(0),
  totalPrice: z.number().min(0),
});

const stockRequestInput = z.object({
  materialId: z.number().int().positive(),
  quantity: z.number().positive(),
  reason: z.string().trim().min(2).max(255),
  notes: z.string().trim().max(2000).nullable().optional(),
});

const outboundOrderItemInput = z.object({
  materialId: z.number().int().positive(),
  quantity: z.number().positive(),
});

const outboundOrderInput = z.object({
  recipientName: z.string().trim().min(2).max(255),
  recipientDocument: z.string().trim().max(32).nullable().optional(),
  destination: z.string().trim().max(255).nullable().optional(),
  contact: z.string().trim().max(255).nullable().optional(),
  notes: z.string().trim().max(5000).nullable().optional(),
  items: z.array(outboundOrderItemInput).min(1),
});

const manualEntryInput = z.object({
  supplierId: z.number().int().positive(),
  entryDate: z.date(),
  reference: z.string().trim().max(64).nullable().optional(),
  invoiceNumber: z.string().trim().max(64).nullable().optional(),
  company: z.string().trim().max(64).nullable().optional(),
  notes: z.string().trim().max(5000).nullable().optional(),
  items: z.array(z.object({ materialId: z.number().int().positive(), quantity: z.number().positive(), unitPrice: z.number().min(0) })).min(1),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user ? { ...opts.ctx.user, isOwner: isOwnerIdentity(opts.ctx.user) } : null),
    passwordLogin: publicProcedure
      .input(z.object({ email: z.string().trim().email().max(320), password: z.string().min(1).max(128) }))
      .mutation(async ({ input, ctx }) => {
        const user = await db.authenticateWithPassword(input);
        if (!user) throw new TRPCError({ code: "UNAUTHORIZED", message: "E-mail ou senha inválidos." });
        const token = await sdk.createSessionToken(user.openId, { name: user.name ?? user.email ?? "Usuário interno" });
        ctx.res.cookie(COOKIE_NAME, token, getSessionCookieOptions(ctx.req));
        return { ...user, isOwner: isOwnerIdentity(user) };
      }),
    visitorLogin: publicProcedure.mutation(async ({ ctx }) => {
      const user = await db.getOrCreateVisitor();
      if (!user) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Não foi possível iniciar o acesso visitante." });
      const token = await sdk.createSessionToken(user.openId, { name: "Visitante" });
      ctx.res.cookie(COOKIE_NAME, token, getSessionCookieOptions(ctx.req));
      return { ...user, isOwner: false };
    }),
    passwordStatus: protectedProcedure.query(({ ctx }) => db.getPasswordStatus(ctx.user.id)),
    setPassword: ownerProcedure
      .input(z.object({ password: z.string().min(8).max(128), currentPassword: z.string().max(128).nullable().optional() }))
      .mutation(({ input, ctx }) => db.setUserPassword({ ...input, userId: ctx.user.id })),
    logout: publicProcedure.mutation(async ({ ctx }) => {
      if (ctx.user) await db.revokeUserSessions(ctx.user.id);
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  dashboard: router({
    overview: protectedProcedure.input(z.object({ months: z.number().int().min(3).max(12).optional() }).optional()).query(async ({ input, ctx }) => {
      const data = await db.getDashboardData(input);
      if (ctx.user.role === "admin" || ctx.user.role === "diretoria") return data;
      return { ...data, metrics: { ...data.metrics, suppliers: 0, invoices: 0, stockValue: 0 }, recentPurchases: data.recentPurchases.map(row => ({ ...row, supplierName: null, totalPrice: "0", invoiceNumber: null })), charts: { ...data.charts, purchaseTrend: [], topSuppliers: [] } };
    }),
  }),
  materials: router({
    list: protectedProcedure
      .input(z.object({ search: z.string().trim().optional(), category: z.string().trim().optional(), status: z.enum(["active", "inactive"]).optional() }).optional())
      .query(async ({ input, ctx }) => {
        const rows = await db.listMaterials(input);
        return ctx.user.role === "admin" || ctx.user.role === "diretoria" ? rows : rows.map(row => ({ ...row, supplierName: null, averageCost: "0" }));
      }),
    create: adminProcedure.input(materialInput).mutation(({ input }) => db.createMaterial(input)),
    update: adminProcedure.input(z.object({ id: z.number().int().positive(), data: materialInput })).mutation(({ input }) => db.updateMaterial(input.id, input.data)),
  }),
  suppliers: router({
    list: adminOrDiretoriaProcedure.input(z.object({ search: z.string().trim().optional() }).optional()).query(({ input }) => db.listSuppliers(input)),
    create: adminProcedure.input(supplierInput).mutation(({ input }) => db.createSupplier(input)),
    update: adminProcedure.input(z.object({ id: z.number().int().positive(), data: supplierInput })).mutation(({ input }) => db.updateSupplier(input.id, input.data)),
  }),
  purchases: router({
    list: protectedProcedure
      .input(z.object({ search: z.string().trim().optional(), company: z.string().trim().optional() }).optional())
      .query(async ({ input, ctx }) => {
        const rows = await db.listPurchases(input);
        return ctx.user.role === "admin" || ctx.user.role === "diretoria" ? rows : rows.map(row => ({ ...row, supplierName: null, totalPrice: "0" }));
      }),
    details: protectedProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ input, ctx }) => {
      const detail = await db.getPurchaseDetails(input.id);
      return ctx.user.role === "admin" || ctx.user.role === "diretoria" ? detail : { ...detail, supplierName: null, totalPrice: "0", items: detail.items.map(item => ({ ...item, unitPrice: "0", totalPrice: "0" })) };
    }),
    createManualEntry: adminProcedure.input(manualEntryInput).mutation(({ input, ctx }) => db.createManualEntry(input, { actorUserId: ctx.user.id })),
    updateStatus: adminProcedure
      .input(z.object({ purchaseOrderId: z.number().int().positive(), status: z.enum(["received", "awaiting_confirmation", "confirmed"]) }))
      .mutation(({ input, ctx }) => db.updatePurchaseStatus(input.purchaseOrderId, input.status as PurchaseStatus, ctx.user.id)),
  }),
  invoices: router({
    list: adminOrDiretoriaProcedure.query(() => db.listInvoices()),
    getById: adminOrDiretoriaProcedure.input(z.object({ id: z.number().int().positive() })).query(({ input }) => db.getInvoiceById(input.id)),
    import: adminProcedure
      .input(
        z.object({
          number: z.string().trim().min(1).max(64),
          accessKey: z.string().trim().max(64).nullable().optional(),
          issuerName: z.string().trim().min(1).max(255),
          issuerDocument: z.string().trim().max(32).nullable().optional(),
          issueDate: z.date().nullable().optional(),
          totalAmount: z.number().min(0),
          items: z.array(invoiceItemInput).min(1),
        })
      )
      .mutation(({ input }) => db.importInvoice(input)),
    matchItem: adminProcedure
      .input(z.object({ invoiceItemId: z.number().int().positive(), materialId: z.number().int().positive() }))
      .mutation(({ input }) => db.matchInvoiceItem(input.invoiceItemId, input.materialId)),
    confirm: adminProcedure.input(z.object({ invoiceId: z.number().int().positive() })).mutation(({ input }) => db.confirmInvoice(input.invoiceId)),
    updateStatus: adminProcedure
      .input(z.object({ invoiceId: z.number().int().positive(), status: z.enum(["draft", "confirmed"]) }))
      .mutation(({ input }) => db.updateInvoiceStatus(input.invoiceId, input.status)),
  }),
  stock: router({
    movements: protectedProcedure.query(async ({ ctx }) => {
      const rows = await db.listStockMovements();
      return ctx.user.role === "admin" || ctx.user.role === "diretoria" ? rows : rows.map(row => ({ ...row, unitCost: "0" }));
    }),
    recordExit: adminProcedure
      .input(z.object({ materialId: z.number().int().positive(), quantity: z.number().positive(), reason: z.string().trim().min(2).max(255), notes: z.string().trim().max(2000).nullable().optional() }))
      .mutation(({ input, ctx }) => db.recordStockExit({ ...input, actorName: ctx.user.name ?? ctx.user.email ?? "Usuário interno" })),
  }),
  stockAudits: router({
    list: adminOrDiretoriaProcedure.query(() => db.listStockAudits()),
    getById: adminOrDiretoriaProcedure.input(z.object({ id: z.number().int().positive() })).query(({ input }) => db.getStockAudit(input.id)),
    create: adminProcedure.input(z.object({ notes: z.string().trim().max(2000).nullable().optional() })).mutation(({ input, ctx }) => db.createStockAudit({ startedByUserId: ctx.user.id, notes: input.notes })),
    saveCounts: adminProcedure.input(z.object({ auditId: z.number().int().positive(), items: z.array(z.object({ materialId: z.number().int().positive(), countedQuantity: z.number().min(0) })).min(1) })).mutation(({ input }) => db.updateStockAuditCounts(input)),
    complete: adminProcedure.input(z.object({ auditId: z.number().int().positive() })).mutation(({ input, ctx }) => db.completeStockAudit({ auditId: input.auditId, completedByUserId: ctx.user.id })),
  }),
  stockRequests: router({
    list: protectedProcedure.query(({ ctx }) => db.listStockRequests({ userId: ctx.user.id, isAdmin: ctx.user.role === "admin" || ctx.user.role === "diretoria" })),
    create: protectedProcedure.input(stockRequestInput).mutation(({ input, ctx }) => db.createStockRequest({ ...input, requestedByUserId: ctx.user.id })),
    update: adminProcedure.input(z.object({ requestId: z.number().int().positive(), data: stockRequestInput })).mutation(({ input }) => db.updateStockRequest(input.requestId, input.data)),
    remove: adminProcedure.input(z.object({ requestId: z.number().int().positive() })).mutation(({ input }) => db.deleteStockRequest(input.requestId)),
    review: adminProcedure
      .input(z.object({ requestId: z.number().int().positive(), decision: z.enum(["approved", "rejected"]), reviewNotes: z.string().trim().max(2000).nullable().optional() }))
      .mutation(({ input, ctx }) => db.reviewStockRequest({ ...input, reviewedByUserId: ctx.user.id, reviewerOpenId: ctx.user.openId, reviewerName: ctx.user.name ?? ctx.user.email ?? "Administrador" })),
  }),
  outboundOrders: router({
    list: protectedProcedure.input(z.object({ status: z.enum(["draft", "picking", "dispatched", "cancelled"]).optional() }).optional()).query(async ({ input, ctx }) => {
      const rows = await db.listOutboundOrders(input);
      return ctx.user.role === "admin" || ctx.user.role === "diretoria" ? rows : rows.map(row => ({ ...row, totalValue: "0", dispatchedValue: "0" }));
    }),
    getById: protectedProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ input, ctx }) => {
      const order = await db.getOutboundOrderById(input.id);
      return ctx.user.role === "admin" || ctx.user.role === "diretoria" ? order : { ...order, items: order.items.map(item => ({ ...item, unitCost: "0" })) };
    }),
    create: adminProcedure.input(outboundOrderInput).mutation(({ input, ctx }) => db.createOutboundOrder({ ...input, createdByUserId: ctx.user.id })),
    update: adminProcedure.input(z.object({ orderId: z.number().int().positive(), data: outboundOrderInput })).mutation(({ input }) => db.updateOutboundOrder(input.orderId, input.data)),
    remove: adminProcedure.input(z.object({ orderId: z.number().int().positive() })).mutation(({ input }) => db.deleteOutboundOrder(input.orderId)),
    startPicking: adminProcedure.input(z.object({ orderId: z.number().int().positive() })).mutation(({ input, ctx }) => db.beginOutboundOrderPicking(input.orderId, ctx.user.id)),
    updatePicking: adminProcedure.input(z.object({ orderItemId: z.number().int().positive(), pickedQuantity: z.number().min(0) })).mutation(({ input }) => db.updateOutboundOrderItemPicking({ outboundOrderItemId: input.orderItemId, pickedQuantity: input.pickedQuantity })),
    dispatch: adminProcedure.input(z.object({ orderId: z.number().int().positive() })).mutation(({ input, ctx }) => db.dispatchOutboundOrder(input.orderId, ctx.user.name ?? ctx.user.email ?? "Administrador", ctx.user.id)),
    cancel: adminProcedure.input(z.object({ orderId: z.number().int().positive() })).mutation(({ input, ctx }) => db.cancelOutboundOrder(input.orderId, ctx.user.id)),
    report: protectedProcedure
      .input(z.object({ startDate: z.date().optional(), endDate: z.date().optional(), status: z.enum(["draft", "picking", "dispatched", "cancelled"]).optional(), sector: z.string().trim().min(1).optional() }).optional())
      .query(async ({ input, ctx }) => {
        const report = await db.getOutboundOrderReport(input);
        return ctx.user.role === "admin" || ctx.user.role === "diretoria" ? report : { ...report, summary: { ...report.summary, requestedValue: "0", dispatchedCost: "0", dispatchedValue: "0" }, materials: report.materials.map(material => ({ ...material, cost: "0" })), orders: report.orders.map(order => ({ ...order, totalValue: "0", dispatchedValue: "0" })) };
      }),
  }),
  refrigerated: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin" && ctx.user.role !== "diretoria") return [];
      return db.listRefrigeratedUsage();
    }),
  }),
  privacy: router({
    auditLogs: ownerProcedure.query(() => db.listAccessAuditLogs()),
    myRequests: protectedProcedure.query(({ ctx }) => db.listMyDataSubjectRequests(ctx.user.id)),
    createRequest: protectedProcedure
      .input(z.object({ type: z.enum(["access", "correction", "deletion", "information"]), message: z.string().trim().max(2000).nullable().optional() }))
      .mutation(({ input, ctx }) => db.createDataSubjectRequest({ requesterUserId: ctx.user.id, type: input.type, message: input.message })),
    requests: ownerProcedure.query(() => db.listDataSubjectRequests()),
    updateRequest: ownerProcedure
      .input(z.object({ id: z.number().int().positive(), status: z.enum(["pending", "in_review", "completed"]) }))
      .mutation(({ input, ctx }) => db.updateDataSubjectRequest({ ...input, handledByUserId: ctx.user.id })),
  }),
  team: router({
    myAccess: protectedProcedure.query(({ ctx }) => ctx.user),
    list: ownerProcedure.query(() => db.listTeamMembers()),
    create: ownerProcedure
      .input(z.object({ name: z.string().trim().min(2).max(255), email: z.string().trim().email().max(320), password: z.string().min(8).max(128), role: z.enum(["admin", "user", "diretoria"]) }))
      .mutation(({ input, ctx }) => db.createPasswordCollaborator({ ...input, actorOpenId: ctx.user.openId })),
    resetPassword: ownerProcedure
      .input(z.object({ userId: z.number().int().positive(), password: z.string().min(8).max(128) }))
      .mutation(({ input, ctx }) => db.resetUserPasswordByAdmin({ ...input, actorUserId: ctx.user.id, actorOpenId: ctx.user.openId })),
    updateRole: ownerProcedure
      .input(z.object({ kind: z.enum(["user", "invite"]), id: z.number().int().positive(), role: z.enum(["admin", "user", "diretoria"]) }))
      .mutation(({ input, ctx }) => db.updateCollaboratorRole({ ...input, actorUserId: ctx.user.id, actorOpenId: ctx.user.openId })),
    remove: ownerProcedure
      .input(z.object({ kind: z.enum(["user", "invite"]), id: z.number().int().positive() }))
      .mutation(({ input, ctx }) => db.deleteCollaborator({ ...input, actorUserId: ctx.user.id })),
  }),
});

export type AppRouter = typeof appRouter;
