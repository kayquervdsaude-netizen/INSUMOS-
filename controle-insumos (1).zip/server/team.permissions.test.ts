import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

describe("team permissions", () => {
  it("bloqueia o acesso de colaboradores à gestão de equipe", async () => {
    const ctx: TrpcContext = {
      user: {
        id: 10,
        openId: "collaborator-open-id",
        name: "Colaborador",
        email: "collaborator@example.com",
        loginMethod: "manus",
        role: "user",
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      },
      req: {} as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };

    await expect(appRouter.createCaller(ctx).team.list()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("bloqueia mutações para o perfil Diretoria", async () => {
    const ctx: TrpcContext = {
      user: {
        id: 11,
        openId: "diretoria-open-id",
        name: "Diretoria",
        email: "diretoria@example.com",
        loginMethod: "password",
        role: "diretoria",
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      },
      req: {} as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };

    await expect(
      appRouter.createCaller(ctx).stockRequests.create({ materialId: 1, quantity: 1, reason: "Uso interno", notes: null })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
