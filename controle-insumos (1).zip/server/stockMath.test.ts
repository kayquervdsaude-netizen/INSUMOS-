import { describe, expect, it } from "vitest";
import { calculateEntryBalance, calculateExitBalance } from "./stockMath";

describe("calculateEntryBalance", () => {
  it("atualiza saldo e recalcula o custo médio ponderado em uma entrada", () => {
    expect(calculateEntryBalance(10, 5, 5, 8)).toEqual({ nextStock: 15, nextCost: 6 });
  });

  it("reduz o saldo sem permitir estoque negativo", () => {
    expect(calculateExitBalance(12, 4)).toBe(8);
    expect(() => calculateExitBalance(3, 4)).toThrow("saldo disponível");
  });
});
