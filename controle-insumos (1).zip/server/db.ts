import { randomUUID } from "node:crypto";
import { and, desc, eq, gte, inArray, isNull, like, lte, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import initialData from "./initial-data.json";
import {
  accessAuditLogs,
  collaboratorInvites,
  dataSubjectRequests,
  invoiceItems,
  invoices,
  materialAliases,
  materials,
  outboundOrderItems,
  outboundOrders,
  outboundOrderStatusHistory,
  passwordCredentials,
  purchaseItems,
  purchaseOrderStatusHistory,
  purchaseOrders,
  refrigeratedUsage,
  stockAuditItems,
  stockAudits,
  stockMovements,
  stockRequests,
  suppliers,
  type InsertUser,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import { calculateEntryBalance, calculateExitBalance } from "./stockMath";
import { assertStockRequestCanBeReviewed } from "./stockRequestRules";
import { assertStockRequestCanBeCreated } from "./stockRequestWorkflow";
import { hashPassword, verifyPassword } from "./passwordAuth";
import { assertInvoiceStatusTransition, type InvoiceStatus } from "./invoiceStatusRules";
import { assertOutboundOrderReadyForDispatch, assertOutboundOrderTransition } from "./outboundOrderRules";
import { updateCollaboratorRole as applyCollaboratorRoleUpdate } from "./teamRoleUpdate";
import { assertOwnerAccountCanBeManaged } from "./teamOwnerProtection";
import { isOwnerIdentity } from "./ownerAccess";
import { assertPurchaseStatusTransition, shouldApplyPurchaseStock, type PurchaseStatus } from "./purchaseStatusRules";

let _db: ReturnType<typeof drizzle> | null = null;
let initialDataPromise: Promise<void> | null = null;

type MaterialInput = {
  name: string;
  category?: string | null;
  unit: string;
  defaultSupplierId?: number | null;
  averageCost?: number;
  stockQuantity?: number;
  minimumStock?: number;
  criticalStock?: number;
  status?: "active" | "inactive";
};

type ManualEntryInput = {
  supplierId: number;
  entryDate: Date;
  reference?: string | null;
  invoiceNumber?: string | null;
  company?: string | null;
  notes?: string | null;
  items: Array<{ materialId: number; quantity: number; unitPrice: number }>;
};

function materialSku(id: number) {
  return `INS-${String(id).padStart(6, "0")}`;
}

async function assignMissingMaterialSkus(db: ReturnType<typeof drizzle>) {
  const rows = await db.select({ id: materials.id }).from(materials).where(isNull(materials.sku));
  await Promise.all(rows.map(row => db.update(materials).set({ sku: materialSku(row.id) }).where(eq(materials.id, row.id))));
}

type SupplierInput = {
  name: string;
  email?: string | null;
  phone?: string | null;
  contact?: string | null;
  category?: string | null;
  leadTime?: string | null;
  notes?: string | null;
};

type ImportedInvoiceItem = {
  materialId?: number | null;
  sourceCode?: string | null;
  description: string;
  ncm?: string | null;
  unit: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
};

type ImportedInvoice = {
  number: string;
  accessKey?: string | null;
  issuerName: string;
  issuerDocument?: string | null;
  issueDate?: Date | null;
  totalAmount: number;
  items: ImportedInvoiceItem[];
};

type StockExitInput = {
  materialId: number;
  quantity: number;
  reason: string;
  notes?: string | null;
  actorName: string;
};

type StockRequestInput = {
  materialId: number;
  quantity: number;
  reason: string;
  notes?: string | null;
  requestedByUserId: number;
};

type StockRequestReviewInput = {
  requestId: number;
  decision: "approved" | "rejected";
  reviewNotes?: string | null;
  reviewedByUserId: number;
  reviewerOpenId?: string;
  reviewerName: string;
};

type OutboundOrderItemInput = {
  materialId: number;
  quantity: number;
};

type OutboundOrderInput = {
  recipientName: string;
  recipientDocument?: string | null;
  destination?: string | null;
  contact?: string | null;
  notes?: string | null;
  items: OutboundOrderItemInput[];
  createdByUserId: number;
};

type OutboundOrderUpdateInput = Omit<OutboundOrderInput, "createdByUserId">;

type SeedPurchase = (typeof initialData.purchases)[number];

export function normalizeName(value: string) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, " ")
    .trim();
}

function toNumber(value: unknown) {
  if (typeof value === "number") return value;
  return Number(value ?? 0);
}

function decimal(value: number | undefined | null, scale = 2) {
  return Number(value ?? 0).toFixed(scale);
}

function hasAffectedRow(result: unknown) {
  const candidate = Array.isArray(result) ? result[0] : result;
  return Number((candidate as { affectedRows?: number } | undefined)?.affectedRows ?? 0) > 0;
}

function dateFromWorkbook(value: string | null) {
  if (!value) return null;
  const parsed = new Date(value.endsWith("Z") ? value : `${value}Z`);
  return Number.isNaN(parsed.valueOf()) ? null : parsed;
}

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");

  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;

  textFields.forEach(field => {
    if (user[field] !== undefined) {
      const normalized = user[field] ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    }
  });

  values.lastSignedIn = user.lastSignedIn ?? new Date();
  updateSet.lastSignedIn = values.lastSignedIn;

  const invitation = user.email
    ? await db.select().from(collaboratorInvites).where(eq(collaboratorInvites.email, user.email)).limit(1)
    : [];
  const invitedRole = invitation[0]?.status === "pending" ? invitation[0].role : undefined;

  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  } else if (invitedRole) {
    values.role = invitedRole;
    updateSet.role = invitedRole;
  }

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });

  if (invitation[0]) {
    await db.update(collaboratorInvites).set({ status: "accepted", acceptedAt: new Date() }).where(eq(collaboratorInvites.id, invitation[0].id));
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getOrCreateVisitor() {
  const openId = "visitor:readonly";
  const existing = await getUserByOpenId(openId);
  if (existing) return existing;
  await upsertUser({ openId, name: "Visitante", email: null, loginMethod: "visitor", role: "user", lastSignedIn: new Date() });
  return getUserByOpenId(openId);
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result[0];
}

export async function recordAccessAudit(input: { actorUserId: number; action: string; role: "admin" | "user" | "diretoria" | "diretoria" }, options?: { db?: ReturnType<typeof drizzle> }) {
  const db = options?.db ?? (await getDb());
  if (!db) return;
  await db.insert(accessAuditLogs).values({ actorUserId: input.actorUserId, action: input.action.slice(0, 128), role: input.role });
}

export async function listAccessAuditLogs(limit = 100) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  return db
    .select({
      id: accessAuditLogs.id,
      action: accessAuditLogs.action,
      role: accessAuditLogs.role,
      occurredAt: accessAuditLogs.occurredAt,
      actorName: users.name,
      actorEmail: users.email,
    })
    .from(accessAuditLogs)
    .leftJoin(users, eq(accessAuditLogs.actorUserId, users.id))
    .orderBy(desc(accessAuditLogs.occurredAt), desc(accessAuditLogs.id))
    .limit(Math.min(Math.max(limit, 1), 200));
}

export async function createDataSubjectRequest(input: { requesterUserId: number; type: "access" | "correction" | "deletion" | "information"; message?: string | null }) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  const [created] = await db.insert(dataSubjectRequests).values({ requesterUserId: input.requesterUserId, type: input.type, message: input.message?.trim() || null }).$returningId();
  if (!created) throw new Error("Não foi possível registrar a solicitação de privacidade.");
  const request = await db.select().from(dataSubjectRequests).where(eq(dataSubjectRequests.id, created.id)).limit(1);
  return request[0];
}

export async function listMyDataSubjectRequests(requesterUserId: number) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  return db.select().from(dataSubjectRequests).where(eq(dataSubjectRequests.requesterUserId, requesterUserId)).orderBy(desc(dataSubjectRequests.createdAt), desc(dataSubjectRequests.id));
}

export async function listDataSubjectRequests() {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  return db
    .select({
      id: dataSubjectRequests.id,
      type: dataSubjectRequests.type,
      message: dataSubjectRequests.message,
      status: dataSubjectRequests.status,
      createdAt: dataSubjectRequests.createdAt,
      handledAt: dataSubjectRequests.handledAt,
      requesterName: users.name,
    })
    .from(dataSubjectRequests)
    .leftJoin(users, eq(dataSubjectRequests.requesterUserId, users.id))
    .orderBy(desc(dataSubjectRequests.createdAt), desc(dataSubjectRequests.id));
}

export async function updateDataSubjectRequest(input: { id: number; status: "pending" | "in_review" | "completed"; handledByUserId: number }) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  const updated = await db.update(dataSubjectRequests).set({ status: input.status, handledByUserId: input.handledByUserId, handledAt: input.status === "completed" ? new Date() : null }).where(eq(dataSubjectRequests.id, input.id));
  if (!hasAffectedRow(updated)) throw new Error("Solicitação de privacidade não encontrada.");
  const request = await db.select().from(dataSubjectRequests).where(eq(dataSubjectRequests.id, input.id)).limit(1);
  return request[0];
}

export async function getPasswordStatus(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  const credential = await db.select({ userId: passwordCredentials.userId }).from(passwordCredentials).where(eq(passwordCredentials.userId, userId)).limit(1);
  return { isConfigured: Boolean(credential[0]) };
}

export async function setUserPassword(input: { userId: number; password: string; currentPassword?: string | null }) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");

  const existing = await db.select({ passwordHash: passwordCredentials.passwordHash }).from(passwordCredentials).where(eq(passwordCredentials.userId, input.userId)).limit(1);
  if (existing[0] && !(input.currentPassword && await verifyPassword(input.currentPassword, existing[0].passwordHash))) {
    throw new Error("Informe a senha atual para definir uma nova senha.");
  }

  const passwordHash = await hashPassword(input.password);
  await db.insert(passwordCredentials).values({ userId: input.userId, passwordHash }).onDuplicateKeyUpdate({ set: { passwordHash } });
  await db.update(users).set({ sessionVersion: sql`${users.sessionVersion} + 1` }).where(eq(users.id, input.userId));
}

export async function resetUserPasswordByAdmin(input: { userId: number; actorUserId: number; actorOpenId: string; password: string }, options?: { db?: ReturnType<typeof drizzle> }) {
  if (input.userId === input.actorUserId) throw new Error("Use a área de segurança da sua conta para alterar a própria senha.");
  const db = options?.db ?? (await getDb());
  if (!db) throw new Error("Banco de dados indisponível.");

  const target = await db.select({ id: users.id, openId: users.openId }).from(users).where(eq(users.id, input.userId)).limit(1);
  if (!target[0]) throw new Error("Colaborador não encontrado.");
  assertOwnerAccountCanBeManaged({ targetOpenId: target[0].openId, actorOpenId: input.actorOpenId, ownerOpenId: ENV.ownerOpenId });

  const passwordHash = await hashPassword(input.password);
  await db.insert(passwordCredentials).values({ userId: input.userId, passwordHash }).onDuplicateKeyUpdate({ set: { passwordHash } });
  await db.update(users).set({ sessionVersion: sql`${users.sessionVersion} + 1` }).where(eq(users.id, input.userId));
}

export async function authenticateWithPassword(input: { email: string; password: string }) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");

  const credential = await db
    .select({ userId: passwordCredentials.userId, passwordHash: passwordCredentials.passwordHash })
    .from(passwordCredentials)
    .innerJoin(users, eq(passwordCredentials.userId, users.id))
    .where(eq(users.email, input.email.trim().toLowerCase()))
    .limit(1);
  if (!credential[0] || !(await verifyPassword(input.password, credential[0].passwordHash))) return undefined;

  const user = await getUserById(credential[0].userId);
  if (!user) return undefined;
  await db.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, user.id));
  return user;
}

export async function listTeamMembers() {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  const [registeredUsers, invitations] = await Promise.all([
    db.select({ id: users.id, openId: users.openId, name: users.name, email: users.email, role: users.role, lastSignedIn: users.lastSignedIn }).from(users),
    db.select().from(collaboratorInvites),
  ]);
  const registeredEmails = new Set(registeredUsers.map(user => user.email?.toLocaleLowerCase()).filter(Boolean));
  return [
    ...registeredUsers.map(user => ({ id: user.id, kind: "user" as const, name: user.name ?? "Usuário", email: user.email ?? "Sem e-mail", role: user.role, status: "active" as const, isOwner: isOwnerIdentity(user), createdAt: user.lastSignedIn })),
    ...invitations
      .filter(invitation => invitation.status === "pending" && !registeredEmails.has(invitation.email.toLocaleLowerCase()))
      .map(invitation => ({ id: invitation.id, kind: "invite" as const, name: invitation.name, email: invitation.email, role: invitation.role, status: "pending" as const, isOwner: false, createdAt: invitation.createdAt })),
  ].sort((first, second) => first.name.localeCompare(second.name));
}

export async function createCollaborator(input: { name: string; email: string; role: "admin" | "user" | "diretoria"; invitedByUserId: number }) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  const existingUser = await db.select({ id: users.id }).from(users).where(eq(users.email, input.email)).limit(1);
  if (existingUser[0]) {
    await db.update(users).set({ role: input.role }).where(eq(users.id, existingUser[0].id));
    return { kind: "user" as const, id: existingUser[0].id };
  }
  const [created] = await db
    .insert(collaboratorInvites)
    .values({ name: input.name, email: input.email, role: input.role, status: "pending", invitedByUserId: input.invitedByUserId })
    .onDuplicateKeyUpdate({ set: { name: input.name, role: input.role, status: "pending", invitedByUserId: input.invitedByUserId, acceptedAt: null } })
    .$returningId();
  return { kind: "invite" as const, id: created?.id };
}

export async function createPasswordCollaborator(input: { name: string; email: string; password: string; role: "admin" | "user" | "diretoria"; actorOpenId: string }) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  const email = input.email.trim().toLowerCase();
  const passwordHash = await hashPassword(input.password);

  return db.transaction(async tx => {
    const existing = await tx.select({ id: users.id, openId: users.openId, email: users.email }).from(users).where(eq(users.email, email)).limit(1);
    let userId = existing[0]?.id;
    if (userId) {
      assertOwnerAccountCanBeManaged({ targetOpenId: existing[0]?.openId ?? null, targetEmail: existing[0]?.email, actorOpenId: input.actorOpenId, ownerOpenId: ENV.ownerOpenId });
      await tx.update(users).set({ name: input.name.trim(), role: input.role }).where(eq(users.id, userId));
    } else {
      const [created] = await tx
        .insert(users)
        .values({
          openId: `password:${randomUUID()}`,
          name: input.name.trim(),
          email,
          loginMethod: "password",
          role: input.role,
          lastSignedIn: new Date(),
        })
        .$returningId();
      userId = created?.id;
    }
    if (!userId) throw new Error("Não foi possível criar a conta do colaborador.");

    await tx.insert(passwordCredentials).values({ userId, passwordHash }).onDuplicateKeyUpdate({ set: { passwordHash } });
    await tx.update(collaboratorInvites).set({ status: "accepted", acceptedAt: new Date() }).where(eq(collaboratorInvites.email, email));
    return { kind: "user" as const, id: userId };
  });
}

export async function updateCollaboratorRole(input: { kind: "user" | "invite"; id: number; role: "admin" | "user" | "diretoria"; actorUserId: number; actorOpenId: string }, options?: { db?: ReturnType<typeof drizzle> }) {
  const db = options?.db ?? (await getDb());
  if (!db) throw new Error("Banco de dados indisponível.");
  if (input.kind === "user") {
    const target = await db.select({ openId: users.openId, email: users.email }).from(users).where(eq(users.id, input.id)).limit(1);
    assertOwnerAccountCanBeManaged({ targetOpenId: target[0]?.openId ?? null, targetEmail: target[0]?.email, actorOpenId: input.actorOpenId, ownerOpenId: ENV.ownerOpenId });
  }
  return applyCollaboratorRoleUpdate(input, {
    getUserRole: async id => (await db.select({ role: users.role }).from(users).where(eq(users.id, id)).limit(1))[0]?.role ?? null,
    countAdministrators: async () => toNumber((await db.select({ count: sql<number>`count(*)` }).from(users).where(eq(users.role, "admin")))[0]?.count),
    updateUserRole: async (id, role) => { await db.update(users).set({ role }).where(eq(users.id, id)); },
    updateInviteRole: async (id, role) => { await db.update(collaboratorInvites).set({ role }).where(eq(collaboratorInvites.id, id)); },
  });
}

export async function deleteCollaborator(input: { kind: "user" | "invite"; id: number; actorUserId: number }, options?: { db?: ReturnType<typeof drizzle> }) {
  const db = options?.db ?? (await getDb());
  if (!db) throw new Error("Banco de dados indisponível.");

  return db.transaction(async tx => {
    if (input.kind === "invite") {
      const invitation = await tx.select({ id: collaboratorInvites.id }).from(collaboratorInvites).where(eq(collaboratorInvites.id, input.id)).limit(1);
      if (!invitation[0]) throw new Error("Convite não encontrado.");
      await tx.delete(collaboratorInvites).where(eq(collaboratorInvites.id, input.id));
      return { kind: "invite" as const, id: input.id };
    }

    const target = (await tx.select({ id: users.id, openId: users.openId, role: users.role, email: users.email }).from(users).where(eq(users.id, input.id)).limit(1))[0] ?? null;
    const { assertCollaboratorCanBeDeleted } = await import("./teamDeletion");
    await assertCollaboratorCanBeDeleted(
      { ...input, ownerOpenId: ENV.ownerOpenId },
      target,
      { countAdministrators: async () => toNumber((await tx.select({ count: sql<number>`count(*)` }).from(users).where(eq(users.role, "admin")))[0]?.count) }
    );
    if (!target) throw new Error("Usuário não encontrado.");

    await tx.delete(passwordCredentials).where(eq(passwordCredentials.userId, target.id));
    if (target.email) await tx.delete(collaboratorInvites).where(eq(collaboratorInvites.email, target.email));
    await tx.delete(users).where(eq(users.id, target.id));
    return { kind: "user" as const, id: target.id };
  });
}

async function seedInitialData() {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");

  const existingMaterials = await db.select({ count: sql<number>`count(*)` }).from(materials);
  if (toNumber(existingMaterials[0]?.count) === 0) {

  for (const supplier of initialData.suppliers) {
    await db
      .insert(suppliers)
      .values({
        name: supplier.name,
        email: supplier.email,
        phone: supplier.phone,
        contact: supplier.contact,
        category: supplier.category,
        leadTime: supplier.leadTime,
        notes: supplier.notes,
        sourceUpdatedAt: dateFromWorkbook(supplier.updatedAt),
      })
      .onDuplicateKeyUpdate({ set: { name: supplier.name } });
  }

  const supplierRows = await db.select({ id: suppliers.id, name: suppliers.name }).from(suppliers);
  const supplierByName = new Map(supplierRows.map(row => [normalizeName(row.name), row.id]));

  const purchaseStats = new Map<
    string,
    { quantity: number; total: number; lastSupplierId: number | null }
  >();
  for (const purchase of initialData.purchases) {
    const key = normalizeName(purchase.materialName);
    const current = purchaseStats.get(key) ?? { quantity: 0, total: 0, lastSupplierId: null };
    current.quantity += Number(purchase.quantity);
    current.total += Number(purchase.totalPrice);
    current.lastSupplierId = supplierByName.get(normalizeName(purchase.supplierName ?? "")) ?? null;
    purchaseStats.set(key, current);
  }

  for (const material of initialData.materials) {
    const key = normalizeName(material.name);
    const stats = purchaseStats.get(key);
    const averageCost = stats && stats.quantity > 0 ? stats.total / stats.quantity : 0;
    await db.insert(materials).values({
      name: material.name,
      normalizedName: key,
      category: material.category,
      unit: material.unit,
      defaultSupplierId: stats?.lastSupplierId ?? null,
      averageCost: decimal(averageCost),
      stockQuantity: "0.000",
      minimumStock: "0.000",
      status: "active",
    });
  }

  const materialRows = await db.select({ id: materials.id, normalizedName: materials.normalizedName }).from(materials);
  const materialByName = new Map(materialRows.map(row => [row.normalizedName, row.id]));

  const groups = new Map<string, SeedPurchase[]>();
  for (const purchase of initialData.purchases) {
    const key = [
      purchase.origin,
      purchase.invoiceNumber ?? "sem-nota",
      purchase.supplierName ?? "sem-fornecedor",
      purchase.orderDate ?? "sem-data",
      purchase.company ?? "",
    ].join("|");
    const group = groups.get(key) ?? [];
    group.push(purchase);
    groups.set(key, group);
  }

  for (const groupedPurchases of Array.from(groups.values())) {
    const sample = groupedPurchases[0];
    if (!sample) continue;
    const totalPrice = groupedPurchases.reduce((sum, item) => sum + Number(item.totalPrice), 0);
    const [order] = await db
      .insert(purchaseOrders)
      .values({
        source: sample.origin,
        supplierId: supplierByName.get(normalizeName(sample.supplierName ?? "")) ?? null,
        orderDate: dateFromWorkbook(sample.orderDate),
        invoiceNumber: sample.invoiceNumber,
        leadTime: sample.leadTime,
        company: sample.company,
        purchaseType: sample.purchaseType,
        category: sample.category,
        notes: sample.notes,
        totalPrice: decimal(totalPrice),
      })
      .$returningId();

    if (!order) continue;
    await db.insert(purchaseItems).values(
      groupedPurchases.map(purchase => ({
        purchaseOrderId: order.id,
        materialId: materialByName.get(normalizeName(purchase.materialName)) ?? null,
        description: purchase.materialName,
        unit: purchase.unit,
        quantity: decimal(Number(purchase.quantity), 3),
        unitPrice: decimal(Number(purchase.unitPrice)),
        totalPrice: decimal(Number(purchase.totalPrice)),
      }))
    );
  }
  }

  const existingUsage = await db.select({ count: sql<number>`count(*)` }).from(refrigeratedUsage);
  if (toNumber(existingUsage[0]?.count) === 0) {
    const materialRows = await db.select({ id: materials.id, normalizedName: materials.normalizedName }).from(materials);
    const materialByName = new Map(materialRows.map(row => [row.normalizedName, row.id]));
    await db.insert(refrigeratedUsage).values(
      initialData.refrigeratedUsage.map(item => ({
        materialId: materialByName.get(normalizeName(item.materialName)) ?? null,
        materialLabel: item.materialName,
        totalQuantity: decimal(Number(item.totalQuantity), 3),
        totalConsumptionValue: decimal(Number(item.totalConsumptionValue)),
      }))
    );
  }
}

export async function ensureInitialData() {
  if (!initialDataPromise) {
    initialDataPromise = seedInitialData().then(async () => {
      const db = await getDb();
      if (!db) throw new Error("Banco de dados indisponível.");
      await assignMissingMaterialSkus(db);
    }).catch(error => {
      initialDataPromise = null;
      throw error;
    });
  }
  return initialDataPromise;
}

export async function getDashboardData(input?: { months?: number }) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");

  const [materialCount, supplierCount, purchaseCount, invoiceCount, stockValue, stockQuantityTotal, lowStockRows, criticalStockRows, lowStockCount, criticalStockCount, pendingRequestCount, awaitingPurchaseCount] = await Promise.all([
    db.select({ count: sql<number>`count(*)` }).from(materials),
    db.select({ count: sql<number>`count(*)` }).from(suppliers),
    db.select({ count: sql<number>`count(*)` }).from(purchaseOrders),
    db.select({ count: sql<number>`count(*)` }).from(invoices),
    db.select({ value: sql<string>`coalesce(sum(${materials.stockQuantity} * ${materials.averageCost}), 0)` }).from(materials).where(eq(materials.status, "active")),
    db.select({ value: sql<string>`coalesce(sum(${materials.stockQuantity}), 0)` }).from(materials).where(eq(materials.status, "active")),
    db.select({ id: materials.id, name: materials.name, sku: materials.sku, stockQuantity: materials.stockQuantity, minimumStock: materials.minimumStock, criticalStock: materials.criticalStock }).from(materials).where(and(eq(materials.status, "active"), sql`${materials.stockQuantity} > ${materials.criticalStock}`, sql`${materials.stockQuantity} <= ${materials.minimumStock}`)).orderBy(materials.name).limit(8),
    db.select({ id: materials.id, name: materials.name, sku: materials.sku, stockQuantity: materials.stockQuantity, minimumStock: materials.minimumStock, criticalStock: materials.criticalStock }).from(materials).where(and(eq(materials.status, "active"), sql`${materials.stockQuantity} <= ${materials.criticalStock}`)).orderBy(materials.name).limit(8),
    db.select({ count: sql<number>`count(*)` }).from(materials).where(and(eq(materials.status, "active"), sql`${materials.stockQuantity} > ${materials.criticalStock}`, sql`${materials.stockQuantity} <= ${materials.minimumStock}`)),
    db.select({ count: sql<number>`count(*)` }).from(materials).where(and(eq(materials.status, "active"), sql`${materials.stockQuantity} <= ${materials.criticalStock}`)),
    db.select({ count: sql<number>`count(*)` }).from(stockRequests).where(eq(stockRequests.status, "pending")),
    db.select({ count: sql<number>`count(*)` }).from(purchaseOrders).where(eq(purchaseOrders.status, "awaiting_confirmation")),
  ]);

  const recentPurchases = await db
    .select({
      id: purchaseOrders.id,
      invoiceNumber: purchaseOrders.invoiceNumber,
      orderDate: purchaseOrders.orderDate,
      totalPrice: purchaseOrders.totalPrice,
      supplierName: suppliers.name,
      company: purchaseOrders.company,
    })
    .from(purchaseOrders)
    .leftJoin(suppliers, eq(purchaseOrders.supplierId, suppliers.id))
    .orderBy(desc(purchaseOrders.orderDate), desc(purchaseOrders.id))
    .limit(6);

  const recentMovements = await db
    .select({
      id: stockMovements.id,
      occurredAt: stockMovements.occurredAt,
      quantity: stockMovements.quantity,
      type: stockMovements.type,
      reference: stockMovements.reference,
      materialName: materials.name,
    })
    .from(stockMovements)
    .innerJoin(materials, eq(stockMovements.materialId, materials.id))
    .orderBy(desc(stockMovements.occurredAt), desc(stockMovements.id))
    .limit(6);

  const [purchaseChartRows, supplierChartRows, outboundStatusRows] = await Promise.all([
    db.select({ monthKey: sql<string>`DATE_FORMAT(${purchaseOrders.orderDate}, '%Y-%m')`, total: sql<number>`COALESCE(SUM(${purchaseOrders.totalPrice}), 0)` }).from(purchaseOrders).groupBy(purchaseOrders.orderDate),
    db.select({ supplierName: suppliers.name, total: sql<number>`COALESCE(SUM(${purchaseOrders.totalPrice}), 0)` }).from(purchaseOrders).leftJoin(suppliers, eq(purchaseOrders.supplierId, suppliers.id)).groupBy(suppliers.name),
    db.select({ status: outboundOrders.status, count: sql<number>`COUNT(*)` }).from(outboundOrders).groupBy(outboundOrders.status),
  ]);

  const monthFormatter = new Intl.DateTimeFormat("pt-BR", { month: "short" });
  const months = Math.min(12, Math.max(3, Math.floor(input?.months ?? 6)));
  const monthStarts = Array.from({ length: months }, (_, index) => { const date = new Date(); date.setDate(1); date.setMonth(date.getMonth() - (months - 1 - index)); return date; });
  const purchaseByMonth = new Map(monthStarts.map(date => [`${date.getFullYear()}-${date.getMonth()}`, 0]));
  for (const row of purchaseChartRows) {
    const key = row.monthKey ? `${row.monthKey.slice(0, 4)}-${Number(row.monthKey.slice(5, 7)) - 1}` : "";
    if (purchaseByMonth.has(key)) purchaseByMonth.set(key, (purchaseByMonth.get(key) ?? 0) + toNumber(row.total));
  }
  const purchaseTrend = monthStarts.map(date => ({ label: monthFormatter.format(date).replace(".", ""), total: purchaseByMonth.get(`${date.getFullYear()}-${date.getMonth()}`) ?? 0 }));
  const supplierTotals = new Map<string, number>();
  for (const row of supplierChartRows) { const name = row.supplierName ?? "Não informado"; supplierTotals.set(name, toNumber(row.total)); }
  const topSuppliers = Array.from(supplierTotals.entries()).sort((first, second) => second[1] - first[1]).slice(0, 5).map(([name, total]) => ({ name, total }));
  const orderStatuses = ["draft", "picking", "dispatched", "cancelled"] as const;
  const statusTotals = new Map(outboundStatusRows.map(row => [row.status, toNumber(row.count)]));
  const orderStatusDistribution = orderStatuses.map(status => ({ status, total: statusTotals.get(status) ?? 0 }));

  return {
    metrics: {
      materials: toNumber(materialCount[0]?.count),
      suppliers: toNumber(supplierCount[0]?.count),
      purchases: toNumber(purchaseCount[0]?.count),
      invoices: toNumber(invoiceCount[0]?.count),
      stockValue: toNumber(stockValue[0]?.value),
      stockQuantityTotal: toNumber(stockQuantityTotal[0]?.value),
      lowStock: toNumber(lowStockCount[0]?.count),
      criticalStock: toNumber(criticalStockCount[0]?.count),
      pendingRequests: toNumber(pendingRequestCount[0]?.count),
      awaitingPurchases: toNumber(awaitingPurchaseCount[0]?.count),
    },
    lowStockItems: lowStockRows,
    criticalStockItems: criticalStockRows,
    recentPurchases,
    recentMovements,
    charts: { purchaseTrend, topSuppliers, orderStatusDistribution },
  };
}

export async function listMaterials(input?: { search?: string; category?: string; status?: "active" | "inactive" }) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");

  const conditions = [];
  if (input?.search) conditions.push(or(like(materials.name, `%${input.search}%`), like(materials.sku, `%${input.search}%`), like(materials.category, `%${input.search}%`)));
  if (input?.category) conditions.push(eq(materials.category, input.category));
  if (input?.status) conditions.push(eq(materials.status, input.status));

  return db
    .select({
      id: materials.id,
      sku: materials.sku,
      name: materials.name,
      category: materials.category,
      unit: materials.unit,
      defaultSupplierId: materials.defaultSupplierId,
      supplierName: suppliers.name,
      averageCost: materials.averageCost,
      stockQuantity: materials.stockQuantity,
      minimumStock: materials.minimumStock,
      criticalStock: materials.criticalStock,
      status: materials.status,
      updatedAt: materials.updatedAt,
    })
    .from(materials)
    .leftJoin(suppliers, eq(materials.defaultSupplierId, suppliers.id))
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(materials.name);
}

export async function listSuppliers(input?: { search?: string }) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");

  const rows = await db
    .select({
      id: suppliers.id,
      name: suppliers.name,
      email: suppliers.email,
      phone: suppliers.phone,
      contact: suppliers.contact,
      category: suppliers.category,
      leadTime: suppliers.leadTime,
      notes: suppliers.notes,
      sourceUpdatedAt: suppliers.sourceUpdatedAt,
      updatedAt: suppliers.updatedAt,
    })
    .from(suppliers)
    .where(input?.search ? like(suppliers.name, `%${input.search}%`) : undefined)
    .orderBy(suppliers.name);

  const usages = await db
    .select({ supplierId: purchaseOrders.supplierId, count: sql<number>`count(*)` })
    .from(purchaseOrders)
    .groupBy(purchaseOrders.supplierId);
  const usageBySupplier = new Map(usages.map(row => [row.supplierId, toNumber(row.count)]));

  return rows.map(row => ({ ...row, purchaseCount: usageBySupplier.get(row.id) ?? 0 }));
}

export async function listPurchases(input?: { search?: string; company?: string }) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");

  const conditions = [];
  if (input?.company) conditions.push(eq(purchaseOrders.company, input.company));
  if (input?.search) {
    conditions.push(
      or(
        like(suppliers.name, `%${input.search}%`),
        like(purchaseOrders.invoiceNumber, `%${input.search}%`),
        like(purchaseOrders.notes, `%${input.search}%`)
      )
    );
  }

  const rows = await db
    .select({
      id: purchaseOrders.id,
      source: purchaseOrders.source,
      status: purchaseOrders.status,
      stockAppliedAt: purchaseOrders.stockAppliedAt,
      supplierName: suppliers.name,
      orderDate: purchaseOrders.orderDate,
      invoiceNumber: purchaseOrders.invoiceNumber,
      leadTime: purchaseOrders.leadTime,
      company: purchaseOrders.company,
      purchaseType: purchaseOrders.purchaseType,
      category: purchaseOrders.category,
      notes: purchaseOrders.notes,
      totalPrice: purchaseOrders.totalPrice,
    })
    .from(purchaseOrders)
    .leftJoin(suppliers, eq(purchaseOrders.supplierId, suppliers.id))
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(purchaseOrders.orderDate), desc(purchaseOrders.id));

  if (!rows.length) return [];
  const counts = await db
    .select({ purchaseOrderId: purchaseItems.purchaseOrderId, count: sql<number>`count(*)` })
    .from(purchaseItems)
    .where(inArray(purchaseItems.purchaseOrderId, rows.map(row => row.id)))
    .groupBy(purchaseItems.purchaseOrderId);
  const countByOrderId = new Map(counts.map(row => [row.purchaseOrderId, toNumber(row.count)]));
  return rows.map(row => ({ ...row, itemCount: countByOrderId.get(row.id) ?? 0 }));
}

export async function getPurchaseDetails(purchaseOrderId: number) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");

  const order = await db
    .select({
      id: purchaseOrders.id,
      source: purchaseOrders.source,
      status: purchaseOrders.status,
      stockAppliedAt: purchaseOrders.stockAppliedAt,
      supplierName: suppliers.name,
      orderDate: purchaseOrders.orderDate,
      invoiceNumber: purchaseOrders.invoiceNumber,
      leadTime: purchaseOrders.leadTime,
      company: purchaseOrders.company,
      purchaseType: purchaseOrders.purchaseType,
      category: purchaseOrders.category,
      notes: purchaseOrders.notes,
      totalPrice: purchaseOrders.totalPrice,
    })
    .from(purchaseOrders)
    .leftJoin(suppliers, eq(purchaseOrders.supplierId, suppliers.id))
    .where(eq(purchaseOrders.id, purchaseOrderId))
    .limit(1);
  if (!order[0]) throw new Error("Pedido não encontrado.");

  const items = await db
    .select({
      id: purchaseItems.id,
      description: purchaseItems.description,
      unit: purchaseItems.unit,
      quantity: purchaseItems.quantity,
      unitPrice: purchaseItems.unitPrice,
      totalPrice: purchaseItems.totalPrice,
      materialName: materials.name,
    })
    .from(purchaseItems)
    .leftJoin(materials, eq(purchaseItems.materialId, materials.id))
    .where(eq(purchaseItems.purchaseOrderId, purchaseOrderId))
    .orderBy(purchaseItems.id);

  return { ...order[0], items };
}

export async function createManualEntry(input: ManualEntryInput, options?: { db?: ReturnType<typeof drizzle>; skipInitialData?: boolean; actorUserId?: number }) {
  if (!options?.skipInitialData) await ensureInitialData();
  const db = options?.db ?? (await getDb());
  if (!db) throw new Error("Banco de dados indisponível.");
  if (!input.items.length) throw new Error("Inclua ao menos um insumo na entrada.");
  if (new Set(input.items.map(item => item.materialId)).size !== input.items.length) throw new Error("Inclua cada insumo apenas uma vez na entrada.");
  if (input.items.some(item => !Number.isFinite(item.quantity) || item.quantity <= 0 || !Number.isFinite(item.unitPrice) || item.unitPrice < 0)) throw new Error("Informe quantidades e custos válidos para todos os itens.");

  const created = await db.transaction(async tx => {
    const supplier = await tx.select({ id: suppliers.id }).from(suppliers).where(eq(suppliers.id, input.supplierId)).limit(1);
    if (!supplier[0]) throw new Error("Fornecedor não encontrado.");
    const materialRows = await tx.select().from(materials).where(inArray(materials.id, input.items.map(item => item.materialId)));
    const materialById = new Map(materialRows.map(material => [material.id, material]));
    for (const item of input.items) if (!materialById.get(item.materialId) || materialById.get(item.materialId)?.status !== "active") throw new Error("Um dos insumos selecionados não está disponível.");

    const totalPrice = input.items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0);
    const [order] = await tx.insert(purchaseOrders).values({
      source: "manual_entry",
      status: "received",
      supplierId: input.supplierId,
      orderDate: input.entryDate,
      invoiceNumber: input.invoiceNumber?.trim() || input.reference?.trim() || null,
      company: input.company?.trim() || null,
      purchaseType: "Entrada manual",
      category: "Entrada manual",
      notes: input.notes?.trim() || null,
      totalPrice: decimal(totalPrice),
    }).$returningId();
    if (!order) throw new Error("Não foi possível criar o pedido de entrada.");

    await tx.insert(purchaseItems).values(input.items.map(item => {
      const material = materialById.get(item.materialId)!;
      return { purchaseOrderId: order.id, materialId: material.id, description: material.name, unit: material.unit, quantity: decimal(item.quantity, 3), unitPrice: decimal(item.unitPrice), totalPrice: decimal(item.quantity * item.unitPrice) };
    }));
    if (options?.actorUserId) await tx.insert(purchaseOrderStatusHistory).values({ purchaseOrderId: order.id, previousStatus: null, nextStatus: "received", changedByUserId: options.actorUserId, notes: "Entrada manual criada como recebida." });

    return { id: order.id, totalPrice };
  });
  return created;
}

export async function updatePurchaseStatus(
  purchaseOrderId: number,
  nextStatus: PurchaseStatus,
  changedByUserId: number,
  options?: { db?: ReturnType<typeof drizzle>; skipInitialData?: boolean }
) {
  if (!options?.skipInitialData) await ensureInitialData();
  const db = options?.db ?? (await getDb());
  if (!db) throw new Error("Banco de dados indisponível.");

  const result = await db.transaction(async tx => {
    const orderRows = await tx.select().from(purchaseOrders).where(eq(purchaseOrders.id, purchaseOrderId)).limit(1);
    const order = orderRows[0];
    if (!order) throw new Error("Compra não encontrada.");
    const currentStatus = order.status as PurchaseStatus;
    assertPurchaseStatusTransition(currentStatus, nextStatus);
    if (currentStatus === nextStatus) return order;

    let stockAppliedAt = order.stockAppliedAt;
    if (shouldApplyPurchaseStock(nextStatus, stockAppliedAt)) {
      const items = await tx.select().from(purchaseItems).where(eq(purchaseItems.purchaseOrderId, purchaseOrderId));
      if (!items.length) throw new Error("A compra não possui itens para entrada no estoque.");
      const materialIds = items.map(item => item.materialId).filter((id): id is number => Boolean(id));
      if (materialIds.length !== items.length) throw new Error("Todos os itens precisam estar vinculados a um insumo antes da conferência.");
      const materialRows = await tx.select().from(materials).where(inArray(materials.id, materialIds));
      const materialById = new Map(materialRows.map(material => [material.id, material]));
      for (const item of items) {
        const material = materialById.get(item.materialId!);
        if (!material) throw new Error("Um dos insumos da compra não está mais disponível.");
        const { nextStock, nextCost } = calculateEntryBalance(toNumber(material.stockQuantity), toNumber(material.averageCost), toNumber(item.quantity), toNumber(item.unitPrice));
        await tx.update(materials).set({ stockQuantity: decimal(nextStock, 3), averageCost: decimal(nextCost), defaultSupplierId: order.supplierId }).where(eq(materials.id, material.id));
        await tx.insert(stockMovements).values({ materialId: material.id, type: "entry", quantity: decimal(toNumber(item.quantity), 3), balanceAfter: decimal(nextStock, 3), unitCost: decimal(toNumber(item.unitPrice)), reference: `Compra #${purchaseOrderId}${order.invoiceNumber ? ` / NF ${order.invoiceNumber}` : ""}`, notes: `Entrada registrada após conferência da compra #${purchaseOrderId}.` });
      }
      stockAppliedAt = new Date();
    }

    await tx.update(purchaseOrders).set({ status: nextStatus, stockAppliedAt }).where(eq(purchaseOrders.id, purchaseOrderId));
    await tx.insert(purchaseOrderStatusHistory).values({ purchaseOrderId, previousStatus: currentStatus, nextStatus, changedByUserId, notes: nextStatus === "confirmed" ? "Compra conferida e saldo atualizado no estoque." : "Status da compra atualizado." });
    return { ...order, status: nextStatus, stockAppliedAt };
  });
  return result;
}

export async function listInvoices() {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");

  return db
    .select({
      id: invoices.id,
      number: invoices.number,
      issuerName: invoices.issuerName,
      issueDate: invoices.issueDate,
      totalAmount: invoices.totalAmount,
      status: invoices.status,
      createdAt: invoices.createdAt,
      itemCount: sql<number>`count(${invoiceItems.id})`,
      pendingItemCount: sql<number>`coalesce(sum(case when ${invoiceItems.materialId} is null then 1 else 0 end), 0)`,
    })
    .from(invoices)
    .leftJoin(invoiceItems, eq(invoiceItems.invoiceId, invoices.id))
    .groupBy(invoices.id)
    .orderBy(desc(invoices.createdAt));
}

export async function listStockMovements() {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");

  return db
    .select({
      id: stockMovements.id,
      occurredAt: stockMovements.occurredAt,
      type: stockMovements.type,
      quantity: stockMovements.quantity,
      balanceAfter: stockMovements.balanceAfter,
      unitCost: stockMovements.unitCost,
      reference: stockMovements.reference,
      materialName: materials.name,
      invoiceNumber: invoices.number,
    })
    .from(stockMovements)
    .innerJoin(materials, eq(stockMovements.materialId, materials.id))
    .leftJoin(invoices, eq(stockMovements.invoiceId, invoices.id))
    .orderBy(desc(stockMovements.occurredAt), desc(stockMovements.id));
}

export async function listStockRequests(input: { userId: number; isAdmin: boolean }) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");

  return db
    .select({
      id: stockRequests.id,
      materialId: stockRequests.materialId,
      materialName: materials.name,
      unit: materials.unit,
      availableStock: materials.stockQuantity,
      requestedByUserId: stockRequests.requestedByUserId,
      requesterName: users.name,
      requesterEmail: users.email,
      quantity: stockRequests.quantity,
      reason: stockRequests.reason,
      notes: stockRequests.notes,
      status: stockRequests.status,
      reviewedByUserId: stockRequests.reviewedByUserId,
      reviewedAt: stockRequests.reviewedAt,
      reviewNotes: stockRequests.reviewNotes,
      outboundOrderId: stockRequests.outboundOrderId,
      outboundOrderCode: outboundOrders.code,
      createdAt: stockRequests.createdAt,
    })
    .from(stockRequests)
    .innerJoin(materials, eq(stockRequests.materialId, materials.id))
    .leftJoin(users, eq(stockRequests.requestedByUserId, users.id))
    .leftJoin(outboundOrders, eq(stockRequests.outboundOrderId, outboundOrders.id))
    .where(input.isAdmin ? undefined : eq(stockRequests.requestedByUserId, input.userId))
    .orderBy(desc(stockRequests.createdAt), desc(stockRequests.id));
}

export async function listOutboundOrders(input?: { status?: "draft" | "picking" | "dispatched" | "cancelled" }) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");

  return db
    .select({
      id: outboundOrders.id,
      code: outboundOrders.code,
      recipientName: outboundOrders.recipientName,
      destination: outboundOrders.destination,
      status: outboundOrders.status,
      createdAt: outboundOrders.createdAt,
      pickingStartedAt: outboundOrders.pickingStartedAt,
      dispatchedAt: outboundOrders.dispatchedAt,
      sourceRequestId: stockRequests.id,
      itemCount: sql<number>`count(${outboundOrderItems.id})`,
      requestedQuantity: sql<string>`coalesce(sum(${outboundOrderItems.requestedQuantity}), 0)`,
      pickedQuantity: sql<string>`coalesce(sum(${outboundOrderItems.pickedQuantity}), 0)`,
      totalValue: sql<string>`coalesce(sum(${outboundOrderItems.requestedQuantity} * ${outboundOrderItems.unitCost}), 0)`,
      dispatchedValue: sql<string>`coalesce(sum(case when ${outboundOrders.status} = 'dispatched' then ${outboundOrderItems.pickedQuantity} * ${outboundOrderItems.unitCost} else 0 end), 0)`,
    })
    .from(outboundOrders)
    .leftJoin(outboundOrderItems, eq(outboundOrderItems.outboundOrderId, outboundOrders.id))
    .leftJoin(stockRequests, eq(stockRequests.outboundOrderId, outboundOrders.id))
    .where(input?.status ? eq(outboundOrders.status, input.status) : undefined)
    .groupBy(
      outboundOrders.id,
      outboundOrders.code,
      outboundOrders.recipientName,
      outboundOrders.destination,
      outboundOrders.status,
      outboundOrders.createdAt,
      outboundOrders.pickingStartedAt,
      outboundOrders.dispatchedAt,
      stockRequests.id
    )
    .orderBy(desc(outboundOrders.createdAt), desc(outboundOrders.id));
}

export async function getOutboundOrderById(
  outboundOrderId: number,
  options?: { db?: ReturnType<typeof drizzle>; skipInitialData?: boolean }
) {
  if (!options?.skipInitialData) await ensureInitialData();
  const db = options?.db ?? (await getDb());
  if (!db) throw new Error("Banco de dados indisponível.");

  const order = await db.select().from(outboundOrders).where(eq(outboundOrders.id, outboundOrderId)).limit(1);
  if (!order[0]) throw new Error("Pedido de saída não encontrado.");
  const items = await db
    .select({
      id: outboundOrderItems.id,
      materialId: outboundOrderItems.materialId,
      materialName: materials.name,
      unit: outboundOrderItems.unit,
      requestedQuantity: outboundOrderItems.requestedQuantity,
      pickedQuantity: outboundOrderItems.pickedQuantity,
      unitCost: outboundOrderItems.unitCost,
      availableStock: materials.stockQuantity,
    })
    .from(outboundOrderItems)
    .innerJoin(materials, eq(outboundOrderItems.materialId, materials.id))
    .where(eq(outboundOrderItems.outboundOrderId, outboundOrderId))
    .orderBy(materials.name);

  const statusHistory = await db
    .select({
      id: outboundOrderStatusHistory.id,
      previousStatus: outboundOrderStatusHistory.previousStatus,
      nextStatus: outboundOrderStatusHistory.nextStatus,
      notes: outboundOrderStatusHistory.notes,
      changedAt: outboundOrderStatusHistory.changedAt,
      changedByName: users.name,
      changedByEmail: users.email,
    })
    .from(outboundOrderStatusHistory)
    .leftJoin(users, eq(outboundOrderStatusHistory.changedByUserId, users.id))
    .where(eq(outboundOrderStatusHistory.outboundOrderId, outboundOrderId))
    .orderBy(desc(outboundOrderStatusHistory.changedAt), desc(outboundOrderStatusHistory.id));

  return { ...order[0], items, statusHistory };
}

export async function createOutboundOrder(input: OutboundOrderInput) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  if (new Set(input.items.map(item => item.materialId)).size !== input.items.length) throw new Error("Inclua cada insumo apenas uma vez no pedido.");

  const materialRows = await db.select().from(materials).where(inArray(materials.id, input.items.map(item => item.materialId)));
  const materialById = new Map(materialRows.map(material => [material.id, material]));
  for (const item of input.items) {
    const material = materialById.get(item.materialId);
    if (!material || material.status !== "active") throw new Error("Um dos insumos selecionados não está disponível.");
    if (item.quantity > toNumber(material.stockQuantity)) throw new Error(`A quantidade de ${material.name} é maior que o saldo disponível.`);
  }

  const code = `PS-${new Date().toISOString().slice(0, 10).replaceAll("-", "")}-${randomUUID().slice(0, 6).toUpperCase()}`;
  const [created] = await db.insert(outboundOrders).values({
    code,
    recipientName: input.recipientName.trim(),
    recipientDocument: input.recipientDocument?.trim() || null,
    destination: input.destination?.trim() || null,
    contact: input.contact?.trim() || null,
    notes: input.notes?.trim() || null,
    createdByUserId: input.createdByUserId,
  }).$returningId();
  if (!created) throw new Error("Não foi possível criar o pedido de saída.");

  await db.insert(outboundOrderItems).values(input.items.map(item => {
    const material = materialById.get(item.materialId)!;
    return {
      outboundOrderId: created.id,
      materialId: item.materialId,
      unit: material.unit,
      requestedQuantity: decimal(item.quantity, 3),
      unitCost: material.averageCost,
    };
  }));

  await db.insert(outboundOrderStatusHistory).values({
    outboundOrderId: created.id,
    nextStatus: "draft",
    changedByUserId: input.createdByUserId,
    notes: "Pedido criado manualmente pelo administrador.",
  });

  return getOutboundOrderById(created.id);
}

export async function updateOutboundOrder(outboundOrderId: number, input: OutboundOrderUpdateInput, options?: { db?: ReturnType<typeof drizzle>; skipInitialData?: boolean }) {
  if (!options?.skipInitialData) await ensureInitialData();
  const db = options?.db ?? (await getDb());
  if (!db) throw new Error("Banco de dados indisponível.");
  if (new Set(input.items.map(item => item.materialId)).size !== input.items.length) throw new Error("Inclua cada insumo apenas uma vez no pedido.");

  await db.transaction(async tx => {
    const order = await tx.select({ status: outboundOrders.status }).from(outboundOrders).where(eq(outboundOrders.id, outboundOrderId)).limit(1);
    if (!order[0]) throw new Error("Pedido de saída não encontrado.");
    if (order[0].status !== "draft") throw new Error("Apenas pedidos em rascunho podem ser alterados. Cancele o pedido para preservar o histórico após a separação.");
    const materialRows = await tx.select({ id: materials.id, unit: materials.unit, averageCost: materials.averageCost, status: materials.status }).from(materials).where(inArray(materials.id, input.items.map(item => item.materialId)));
    const materialById = new Map(materialRows.map(material => [material.id, material]));
    for (const item of input.items) if (!materialById.get(item.materialId) || materialById.get(item.materialId)?.status !== "active") throw new Error("Um dos insumos selecionados não está disponível.");
    await tx.update(outboundOrders).set({ recipientName: input.recipientName.trim(), recipientDocument: input.recipientDocument?.trim() || null, destination: input.destination?.trim() || null, contact: input.contact?.trim() || null, notes: input.notes?.trim() || null }).where(eq(outboundOrders.id, outboundOrderId));
    await tx.delete(outboundOrderItems).where(eq(outboundOrderItems.outboundOrderId, outboundOrderId));
    await tx.insert(outboundOrderItems).values(input.items.map(item => {
      const material = materialById.get(item.materialId)!;
      return { outboundOrderId, materialId: item.materialId, unit: material.unit, requestedQuantity: decimal(item.quantity, 3), unitCost: material.averageCost };
    }));
  });
  return getOutboundOrderById(outboundOrderId, options);
}

export async function deleteOutboundOrder(outboundOrderId: number, options?: { db?: ReturnType<typeof drizzle>; skipInitialData?: boolean }) {
  if (!options?.skipInitialData) await ensureInitialData();
  const db = options?.db ?? (await getDb());
  if (!db) throw new Error("Banco de dados indisponível.");
  return db.transaction(async tx => {
    const order = await tx.select({ id: outboundOrders.id, status: outboundOrders.status }).from(outboundOrders).where(eq(outboundOrders.id, outboundOrderId)).limit(1);
    if (!order[0]) throw new Error("Pedido de saída não encontrado.");
    if (order[0].status === "dispatched") throw new Error("Pedidos expedidos não podem ser excluídos porque já possuem baixa de estoque e histórico.");
    const sourceRequest = await tx.select({ id: stockRequests.id }).from(stockRequests).where(eq(stockRequests.outboundOrderId, outboundOrderId)).limit(1);
    if (sourceRequest[0]) throw new Error("Pedidos criados a partir de uma solicitação não podem ser excluídos. Cancele o pedido para preservar o vínculo e o histórico.");
    await tx.delete(outboundOrderStatusHistory).where(eq(outboundOrderStatusHistory.outboundOrderId, outboundOrderId));
    await tx.delete(outboundOrderItems).where(eq(outboundOrderItems.outboundOrderId, outboundOrderId));
    await tx.delete(outboundOrders).where(eq(outboundOrders.id, outboundOrderId));
    return { id: outboundOrderId, deleted: true as const };
  });
}

export async function beginOutboundOrderPicking(outboundOrderId: number, changedByUserId: number, options?: { db?: ReturnType<typeof drizzle>; skipInitialData?: boolean }) {
  if (!options?.skipInitialData) await ensureInitialData();
  const db = options?.db ?? (await getDb());
  if (!db) throw new Error("Banco de dados indisponível.");
  const updated = await db.update(outboundOrders).set({ status: "picking", pickingStartedAt: new Date() }).where(and(eq(outboundOrders.id, outboundOrderId), eq(outboundOrders.status, "draft")));
  if (!hasAffectedRow(updated)) throw new Error("Somente pedidos aguardando separação podem iniciar o picking.");
  await db.insert(outboundOrderStatusHistory).values({ outboundOrderId, previousStatus: "draft", nextStatus: "picking", changedByUserId, notes: "Separação iniciada." });
  return getOutboundOrderById(outboundOrderId, options);
}

export async function updateOutboundOrderItemPicking(input: { outboundOrderItemId: number; pickedQuantity: number }) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  const item = await db
    .select({
      id: outboundOrderItems.id,
      outboundOrderId: outboundOrderItems.outboundOrderId,
      requestedQuantity: outboundOrderItems.requestedQuantity,
      status: outboundOrders.status,
      materialId: outboundOrderItems.materialId,
      materialName: materials.name,
      stockQuantity: materials.stockQuantity,
    })
    .from(outboundOrderItems)
    .innerJoin(outboundOrders, eq(outboundOrderItems.outboundOrderId, outboundOrders.id))
    .innerJoin(materials, eq(outboundOrderItems.materialId, materials.id))
    .where(eq(outboundOrderItems.id, input.outboundOrderItemId))
    .limit(1);
  if (!item[0]) throw new Error("Item do pedido não encontrado.");
  if (item[0].status !== "picking") throw new Error("O picking só pode ser atualizado durante a separação.");
  if (input.pickedQuantity < 0 || input.pickedQuantity > toNumber(item[0].requestedQuantity)) throw new Error("A quantidade separada deve estar entre zero e a quantidade solicitada.");
  if (input.pickedQuantity > toNumber(item[0].stockQuantity)) throw new Error(`O saldo atual de ${item[0].materialName} não é suficiente para essa separação.`);

  await db.update(outboundOrderItems).set({ pickedQuantity: decimal(input.pickedQuantity, 3) }).where(eq(outboundOrderItems.id, input.outboundOrderItemId));
  return getOutboundOrderById(item[0].outboundOrderId);
}

export async function dispatchOutboundOrder(
  outboundOrderId: number,
  actorName: string,
  changedByUserIdOrOptions?: number | { db?: ReturnType<typeof drizzle>; skipInitialData?: boolean },
  maybeOptions?: { db?: ReturnType<typeof drizzle>; skipInitialData?: boolean }
) {
  const changedByUserId = typeof changedByUserIdOrOptions === "number" ? changedByUserIdOrOptions : undefined;
  const options = typeof changedByUserIdOrOptions === "number" ? maybeOptions : changedByUserIdOrOptions;
  if (!options?.skipInitialData) await ensureInitialData();
  const db = options?.db ?? (await getDb());
  if (!db) throw new Error("Banco de dados indisponível.");

  await db.transaction(async tx => {
    const order = await tx.select().from(outboundOrders).where(eq(outboundOrders.id, outboundOrderId)).limit(1);
    if (!order[0]) throw new Error("Pedido de saída não encontrado.");
    const items = await tx.select().from(outboundOrderItems).where(eq(outboundOrderItems.outboundOrderId, outboundOrderId));
    assertOutboundOrderReadyForDispatch({ status: order[0].status, items: items.map(item => ({ requestedQuantity: toNumber(item.requestedQuantity), pickedQuantity: toNumber(item.pickedQuantity) })) });

    const orderUpdate = await tx
      .update(outboundOrders)
      .set({ status: "dispatched", dispatchedAt: new Date() })
      .where(and(eq(outboundOrders.id, outboundOrderId), eq(outboundOrders.status, "picking")));
    if (!hasAffectedRow(orderUpdate)) throw new Error("Este pedido já foi expedido ou alterado por outro usuário.");

    const materialRows = await tx.select().from(materials).where(inArray(materials.id, items.map(item => item.materialId)));
    const materialById = new Map(materialRows.map(material => [material.id, material]));
    for (const item of items) {
      const material = materialById.get(item.materialId);
      if (!material) throw new Error("Um dos insumos do pedido não está mais disponível.");
      const quantity = toNumber(item.pickedQuantity);
      const nextStock = calculateExitBalance(toNumber(material.stockQuantity), quantity);
      await tx.update(materials).set({ stockQuantity: decimal(nextStock, 3) }).where(eq(materials.id, material.id));
      await tx.insert(stockMovements).values({
        materialId: material.id,
        outboundOrderId,
        type: "exit",
        quantity: decimal(-quantity, 3),
        balanceAfter: decimal(nextStock, 3),
        unitCost: material.averageCost,
        reference: `Pedido ${order[0].code}`,
        notes: `Saída expedida para ${order[0].recipientName}. Responsável: ${actorName}.`,
      });
    }

    await tx.insert(outboundOrderStatusHistory).values({ outboundOrderId, previousStatus: "picking", nextStatus: "dispatched", changedByUserId, notes: `Pedido expedido por ${actorName}.` });
  });

  return getOutboundOrderById(outboundOrderId, options);
}

export async function cancelOutboundOrder(outboundOrderId: number, changedByUserId: number, options?: { db?: ReturnType<typeof drizzle>; skipInitialData?: boolean }) {
  if (!options?.skipInitialData) await ensureInitialData();
  const db = options?.db ?? (await getDb());
  if (!db) throw new Error("Banco de dados indisponível.");
  const order = await db.select({ status: outboundOrders.status }).from(outboundOrders).where(eq(outboundOrders.id, outboundOrderId)).limit(1);
  if (!order[0]) throw new Error("Pedido de saída não encontrado.");
  assertOutboundOrderTransition(order[0].status, "cancelled");
  await db.update(outboundOrders).set({ status: "cancelled", cancelledAt: new Date() }).where(eq(outboundOrders.id, outboundOrderId));
  await db.insert(outboundOrderStatusHistory).values({ outboundOrderId, previousStatus: order[0].status, nextStatus: "cancelled", changedByUserId, notes: "Pedido cancelado pelo administrador." });
  return getOutboundOrderById(outboundOrderId, options);
}

export async function getOutboundOrderReport(input?: { startDate?: Date; endDate?: Date; status?: "draft" | "picking" | "dispatched" | "cancelled"; sector?: string }) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  const conditions = [];
  if (input?.startDate) conditions.push(gte(outboundOrders.createdAt, input.startDate));
  if (input?.endDate) conditions.push(lte(outboundOrders.createdAt, input.endDate));
  if (input?.status) conditions.push(eq(outboundOrders.status, input.status));
  if (input?.sector) conditions.push(eq(materials.category, input.sector));
  const where = conditions.length ? and(...conditions) : undefined;

  const [summary] = await db
    .select({
      orderCount: sql<number>`count(distinct ${outboundOrders.id})`,
      requestedQuantity: sql<string>`coalesce(sum(${outboundOrderItems.requestedQuantity}), 0)`,
      pickedQuantity: sql<string>`coalesce(sum(${outboundOrderItems.pickedQuantity}), 0)`,
      requestedValue: sql<string>`coalesce(sum(${outboundOrderItems.requestedQuantity} * ${outboundOrderItems.unitCost}), 0)`,
      dispatchedCost: sql<string>`coalesce(sum(case when ${outboundOrders.status} = 'dispatched' then ${outboundOrderItems.pickedQuantity} * ${outboundOrderItems.unitCost} else 0 end), 0)`,
      dispatchedValue: sql<string>`coalesce(sum(case when ${outboundOrders.status} = 'dispatched' then ${outboundOrderItems.pickedQuantity} * ${outboundOrderItems.unitCost} else 0 end), 0)`,
    })
    .from(outboundOrders)
    .leftJoin(outboundOrderItems, eq(outboundOrderItems.outboundOrderId, outboundOrders.id))
    .leftJoin(materials, eq(outboundOrderItems.materialId, materials.id))
    .where(where);

  const statuses = await db
    .select({ status: outboundOrders.status, count: sql<number>`count(*)` })
    .from(outboundOrders)
    .innerJoin(outboundOrderItems, eq(outboundOrderItems.outboundOrderId, outboundOrders.id))
    .innerJoin(materials, eq(outboundOrderItems.materialId, materials.id))
    .where(where)
    .groupBy(outboundOrders.status);

  const dispatchedConditions = [...conditions, eq(outboundOrders.status, "dispatched")];
  const materialsSummary = await db
    .select({
      materialId: materials.id,
      materialName: materials.name,
      sector: materials.category,
      unit: materials.unit,
      quantity: sql<string>`coalesce(sum(${outboundOrderItems.pickedQuantity}), 0)`,
      cost: sql<string>`coalesce(sum(${outboundOrderItems.pickedQuantity} * ${outboundOrderItems.unitCost}), 0)`,
    })
    .from(outboundOrderItems)
    .innerJoin(outboundOrders, eq(outboundOrderItems.outboundOrderId, outboundOrders.id))
    .innerJoin(materials, eq(outboundOrderItems.materialId, materials.id))
    .where(and(...dispatchedConditions))
    .groupBy(materials.id)
    .orderBy(desc(sql`sum(${outboundOrderItems.pickedQuantity})`))
    .limit(10);

  const orders = await db
    .select({
      id: outboundOrders.id,
      code: outboundOrders.code,
      recipientName: outboundOrders.recipientName,
      destination: outboundOrders.destination,
      status: outboundOrders.status,
      createdAt: outboundOrders.createdAt,
      pickingStartedAt: outboundOrders.pickingStartedAt,
      dispatchedAt: outboundOrders.dispatchedAt,
      sourceRequestId: stockRequests.id,
      itemCount: sql<number>`count(${outboundOrderItems.id})`,
      requestedQuantity: sql<string>`coalesce(sum(${outboundOrderItems.requestedQuantity}), 0)`,
      pickedQuantity: sql<string>`coalesce(sum(${outboundOrderItems.pickedQuantity}), 0)`,
      totalValue: sql<string>`coalesce(sum(${outboundOrderItems.requestedQuantity} * ${outboundOrderItems.unitCost}), 0)`,
      dispatchedValue: sql<string>`coalesce(sum(case when ${outboundOrders.status} = 'dispatched' then ${outboundOrderItems.pickedQuantity} * ${outboundOrderItems.unitCost} else 0 end), 0)`,
    })
    .from(outboundOrders)
    .innerJoin(outboundOrderItems, eq(outboundOrderItems.outboundOrderId, outboundOrders.id))
    .innerJoin(materials, eq(outboundOrderItems.materialId, materials.id))
    .leftJoin(stockRequests, eq(stockRequests.outboundOrderId, outboundOrders.id))
    .where(where)
    .groupBy(outboundOrders.id, outboundOrders.code, outboundOrders.recipientName, outboundOrders.destination, outboundOrders.status, outboundOrders.createdAt, outboundOrders.pickingStartedAt, outboundOrders.dispatchedAt, stockRequests.id)
    .orderBy(desc(outboundOrders.createdAt), desc(outboundOrders.id));
  return { summary: { orderCount: toNumber(summary?.orderCount), requestedQuantity: summary?.requestedQuantity ?? "0", pickedQuantity: summary?.pickedQuantity ?? "0", requestedValue: summary?.requestedValue ?? "0", dispatchedCost: summary?.dispatchedCost ?? "0", dispatchedValue: summary?.dispatchedValue ?? "0" }, statuses, materials: materialsSummary, orders };
}

export async function listRefrigeratedUsage() {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");

  return db
    .select({
      id: refrigeratedUsage.id,
      materialLabel: refrigeratedUsage.materialLabel,
      materialName: materials.name,
      totalQuantity: refrigeratedUsage.totalQuantity,
      totalConsumptionValue: refrigeratedUsage.totalConsumptionValue,
    })
    .from(refrigeratedUsage)
    .leftJoin(materials, eq(refrigeratedUsage.materialId, materials.id))
    .orderBy(desc(refrigeratedUsage.totalConsumptionValue));
}

export async function createMaterial(input: MaterialInput) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  const normalizedName = normalizeName(input.name);

  const [created] = await db
    .insert(materials)
    .values({
      name: input.name.trim(),
      normalizedName,
      category: input.category ?? null,
      unit: input.unit,
      defaultSupplierId: input.defaultSupplierId ?? null,
      averageCost: decimal(input.averageCost),
      stockQuantity: decimal(input.stockQuantity, 3),
      minimumStock: decimal(input.minimumStock, 3),
      criticalStock: decimal(input.criticalStock, 3),
      status: input.status ?? "active",
    })
    .$returningId();
  if (created) await db.update(materials).set({ sku: materialSku(created.id) }).where(eq(materials.id, created.id));
  return created;
}

export async function createStockRequest(
  input: StockRequestInput,
  options?: { db?: ReturnType<typeof drizzle>; skipInitialData?: boolean }
) {
  if (!options?.skipInitialData) await ensureInitialData();
  const db = options?.db ?? (await getDb());
  if (!db) throw new Error("Banco de dados indisponível.");

  const material = await db
    .select({ id: materials.id, stockQuantity: materials.stockQuantity, status: materials.status })
    .from(materials)
    .where(eq(materials.id, input.materialId))
    .limit(1);

  if (!material[0] || material[0].status !== "active") throw new Error("O insumo selecionado não está disponível para solicitação.");
  assertStockRequestCanBeCreated({ quantity: input.quantity, availableStock: toNumber(material[0].stockQuantity) });

  const [created] = await db
    .insert(stockRequests)
    .values({
      materialId: input.materialId,
      requestedByUserId: input.requestedByUserId,
      quantity: decimal(input.quantity, 3),
      reason: input.reason.trim(),
      notes: input.notes?.trim() || null,
    })
    .$returningId();

  return created;
}

export async function updateStockRequest(requestId: number, input: Omit<StockRequestInput, "requestedByUserId">, options?: { db?: ReturnType<typeof drizzle>; skipInitialData?: boolean }) {
  if (!options?.skipInitialData) await ensureInitialData();
  const db = options?.db ?? (await getDb());
  if (!db) throw new Error("Banco de dados indisponível.");
  return db.transaction(async tx => {
    const request = await tx.select({ status: stockRequests.status, outboundOrderId: stockRequests.outboundOrderId }).from(stockRequests).where(eq(stockRequests.id, requestId)).limit(1);
    if (!request[0]) throw new Error("Solicitação não encontrada.");
    if (request[0].status !== "pending" || request[0].outboundOrderId) throw new Error("Apenas solicitações pendentes e sem pedido vinculado podem ser alteradas.");
    const material = await tx.select({ id: materials.id, stockQuantity: materials.stockQuantity, status: materials.status }).from(materials).where(eq(materials.id, input.materialId)).limit(1);
    if (!material[0] || material[0].status !== "active") throw new Error("O insumo selecionado não está disponível para solicitação.");
    assertStockRequestCanBeCreated({ quantity: input.quantity, availableStock: toNumber(material[0].stockQuantity) });
    const updated = await tx.update(stockRequests).set({ materialId: input.materialId, quantity: decimal(input.quantity, 3), reason: input.reason.trim(), notes: input.notes?.trim() || null }).where(and(eq(stockRequests.id, requestId), eq(stockRequests.status, "pending")));
    if (!hasAffectedRow(updated)) throw new Error("Esta solicitação não pode mais ser alterada.");
    return { id: requestId, updated: true as const };
  });
}

export async function deleteStockRequest(requestId: number, options?: { db?: ReturnType<typeof drizzle>; skipInitialData?: boolean }) {
  if (!options?.skipInitialData) await ensureInitialData();
  const db = options?.db ?? (await getDb());
  if (!db) throw new Error("Banco de dados indisponível.");
  const request = await db.select({ status: stockRequests.status, outboundOrderId: stockRequests.outboundOrderId }).from(stockRequests).where(eq(stockRequests.id, requestId)).limit(1);
  if (!request[0]) throw new Error("Solicitação não encontrada.");
  if (request[0].outboundOrderId || request[0].status === "approved") throw new Error("Solicitações aprovadas ou vinculadas a pedidos não podem ser excluídas. Cancele o pedido relacionado para preservar o histórico.");
  const deleted = await db.delete(stockRequests).where(eq(stockRequests.id, requestId));
  if (!hasAffectedRow(deleted)) throw new Error("Esta solicitação não pode mais ser excluída.");
  return { id: requestId, deleted: true as const };
}

export async function updateMaterial(id: number, input: MaterialInput) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  await db
    .update(materials)
    .set({
      name: input.name.trim(),
      normalizedName: normalizeName(input.name),
      category: input.category ?? null,
      unit: input.unit,
      defaultSupplierId: input.defaultSupplierId ?? null,
      averageCost: decimal(input.averageCost),
      stockQuantity: decimal(input.stockQuantity, 3),
      minimumStock: decimal(input.minimumStock, 3),
      criticalStock: decimal(input.criticalStock, 3),
      status: input.status ?? "active",
    })
    .where(eq(materials.id, id));
}

export async function createSupplier(input: SupplierInput) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  const [created] = await db.insert(suppliers).values(input).$returningId();
  return created;
}

export async function updateSupplier(id: number, input: SupplierInput) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  await db.update(suppliers).set(input).where(eq(suppliers.id, id));
}

export async function importInvoice(input: ImportedInvoice) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");

  if (input.accessKey) {
    const existing = await db.select({ id: invoices.id }).from(invoices).where(eq(invoices.accessKey, input.accessKey)).limit(1);
    if (existing[0]) throw new Error("Esta nota fiscal já foi importada.");
  }

  const [invoice] = await db
    .insert(invoices)
    .values({
      number: input.number,
      accessKey: input.accessKey ?? null,
      issuerName: input.issuerName,
      issuerDocument: input.issuerDocument ?? null,
      issueDate: input.issueDate ?? null,
      totalAmount: decimal(input.totalAmount),
      status: "draft",
    })
    .$returningId();
  if (!invoice) throw new Error("Não foi possível criar a conferência da nota.");

  await db.insert(invoiceItems).values(
    input.items.map(item => ({
      invoiceId: invoice.id,
      materialId: item.materialId ?? null,
      sourceCode: item.sourceCode ?? null,
      description: item.description,
      ncm: item.ncm ?? null,
      unit: item.unit || "Und",
      quantity: decimal(item.quantity, 3),
      unitPrice: decimal(item.unitPrice),
      totalPrice: decimal(item.totalPrice),
      matchStatus: item.materialId ? ("matched" as const) : ("unmatched" as const),
    }))
  );

  return getInvoiceById(invoice.id);
}

export async function getInvoiceById(
  invoiceId: number,
  options?: { db?: ReturnType<typeof drizzle>; skipInitialData?: boolean }
) {
  if (!options?.skipInitialData) await ensureInitialData();
  const db = options?.db ?? (await getDb());
  if (!db) throw new Error("Banco de dados indisponível.");

  const invoice = await db.select().from(invoices).where(eq(invoices.id, invoiceId)).limit(1);
  if (!invoice[0]) throw new Error("Nota fiscal não encontrada.");

  const items = await db
    .select({
      id: invoiceItems.id,
      materialId: invoiceItems.materialId,
      materialName: materials.name,
      sourceCode: invoiceItems.sourceCode,
      description: invoiceItems.description,
      ncm: invoiceItems.ncm,
      unit: invoiceItems.unit,
      quantity: invoiceItems.quantity,
      unitPrice: invoiceItems.unitPrice,
      totalPrice: invoiceItems.totalPrice,
      matchStatus: invoiceItems.matchStatus,
    })
    .from(invoiceItems)
    .leftJoin(materials, eq(invoiceItems.materialId, materials.id))
    .where(eq(invoiceItems.invoiceId, invoiceId))
    .orderBy(invoiceItems.id);

  return { ...invoice[0], items };
}

export async function matchInvoiceItem(invoiceItemId: number, materialId: number) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");

  const item = await db.select().from(invoiceItems).where(eq(invoiceItems.id, invoiceItemId)).limit(1);
  if (!item[0]) throw new Error("Item da nota não encontrado.");

  await db.update(invoiceItems).set({ materialId, matchStatus: "matched" }).where(eq(invoiceItems.id, invoiceItemId));
  await db
    .insert(materialAliases)
    .values({
      materialId,
      label: item[0].description,
      normalizedLabel: normalizeName(item[0].description),
    })
    .onDuplicateKeyUpdate({ set: { materialId } });

  return getInvoiceById(item[0].invoiceId);
}

export async function confirmInvoice(
  invoiceId: number,
  options?: { db?: ReturnType<typeof drizzle>; skipInitialData?: boolean }
) {
  if (!options?.skipInitialData) await ensureInitialData();
  const db = options?.db ?? (await getDb());
  if (!db) throw new Error("Banco de dados indisponível.");

  await db.transaction(async tx => {
    const invoice = await tx.select().from(invoices).where(eq(invoices.id, invoiceId)).limit(1);
    if (!invoice[0]) throw new Error("Nota fiscal não encontrada.");
    if (invoice[0].status === "confirmed") throw new Error("Esta nota fiscal já foi confirmada.");

    const items = await tx.select().from(invoiceItems).where(eq(invoiceItems.invoiceId, invoiceId));
    if (!items.length) throw new Error("A nota fiscal não possui itens para entrada.");
    if (items.some(item => !item.materialId)) throw new Error("Vincule todos os itens da nota antes de confirmar a entrada.");

    const materialIds = items.map(item => item.materialId).filter((id): id is number => Boolean(id));
    const materialRows = await tx.select().from(materials).where(inArray(materials.id, materialIds));
    const materialById = new Map(materialRows.map(material => [material.id, material]));

    for (const item of items) {
      const material = materialById.get(item.materialId!);
      if (!material) throw new Error("Um dos insumos vinculados não está mais disponível.");

      const currentStock = toNumber(material.stockQuantity);
      const currentCost = toNumber(material.averageCost);
      const quantity = toNumber(item.quantity);
      const unitPrice = toNumber(item.unitPrice);
      const { nextStock, nextCost } = calculateEntryBalance(currentStock, currentCost, quantity, unitPrice);

      await tx
        .update(materials)
        .set({ stockQuantity: decimal(nextStock, 3), averageCost: decimal(nextCost) })
        .where(eq(materials.id, material.id));
      await tx.insert(stockMovements).values({
        materialId: material.id,
        invoiceId,
        type: "entry",
        quantity: decimal(quantity, 3),
        balanceAfter: decimal(nextStock, 3),
        unitCost: decimal(unitPrice),
        reference: `NF ${invoice[0].number}`,
        notes: `Entrada confirmada a partir da nota fiscal ${invoice[0].number}.`,
      });
      await tx.update(invoiceItems).set({ matchStatus: "confirmed" }).where(eq(invoiceItems.id, item.id));
    }

    await tx.update(invoices).set({ status: "confirmed", confirmedAt: new Date() }).where(eq(invoices.id, invoiceId));
  });

  return getInvoiceById(invoiceId, options);
}

export async function updateInvoiceStatus(
  invoiceId: number,
  nextStatus: InvoiceStatus,
  options?: { db?: ReturnType<typeof drizzle>; skipInitialData?: boolean }
) {
  if (!options?.skipInitialData) await ensureInitialData();
  if (nextStatus === "confirmed") return confirmInvoice(invoiceId, options);

  const db = options?.db ?? (await getDb());
  if (!db) throw new Error("Banco de dados indisponível.");
  const invoice = await db.select({ status: invoices.status }).from(invoices).where(eq(invoices.id, invoiceId)).limit(1);
  if (!invoice[0]) throw new Error("Nota fiscal não encontrada.");
  assertInvoiceStatusTransition(invoice[0].status, nextStatus);
  return getInvoiceById(invoiceId, options);
}

export async function recordStockExit(input: StockExitInput) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");

  await db.transaction(async tx => {
    const material = await tx.select().from(materials).where(eq(materials.id, input.materialId)).limit(1);
    if (!material[0]) throw new Error("Insumo não encontrado.");
    const currentStock = toNumber(material[0].stockQuantity);
    const nextStock = calculateExitBalance(currentStock, input.quantity);

    await tx.update(materials).set({ stockQuantity: decimal(nextStock, 3) }).where(eq(materials.id, input.materialId));
    await tx.insert(stockMovements).values({
      materialId: input.materialId,
      type: "exit",
      quantity: decimal(-input.quantity, 3),
      balanceAfter: decimal(nextStock, 3),
      unitCost: material[0].averageCost,
      reference: `Baixa: ${input.reason}`,
      notes: `Responsável: ${input.actorName}.${input.notes ? ` ${input.notes}` : ""}`,
    });
  });
}

export async function reviewStockRequest(
  input: StockRequestReviewInput,
  options?: { db?: ReturnType<typeof drizzle>; skipInitialData?: boolean }
) {
  if (!options?.skipInitialData) await ensureInitialData();
  const db = options?.db ?? (await getDb());
  if (!db) throw new Error("Banco de dados indisponível.");

  return db.transaction(async tx => {
    const request = await tx
      .select({
        id: stockRequests.id,
        materialId: stockRequests.materialId,
        requestedByUserId: stockRequests.requestedByUserId,
        quantity: stockRequests.quantity,
        reason: stockRequests.reason,
        notes: stockRequests.notes,
        status: stockRequests.status,
      requesterName: users.name,
      requesterEmail: users.email,
    })
    .from(stockRequests)
    .leftJoin(users, eq(stockRequests.requestedByUserId, users.id))
      .where(eq(stockRequests.id, input.requestId))
      .limit(1);

    const currentRequest = request[0];
    if (!currentRequest) throw new Error("Solicitação não encontrada.");
    assertStockRequestCanBeReviewed({
      status: currentRequest.status,
      requestedByUserId: currentRequest.requestedByUserId,
      reviewedByUserId: input.reviewedByUserId,
      allowSelfReview: input.reviewerOpenId === ENV.ownerOpenId,
    });

    if (input.decision === "rejected") {
      const reviewUpdate = await tx
        .update(stockRequests)
        .set({ status: "rejected", reviewedByUserId: input.reviewedByUserId, reviewedAt: new Date(), reviewNotes: input.reviewNotes?.trim() || null })
        .where(and(eq(stockRequests.id, input.requestId), eq(stockRequests.status, "pending")));
      if (!hasAffectedRow(reviewUpdate)) throw new Error("Esta solicitação já foi analisada por outro administrador.");
      return { id: input.requestId, status: "rejected" as const, outboundOrderId: null };
    }

    const material = await tx
      .select({ id: materials.id, unit: materials.unit, averageCost: materials.averageCost, stockQuantity: materials.stockQuantity, status: materials.status })
      .from(materials)
      .where(eq(materials.id, currentRequest.materialId))
      .limit(1);
    if (!material[0] || material[0].status !== "active") throw new Error("O insumo solicitado não está disponível para separação.");

    const quantity = toNumber(currentRequest.quantity);
    assertStockRequestCanBeCreated({ quantity, availableStock: toNumber(material[0].stockQuantity) });
    const code = `PS-${new Date().toISOString().slice(0, 10).replaceAll("-", "")}-${randomUUID().slice(0, 6).toUpperCase()}`;
    const [order] = await tx
      .insert(outboundOrders)
      .values({
        code,
        recipientName: currentRequest.requesterName ?? "Colaborador solicitante",
        recipientDocument: null,
        destination: currentRequest.reason,
        contact: currentRequest.requesterEmail ?? null,
        notes: `Solicitação #${currentRequest.id}.${currentRequest.notes ? ` ${currentRequest.notes}` : ""}`,
        createdByUserId: input.reviewedByUserId,
      })
      .$returningId();
    if (!order) throw new Error("Não foi possível criar o pedido de separação.");

    await tx.insert(outboundOrderItems).values({
      outboundOrderId: order.id,
      materialId: currentRequest.materialId,
      unit: material[0].unit,
      requestedQuantity: decimal(quantity, 3),
      unitCost: material[0].averageCost,
    });

    await tx.insert(outboundOrderStatusHistory).values({
      outboundOrderId: order.id,
      nextStatus: "draft",
      changedByUserId: input.reviewedByUserId,
      notes: `Pedido criado automaticamente a partir da solicitação #${currentRequest.id}.`,
    });

    const reviewUpdate = await tx
      .update(stockRequests)
      .set({
        status: "approved",
        reviewedByUserId: input.reviewedByUserId,
        reviewedAt: new Date(),
        reviewNotes: input.reviewNotes?.trim() || null,
        outboundOrderId: order.id,
      })
      .where(and(eq(stockRequests.id, input.requestId), eq(stockRequests.status, "pending")));
    if (!hasAffectedRow(reviewUpdate)) throw new Error("Esta solicitação já foi analisada por outro administrador.");

    return { id: input.requestId, status: "approved" as const, outboundOrderId: order.id };
  });
}


export async function listStockAudits() {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  const audits = await db.select({ id: stockAudits.id, code: stockAudits.code, status: stockAudits.status, notes: stockAudits.notes, startedAt: stockAudits.startedAt, completedAt: stockAudits.completedAt, startedByName: users.name }).from(stockAudits).leftJoin(users, eq(stockAudits.startedByUserId, users.id)).orderBy(desc(stockAudits.startedAt), desc(stockAudits.id));
  const counts = await db.select({ auditId: stockAuditItems.auditId, total: sql<number>`count(*)`, counted: sql<number>`sum(case when ${stockAuditItems.countedQuantity} is not null then 1 else 0 end)`, discrepancies: sql<number>`sum(case when ${stockAuditItems.difference} <> 0 then 1 else 0 end)` }).from(stockAuditItems).groupBy(stockAuditItems.auditId);
  const countByAudit = new Map(counts.map(row => [row.auditId, row]));
  return audits.map(audit => ({ ...audit, totalItems: toNumber(countByAudit.get(audit.id)?.total), countedItems: toNumber(countByAudit.get(audit.id)?.counted), discrepancyItems: toNumber(countByAudit.get(audit.id)?.discrepancies) }));
}

export async function getStockAudit(auditId: number) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  const audit = (await db.select().from(stockAudits).where(eq(stockAudits.id, auditId)).limit(1))[0];
  if (!audit) throw new Error("Auditoria não encontrada.");
  const items = await db.select({ id: stockAuditItems.id, materialId: stockAuditItems.materialId, materialName: materials.name, sku: materials.sku, unit: materials.unit, systemQuantity: stockAuditItems.systemQuantity, countedQuantity: stockAuditItems.countedQuantity, difference: stockAuditItems.difference, adjustmentAppliedAt: stockAuditItems.adjustmentAppliedAt }).from(stockAuditItems).innerJoin(materials, eq(stockAuditItems.materialId, materials.id)).where(eq(stockAuditItems.auditId, auditId)).orderBy(materials.name);
  return { ...audit, items };
}

export async function createStockAudit(input: { startedByUserId: number; notes?: string | null }) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  const auditId = await db.transaction(async tx => {
    const code = `AUD-${Date.now().toString(36).toUpperCase()}`;
    const [created] = await tx.insert(stockAudits).values({ code, startedByUserId: input.startedByUserId, notes: input.notes?.trim() || null }).$returningId();
    if (!created) throw new Error("Não foi possível iniciar a auditoria.");
    const activeMaterials = await tx.select({ id: materials.id, stockQuantity: materials.stockQuantity }).from(materials).where(eq(materials.status, "active"));
    if (activeMaterials.length) await tx.insert(stockAuditItems).values(activeMaterials.map(material => ({ auditId: created.id, materialId: material.id, systemQuantity: decimal(toNumber(material.stockQuantity), 3) })));
    return created.id;
  });
  return getStockAudit(auditId);
}

export async function updateStockAuditCounts(input: { auditId: number; items: Array<{ materialId: number; countedQuantity: number }> }) {
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  return db.transaction(async tx => {
    const audit = (await tx.select({ id: stockAudits.id, status: stockAudits.status }).from(stockAudits).where(eq(stockAudits.id, input.auditId)).limit(1))[0];
    if (!audit) throw new Error("Auditoria não encontrada.");
    if (audit.status !== "draft") throw new Error("Auditorias concluídas não podem ser alteradas.");
    for (const item of input.items) {
      const existing = (await tx.select({ id: stockAuditItems.id, systemQuantity: stockAuditItems.systemQuantity }).from(stockAuditItems).where(and(eq(stockAuditItems.auditId, input.auditId), eq(stockAuditItems.materialId, item.materialId))).limit(1))[0];
      if (!existing) throw new Error("O insumo informado não pertence a esta auditoria.");
      await tx.update(stockAuditItems).set({ countedQuantity: decimal(item.countedQuantity, 3), difference: decimal(item.countedQuantity - toNumber(existing.systemQuantity), 3) }).where(eq(stockAuditItems.id, existing.id));
    }
    return input.auditId;
  });
}

export async function completeStockAudit(input: { auditId: number; completedByUserId: number }) {
  await ensureInitialData();
  const db = await getDb();
  if (!db) throw new Error("Banco de dados indisponível.");
  return db.transaction(async tx => {
    const audit = (await tx.select().from(stockAudits).where(eq(stockAudits.id, input.auditId)).limit(1))[0];
    if (!audit) throw new Error("Auditoria não encontrada.");
    if (audit.status !== "draft") throw new Error("Esta auditoria já foi concluída.");
    const items = await tx.select().from(stockAuditItems).where(eq(stockAuditItems.auditId, input.auditId));
    if (!items.length || items.some(item => item.countedQuantity === null)) throw new Error("Informe a contagem de todos os insumos antes de concluir.");
    for (const item of items) {
      const material = (await tx.select({ stockQuantity: materials.stockQuantity, averageCost: materials.averageCost }).from(materials).where(eq(materials.id, item.materialId)).limit(1))[0];
      if (!material) throw new Error("Insumo da auditoria não encontrado.");
      const counted = toNumber(item.countedQuantity);
      const difference = counted - toNumber(material.stockQuantity);
      if (difference !== 0) {
        await tx.update(materials).set({ stockQuantity: decimal(counted, 3) }).where(eq(materials.id, item.materialId));
        await tx.insert(stockMovements).values({ materialId: item.materialId, type: "adjustment", quantity: decimal(difference, 3), balanceAfter: decimal(counted, 3), unitCost: material.averageCost, reference: `Auditoria ${audit.code}`, notes: `Ajuste autorizado pelo usuário #${input.completedByUserId}.` });
      }
      await tx.update(stockAuditItems).set({ difference: decimal(difference, 3), adjustmentAppliedAt: new Date() }).where(eq(stockAuditItems.id, item.id));
    }
    await tx.update(stockAudits).set({ status: "completed", completedByUserId: input.completedByUserId, completedAt: new Date() }).where(eq(stockAudits.id, input.auditId));
    return input.auditId;
  });
}


export async function revokeUserSessions(userId: number, options?: { db?: ReturnType<typeof drizzle> }) {
  const db = options?.db ?? (await getDb());
  if (!db) return;
  await db.update(users).set({ sessionVersion: sql`${users.sessionVersion} + 1` }).where(eq(users.id, userId));
}
