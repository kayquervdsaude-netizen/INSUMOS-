import { describe, expect, it } from "vitest";
import { assertInvoiceStatusTransition } from "./invoiceStatusRules";

describe("transições de status da nota fiscal", () => {
  it("permite manter uma nota em conferência ou confirmá-la", () => {
    expect(() => assertInvoiceStatusTransition("draft", "draft")).not.toThrow();
    expect(() => assertInvoiceStatusTransition("draft", "confirmed")).not.toThrow();
  });

  it("bloqueia o retorno de uma nota confirmada para conferência", () => {
    expect(() => assertInvoiceStatusTransition("confirmed", "draft")).toThrow("entrada já foi registrada");
  });
});
