import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({
  authenticateWithPassword: vi.fn(),
  createSessionToken: vi.fn(),
}));

vi.mock("./db", () => ({
  authenticateWithPassword: mocks.authenticateWithPassword,
}));

vi.mock("./_core/sdk", () => ({
  sdk: {
    createSessionToken: mocks.createSessionToken,
  },
}));

import { appRouter } from "./routers";
import { COOKIE_NAME } from "../shared/const";

type CookieCall = { name: string; value: string; options: Record<string, unknown> };

function createUnauthenticatedContext(): { ctx: TrpcContext; cookies: CookieCall[] } {
  const cookies: CookieCall[] = [];
  return {
    ctx: {
      user: null,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: { cookie: (name: string, value: string, options: Record<string, unknown>) => cookies.push({ name, value, options }) } as TrpcContext["res"],
    },
    cookies,
  };
}

describe("auth.passwordLogin", () => {
  beforeEach(() => {
    mocks.authenticateWithPassword.mockReset();
    mocks.createSessionToken.mockReset();
  });

  it("autentica credenciais válidas e grava a sessão segura", async () => {
    const user = { id: 7, openId: "password:user-7", name: "Ana Silva", email: "ana@empresa.com", loginMethod: "password", role: "user" as const, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() };
    mocks.authenticateWithPassword.mockResolvedValue(user);
    mocks.createSessionToken.mockResolvedValue("signed-local-session");
    const { ctx, cookies } = createUnauthenticatedContext();

    const result = await appRouter.createCaller(ctx).auth.passwordLogin({ email: "ana@empresa.com", password: "Senha-forte-2026" });

    expect(result).toEqual({ ...user, isOwner: false });
    expect(mocks.authenticateWithPassword).toHaveBeenCalledWith({ email: "ana@empresa.com", password: "Senha-forte-2026" });
    expect(mocks.createSessionToken).toHaveBeenCalledWith("password:user-7", { name: "Ana Silva" });
    expect(cookies).toHaveLength(1);
    expect(cookies[0]).toMatchObject({ name: COOKIE_NAME, value: "signed-local-session", options: { httpOnly: true, secure: true, sameSite: "none", path: "/" } });
  });

  it("rejeita credenciais inválidas sem gravar uma sessão", async () => {
    mocks.authenticateWithPassword.mockResolvedValue(undefined);
    const { ctx, cookies } = createUnauthenticatedContext();

    await expect(appRouter.createCaller(ctx).auth.passwordLogin({ email: "ana@empresa.com", password: "senha-invalida" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    expect(mocks.createSessionToken).not.toHaveBeenCalled();
    expect(cookies).toHaveLength(0);
  });
});
