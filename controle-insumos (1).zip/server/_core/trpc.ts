import { NOT_ADMIN_ERR_MSG, UNAUTHED_ERR_MSG } from '@shared/const';
import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";
import { ENV } from "./env";
import { isOwnerIdentity } from "../ownerAccess";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
});

export const router = t.router;
export const publicProcedure = t.procedure;

const requireUser = t.middleware(async opts => {
  const { ctx, next } = opts;
  if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  if (ctx.user.loginMethod === "visitor" && opts.type === "mutation") {
    throw new TRPCError({ code: "FORBIDDEN", message: "O modo visitante permite apenas visualização." });
  }
  if (ctx.user.role === "diretoria" && opts.type === "mutation") {
    throw new TRPCError({ code: "FORBIDDEN", message: "O perfil Diretoria possui acesso somente para leitura." });
  }
  return next({ ctx: { ...ctx, user: ctx.user } });
});

export const protectedProcedure = t.procedure.use(requireUser);

async function auditAdministrativeAction(user: NonNullable<TrpcContext["user"]>, action: string) {
  try {
    const database = await import("../db");
    await database.recordAccessAudit({ actorUserId: user.id, action, role: user.role });
  } catch (error) {
    if (process.env.NODE_ENV !== "test") console.error("[Auditoria] Não foi possível registrar a ação administrativa.", error);
  }
}

export const adminProcedure = t.procedure.use(
  t.middleware(async opts => {
    const { ctx, next } = opts;
    if (!ctx.user || ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    const result = await next({ ctx: { ...ctx, user: ctx.user } });
    if (opts.type === "mutation") await auditAdministrativeAction(ctx.user, opts.path);
    return result;
  }),
);

export const adminOrDiretoriaProcedure = t.procedure.use(
  t.middleware(async opts => {
    const { ctx, next } = opts;
    if (!ctx.user || (ctx.user.role !== "admin" && ctx.user.role !== "diretoria")) throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    if (opts.type === "mutation") throw new TRPCError({ code: "FORBIDDEN", message: "O perfil Diretoria possui acesso somente para leitura." });
    return next({ ctx: { ...ctx, user: ctx.user } });
  }),
);

export const diretoriaProcedure = t.procedure.use(
  t.middleware(async opts => {
    const { ctx, next } = opts;
    if (!ctx.user || ctx.user.role !== "diretoria") throw new TRPCError({ code: "FORBIDDEN", message: "Esta operação é exclusiva da Diretoria." });
    if (opts.type === "mutation") throw new TRPCError({ code: "FORBIDDEN", message: "O perfil Diretoria possui acesso somente para leitura." });
    return next({ ctx: { ...ctx, user: ctx.user } });
  }),
);

export const ownerProcedure = t.procedure.use(
  t.middleware(async opts => {
    const { ctx, next } = opts;
    if (!ctx.user || !isOwnerIdentity(ctx.user)) throw new TRPCError({ code: "FORBIDDEN", message: "Esta operação é exclusiva do administrador proprietário." });
    const result = await next({ ctx: { ...ctx, user: ctx.user } });
    if (opts.type === "mutation") await auditAdministrativeAction(ctx.user, opts.path);
    return result;
  }),
);
