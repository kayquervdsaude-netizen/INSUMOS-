export function assertOwnerAccountCanBeManaged(input: { targetOpenId: string | null; targetEmail?: string | null; actorOpenId: string; ownerOpenId: string }) {
  const targetIsOwner = input.targetOpenId === input.ownerOpenId || input.targetEmail?.trim().toLowerCase() === "kayque.santos@rvdsaude.com.br";
  if (targetIsOwner && input.actorOpenId !== input.ownerOpenId) {
    throw new Error("A conta proprietária não pode ser alterada por outro administrador.");
  }
}
