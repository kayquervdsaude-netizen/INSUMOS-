import { describe, expect, it, vi } from "vitest";
import { confirmInvoice, updateInvoiceStatus } from "./db";

function selectQuery(rows: unknown[]) {
  const result = Promise.resolve(rows) as Promise<unknown[]> & { limit: () => Promise<unknown[]> };
  result.limit = async () => rows;
  return {
    from: () => ({
      where: () => result,
      leftJoin: () => ({ where: () => ({ orderBy: async () => rows }) }),
    }),
  };
}

function updateQuery() {
  return { set: () => ({ where: async () => undefined }) };
}

function confirmedInvoiceDatabase() {
  const movementValues = vi.fn().mockResolvedValue(undefined);
  const transaction = {
    select: vi
      .fn()
      .mockReturnValueOnce(selectQuery([{ id: 41, number: "7846", status: "draft" }]))
      .mockReturnValueOnce(selectQuery([{ id: 8, materialId: 3, quantity: "2.000", unitPrice: "5.00" }]))
      .mockReturnValueOnce(selectQuery([{ id: 3, stockQuantity: "10.000", averageCost: "5.00" }])),
    update: vi.fn().mockReturnValue(updateQuery()),
    insert: vi.fn().mockReturnValue({ values: movementValues }),
  };
  const database = {
    transaction: vi.fn(callback => callback(transaction)),
    select: vi
      .fn()
      .mockReturnValueOnce(selectQuery([{ id: 41, number: "7846", status: "confirmed" }]))
      .mockReturnValueOnce(selectQuery([])),
  };
  return { database, transaction, movementValues };
}

describe("confirmação transacional de notas fiscais", () => {
  it("confirma a nota, registra uma entrada e atualiza o estoque uma única vez", async () => {
    const { database, transaction, movementValues } = confirmedInvoiceDatabase();

    await expect(updateInvoiceStatus(41, "confirmed", { db: database as never, skipInitialData: true })).resolves.toMatchObject({ id: 41, status: "confirmed" });
    expect(transaction.update).toHaveBeenCalledTimes(3);
    expect(movementValues).toHaveBeenCalledWith(expect.objectContaining({ invoiceId: 41, materialId: 3, type: "entry", quantity: "2.000", balanceAfter: "12.000" }));
  });

  it("bloqueia nova confirmação antes de registrar qualquer movimentação", async () => {
    const movementValues = vi.fn();
    const transaction = { select: vi.fn().mockReturnValue(selectQuery([{ id: 41, status: "confirmed" }])), update: vi.fn(), insert: vi.fn().mockReturnValue({ values: movementValues }) };
    const database = { transaction: vi.fn(callback => callback(transaction)) };

    await expect(confirmInvoice(41, { db: database as never, skipInitialData: true })).rejects.toThrow("já foi confirmada");
    expect(movementValues).not.toHaveBeenCalled();
  });

  it("bloqueia o retorno de uma nota confirmada para conferência", async () => {
    const database = { select: vi.fn().mockReturnValue(selectQuery([{ status: "confirmed" }])) };

    await expect(updateInvoiceStatus(41, "draft", { db: database as never, skipInitialData: true })).rejects.toThrow("entrada já foi registrada");
  });
});
