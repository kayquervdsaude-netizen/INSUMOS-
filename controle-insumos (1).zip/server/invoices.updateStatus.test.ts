import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const mocks = vi.hoisted(() => ({ updateInvoiceStatus: vi.fn(), recordAccessAudit: vi.fn() }));

vi.mock("./db", () => ({ updateInvoiceStatus: mocks.updateInvoiceStatus, recordAccessAudit: mocks.recordAccessAudit }));

import { appRouter } from "./routers";
import { ENV } from "./_core/env";

function createContext(options?: { isOwner?: boolean; role?: "admin" | "user" }): TrpcContext {
  return { user: { id: 4, openId: options?.isOwner === false ? "other-admin" : ENV.ownerOpenId, name: "Administrador", email: "admin@empresa.com", loginMethod: "password", role: options?.role ?? "admin", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }, req: {} as TrpcContext["req"], res: {} as TrpcContext["res"] };
}

describe("invoices.updateStatus", () => {
  beforeEach(() => mocks.updateInvoiceStatus.mockReset());

  it("encaminha a confirmação da nota para a transação segura de estoque", async () => {
    const invoice = { id: 18, status: "confirmed" };
    mocks.updateInvoiceStatus.mockResolvedValue(invoice);

    await expect(appRouter.createCaller(createContext()).invoices.updateStatus({ invoiceId: 18, status: "confirmed" })).resolves.toEqual(invoice);
    expect(mocks.updateInvoiceStatus).toHaveBeenCalledWith(18, "confirmed");
  });

  it("permite que um administrador adicional atualize uma nota", async () => {
    const invoice = { id: 19, status: "draft" };
    mocks.updateInvoiceStatus.mockResolvedValue(invoice);

    await expect(appRouter.createCaller(createContext({ isOwner: false })).invoices.updateStatus({ invoiceId: 19, status: "draft" })).resolves.toEqual(invoice);
    expect(mocks.updateInvoiceStatus).toHaveBeenCalledWith(19, "draft");
  });

  it("rejeita status que não fazem parte do fluxo de conferência", async () => {
    await expect(appRouter.createCaller(createContext()).invoices.updateStatus({ invoiceId: 18, status: "cancelled" as never })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(mocks.updateInvoiceStatus).not.toHaveBeenCalled();
  });
});
