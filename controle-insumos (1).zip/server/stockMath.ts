export function calculateEntryBalance(currentStock: number, currentCost: number, quantity: number, unitPrice: number) {
  const nextStock = currentStock + quantity;
  const nextCost = nextStock > 0 ? (currentStock * currentCost + quantity * unitPrice) / nextStock : unitPrice;
  return { nextStock, nextCost };
}

export function calculateExitBalance(currentStock: number, quantity: number) {
  if (quantity <= 0) throw new Error("A quantidade de saída deve ser maior que zero.");
  if (quantity > currentStock) throw new Error("A quantidade informada é maior que o saldo disponível.");
  return currentStock - quantity;
}
