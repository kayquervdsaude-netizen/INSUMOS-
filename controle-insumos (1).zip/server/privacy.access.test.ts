import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";
import { ENV } from "./_core/env";

const mocks = vi.hoisted(() => ({ createDataSubjectRequest: vi.fn(), listMyDataSubjectRequests: vi.fn(), listDataSubjectRequests: vi.fn(), updateDataSubjectRequest: vi.fn(), listAccessAuditLogs: vi.fn(), recordAccessAudit: vi.fn() }));
vi.mock("./db", () => mocks);

import { appRouter } from "./routers";

function createContext(options: { isOwner?: boolean; role?: "admin" | "user" } = {}): TrpcContext {
  const isOwner = options.isOwner === true;
  return { user: { id: isOwner ? 1 : 6, openId: isOwner ? ENV.ownerOpenId : "collaborator", name: "Conta de teste", email: "teste@empresa.com", loginMethod: "password", role: options.role ?? "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }, req: {} as TrpcContext["req"], res: {} as TrpcContext["res"] };
}

describe("canal de privacidade e LGPD", () => {
  beforeEach(() => Object.values(mocks).forEach(mock => mock.mockReset()));

  it("permite que a conta solicite informações sobre seus próprios dados", async () => {
    const request = { id: 9, requesterUserId: 6, type: "access", status: "pending" };
    mocks.createDataSubjectRequest.mockResolvedValue(request);
    await expect(appRouter.createCaller(createContext()).privacy.createRequest({ type: "access", message: "Quero acessar meus dados." })).resolves.toEqual(request);
    expect(mocks.createDataSubjectRequest).toHaveBeenCalledWith({ requesterUserId: 6, type: "access", message: "Quero acessar meus dados." });
  });

  it("restringe consulta de todas as solicitações e auditoria à conta proprietária", async () => {
    await expect(appRouter.createCaller(createContext()).privacy.requests()).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(appRouter.createCaller(createContext()).privacy.auditLogs()).rejects.toMatchObject({ code: "FORBIDDEN" });
    mocks.listDataSubjectRequests.mockResolvedValue([{ id: 9 }]);
    mocks.listAccessAuditLogs.mockResolvedValue([{ id: 3 }]);
    const owner = appRouter.createCaller(createContext({ isOwner: true, role: "admin" }));
    await expect(owner.privacy.requests()).resolves.toEqual([{ id: 9 }]);
    await expect(owner.privacy.auditLogs()).resolves.toEqual([{ id: 3 }]);
  });

  it("permite somente ao proprietário atualizar o atendimento de uma solicitação", async () => {
    mocks.updateDataSubjectRequest.mockResolvedValue({ id: 9, status: "completed" });
    await expect(appRouter.createCaller(createContext()).privacy.updateRequest({ id: 9, status: "completed" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(appRouter.createCaller(createContext({ isOwner: true, role: "admin" })).privacy.updateRequest({ id: 9, status: "completed" })).resolves.toEqual({ id: 9, status: "completed" });
    expect(mocks.updateDataSubjectRequest).toHaveBeenCalledWith({ id: 9, status: "completed", handledByUserId: 1 });
  });
});
