import { eq } from "drizzle-orm";
import initialData from "../server/initial-data.json";
import { suppliers } from "../drizzle/schema";
import { getDb } from "../server/db";

const db = await getDb();
if (!db) throw new Error("Banco de dados indisponível.");

for (const supplier of initialData.suppliers) {
  const sourceUpdatedAt = supplier.updatedAt ? new Date(`${supplier.updatedAt}Z`) : null;
  await db.update(suppliers).set({ sourceUpdatedAt }).where(eq(suppliers.name, supplier.name));
}

console.log(`Datas atualizadas: ${initialData.suppliers.length}`);
process.exit(0);
