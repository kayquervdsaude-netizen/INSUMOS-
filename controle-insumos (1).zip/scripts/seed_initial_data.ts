import { getDashboardData } from "../server/db";

const dashboard = await getDashboardData();
console.log(JSON.stringify(dashboard.metrics));
