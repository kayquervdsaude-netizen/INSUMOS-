from __future__ import annotations

import json
from datetime import date, datetime
from pathlib import Path

from openpyxl import load_workbook


SOURCE = Path("/home/ubuntu/upload/CONTROLEDECOMPRADEINSUMOS(1).xlsx")
OUTPUT = Path("/home/ubuntu/controle-insumos/workbook_analysis.json")


def normalize(value):
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if value is None:
        return None
    return str(value).strip()


def is_meaningful(row):
    return any(value not in (None, "") for value in row)


def main():
    workbook = load_workbook(SOURCE, data_only=False)
    report = {"source": SOURCE.name, "sheets": []}

    for sheet in workbook.worksheets:
        rows = list(sheet.iter_rows(values_only=True))
        meaningful_rows = [list(map(normalize, row)) for row in rows if is_meaningful(row)]
        report["sheets"].append(
            {
                "title": sheet.title,
                "max_row": sheet.max_row,
                "max_column": sheet.max_column,
                "merged_ranges": [str(rng) for rng in sheet.merged_cells.ranges],
                "preview_rows": meaningful_rows[:40],
            }
        )

    OUTPUT.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(OUTPUT)


if __name__ == "__main__":
    main()
