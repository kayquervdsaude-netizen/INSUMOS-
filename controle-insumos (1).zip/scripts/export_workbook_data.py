from __future__ import annotations

import json
from datetime import date, datetime
from pathlib import Path

from openpyxl import load_workbook


SOURCE = Path("/home/ubuntu/upload/CONTROLEDECOMPRADEINSUMOS(1).xlsx")
OUTPUT = Path("/home/ubuntu/controle-insumos/server/initial-data.json")
SUMMARY = Path("/home/ubuntu/controle-insumos/workbook_summary.json")


def normalize(value):
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return value
    value = str(value).strip()
    return value or None


def text(value):
    value = normalize(value)
    return value if isinstance(value, str) else None


def number(value):
    value = normalize(value)
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        try:
            return float(value.replace(".", "").replace(",", "."))
        except ValueError:
            return None
    return None


def main():
    workbook = load_workbook(SOURCE, data_only=True)

    supplier_sheet = workbook["Fornecedores"]
    product_sheet = workbook["Produtos"]
    general_sheet = workbook["Compras Geral"]
    llt_sheet = workbook["Compras LLT"]
    refrigerated_sheet = workbook["Insumos Refrigerados "]

    suppliers = []
    for row in supplier_sheet.iter_rows(min_row=3, values_only=True):
        if not row[0] or str(row[0]).strip().casefold() == "fornecedor":
            continue
        suppliers.append(
            {
                "name": text(row[0]),
                "email": text(row[1]),
                "phone": text(row[2]),
                "updatedAt": text(row[3]),
                "contact": text(row[4]),
                "category": text(row[5]),
                "leadTime": text(row[6]),
                "notes": text(row[7]),
            }
        )

    materials = []
    for row in product_sheet.iter_rows(min_row=3, values_only=True):
        if not row[0] or str(row[0]).strip().casefold() == "produto":
            continue
        materials.append(
            {
                "name": text(row[0]),
                "category": text(row[1]),
                "unit": text(row[2]) or "Und",
            }
        )

    purchases = []
    for sheet, origin in [(general_sheet, "Compras Geral"), (llt_sheet, "Compras LLT")]:
        for row in sheet.iter_rows(min_row=3, values_only=True):
            if not row[0] or str(row[0]).strip().casefold() == "produto":
                continue
            quantity = number(row[4])
            unit_price = number(row[5])
            total = number(row[6])
            purchases.append(
                {
                    "origin": origin,
                    "materialName": text(row[0]),
                    "unit": text(row[1]) or "Und",
                    "supplierName": text(row[2]),
                    "orderDate": text(row[3]),
                    "quantity": quantity or 0,
                    "unitPrice": unit_price or 0,
                    "totalPrice": total if total is not None else round((quantity or 0) * (unit_price or 0), 2),
                    "invoiceNumber": text(row[7]),
                    "leadTime": text(row[8]),
                    "company": text(row[9]),
                    "purchaseType": text(row[10]) if origin == "Compras Geral" else None,
                    "category": text(row[11]) if origin == "Compras Geral" else None,
                    "notes": text(row[12]) if origin == "Compras Geral" else text(row[10]),
                }
            )

    refrigerated_usage = []
    for row in refrigerated_sheet.iter_rows(min_row=3, values_only=True):
        if not row[0] or str(row[0]).strip().casefold() == "total geral":
            continue
        refrigerated_usage.append(
            {
                "materialName": text(row[0]),
                "totalQuantity": number(row[1]) or 0,
                "totalConsumptionValue": number(row[2]) or 0,
            }
        )

    material_keys = set()
    deduped_materials = []
    for material in materials:
        key = material["name"].casefold()
        if key in material_keys:
            continue
        material_keys.add(key)
        deduped_materials.append(material)

    payload = {
        "source": SOURCE.name,
        "suppliers": suppliers,
        "materials": deduped_materials,
        "purchases": purchases,
        "refrigeratedUsage": refrigerated_usage,
    }
    OUTPUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    SUMMARY.write_text(
        json.dumps(
            {
                "suppliers": len(suppliers),
                "materials_raw": len(materials),
                "materials_deduplicated": len(deduped_materials),
                "purchases": len(purchases),
                "purchases_by_origin": {
                    "Compras Geral": sum(1 for item in purchases if item["origin"] == "Compras Geral"),
                    "Compras LLT": sum(1 for item in purchases if item["origin"] == "Compras LLT"),
                },
                "refrigerated_usage": len(refrigerated_usage),
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    print(OUTPUT)
    print(SUMMARY)


if __name__ == "__main__":
    main()
