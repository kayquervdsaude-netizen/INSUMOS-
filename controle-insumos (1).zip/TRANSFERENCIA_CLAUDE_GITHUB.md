# Transferência para Claude e GitHub

Este pacote contém o código-fonte do **Controle de Compras de Insumos**, incluindo frontend React/Tailwind, servidor Express/tRPC, schema Drizzle, migrações e testes.

## Segurança

Arquivos de ambiente, tokens, credenciais, `node_modules`, artefatos de build, logs e a pasta `.git` não fazem parte do pacote. Configure os valores necessários em um novo ambiente; nunca publique segredos no repositório.

## Abrir no Claude

Envie o arquivo ZIP ao Claude e peça: “Leia `README.md` e `TRANSFERENCIA_CLAUDE_GITHUB.md`, preserve o stack React/Tailwind + Express/tRPC + Drizzle/MySQL e não altere o banco sem revisar e aplicar as migrações.”

## Executar localmente

Use Node.js 22 ou compatível, instale as dependências com `pnpm install`, configure `DATABASE_URL` e os demais valores de ambiente exigidos pelo `README.md`, depois execute `pnpm check` e `pnpm test`. Para desenvolvimento, use `pnpm dev`.

## Versionar no GitHub

Crie um repositório privado vazio no GitHub e, dentro desta pasta, execute:

```bash
git init
git add .
git commit -m "Importa sistema Controle de Compras de Insumos"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
git push -u origin main
```

Se preferir usar o GitHub CLI, autentique-se com `gh auth login`, crie o repositório privado com `gh repo create SEU_USUARIO/SEU_REPOSITORIO --private --source . --remote origin --push` e confirme o endereço antes de publicar.

## Publicação

O projeto já possui uma versão publicada no Manus. Para hospedar fora dele, valide primeiro as variáveis de ambiente, o banco MySQL/TiDB, as migrações Drizzle e o comando de build da plataforma escolhida.

## Versão entregue

A última versão publicada no Manus é `cf0fd062`. Ela inclui status de compras, conferência com atualização idempotente do estoque, SKU, entradas manuais, solicitações, pedidos e testes automatizados.
