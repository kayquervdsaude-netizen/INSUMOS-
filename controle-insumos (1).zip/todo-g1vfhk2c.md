# Project TODO

- [x] Abrir o projeto compartilhado Controle de Compras de Insumos para edição.
- [x] Modelar solicitações de retirada vinculadas ao colaborador, insumo, quantidade e status de aprovação.
- [x] Permitir que colaboradores solicitem a retirada de insumos, como 40 unidades de Caixa 04.
- [x] Criar uma fila administrativa para aprovar ou recusar solicitações pendentes.
- [x] Dar baixa no estoque apenas na aprovação, impedindo saldo negativo e registrando a movimentação.
- [x] Cobrir as regras de solicitação e aprovação com testes automatizados e validar as telas responsivas.
- [x] Adicionar testes automatizados para criação, aprovação, recusa, bloqueio por saldo insuficiente e registro de movimentação.
- [x] Mapear o acesso atual e definir o fluxo seguro de login por e-mail e senha.
- [x] Modelar credenciais protegidas e sessões próprias para usuários internos.
- [x] Criar tela de login e uma interface administrativa para definir ou redefinir senhas.
- [x] Implementar redefinição administrativa de senha para colaboradores já existentes.
- [x] Testar a redefinição administrativa e validar em mobile as telas de login e equipe.
- [x] Validar permissões, proteção de senha, emissão de sessão e responsividade antes da publicação.
- [x] Mapear o fluxo atual de notas fiscais em conferência e suas transições permitidas de status.
- [x] Exibir claramente as notas em conferência, com acesso aos itens e pendências de cada documento.
- [x] Permitir a alteração controlada do status da nota sem duplicar movimentos ou alterar o estoque indevidamente.
- [x] Cobrir as transições de status com testes e validar a interface em desktop e mobile.
- [x] Mapear as movimentações de saída atuais e definir as etapas de pedido, separação e expedição.
- [x] Modelar pedidos de saída com destinatário, observações, itens, quantidades e status operacional.
- [x] Criar uma picking list para separação e um documento imprimível de saída semelhante a uma nota.
- [x] Dar baixa no estoque somente na expedição do pedido, sem permitir saldo negativo ou duplicidade.
- [x] Criar relatórios de pedidos, itens separados e saídas por período e status.
- [x] Validar o comprovante com a renderização de destinatário, itens e estilo de impressão.
- [x] Cobrir as regras e a impressão com testes e validação visual responsiva.
- [x] Integrar solicitações de retirada aprovadas à aba de Pedidos para separação e impressão.
- [x] Avaliar com uma solicitação real a criação do pedido de separação; o teste foi cancelado por saldo insuficiente a pedido do administrador.
- [x] Refinar o layout com cartões mais fluidos e espaçamento inspirado na referência, preservando as cores originais do projeto.
- [x] Revalidar as telas de solicitações e pedidos em desktop e mobile após o ajuste de layout.
- [x] Permitir autoaprovação somente para o administrador proprietário do sistema.
- [x] Manter o bloqueio de autoaprovação para todos os demais colaboradores.
- [x] Finalizar a solicitação autorizada; o teste foi cancelado sem pedido por falta de saldo e decisão do administrador.
- [x] Cancelar a solicitação de teste sem criar pedido nem alterar o estoque.
- [x] Mapear os controles atuais de usuários, criação de pedidos, alteração de status e histórico persistente.
- [x] Criar uma aba administrativa dedicada para gerenciar usuários e seus perfis de acesso.
- [x] Restringir a criação manual e a alteração de status dos pedidos a administradores.
- [x] Preservar todos os pedidos no histórico e registrar as alterações de status com rastreabilidade.
- [x] Confirmar que solicitações aprovadas continuam criando pedidos automaticamente na aba Pedidos.
- [x] Cobrir permissões, status, histórico e responsividade com testes automatizados e validação visual.
- [x] Mapear todas as ações críticas e rotas administrativas do sistema.
- [x] Restringir a conta administradora proprietária como única autorizada a gerenciar usuários e executar operações críticas.
- [x] Ocultar controles de alteração, exclusão, status, estoque, notas e impressão para os demais usuários.
- [x] Cobrir os bloqueios de permissão e validar a interface administrativa em desktop e mobile.
- [x] Permitir a exclusão segura de usuários e convites apenas pelo administrador proprietário, protegendo a conta proprietária e o último administrador.
- [x] Garantir com testes que cada transição de pedido grave o histórico persistente de status.
- [x] Impedir a renderização do documento imprimível para contas que não são proprietárias.
- [x] Corrigir a identificação da conta proprietária para que a aba Usuários permaneça visível no menu lateral.
- [x] Permitir que administradores adicionais editem e atualizem operações, preservando ao proprietário a gestão de usuários e permissões.
- [x] Atualizar a interface para indicar claramente quais contas são proprietária, administradora ou colaboradora.
- [x] Cobrir e validar os novos níveis de permissão antes da publicação.
- [x] Mapear e minimizar a exposição de dados pessoais nas telas e documentos do sistema.
- [x] Adicionar aviso de privacidade, finalidade de uso e canal de solicitação do titular.
- [x] Criar trilha de auditoria para ações administrativas e travas de acesso por perfil.
- [x] Validar os controles de privacidade e acesso antes da publicação.
- [x] Exibir e testar rótulos claros de Proprietária, Administrador e Colaborador para cada conta listada.
- [x] Minimizar dados pessoais em listas e documentos, ocultando e-mails, documentos e contatos quando não forem necessários.
- [x] Definir um canal concreto de solicitação LGPD dentro do sistema.
- [x] Adicionar testes de permissões para administrador adicional e bloqueio de colaborador nas operações críticas.
- [x] Cobrir o registro e a consulta de auditoria com testes automatizados.
- [x] Permitir que administradores adicionais gerenciem colaboradores, sem editar, redefinir senha ou excluir a conta proprietária.
- [x] Atualizar a tela de usuários para permitir a gestão também por administradores adicionais.
- [x] Cobrir a delegação de gestão de colaboradores e as proteções da conta proprietária com testes.
- [x] Validar nos serviços que administradores adicionais não conseguem alterar perfil, senha ou excluir a conta proprietária.
- [x] Permitir edição e exclusão segura de solicitações sem pedido vinculado ou baixa de estoque.
- [x] Permitir edição e exclusão segura de pedidos que ainda não tenham sido expedidos.
- [x] Exibir controles administrativos de edição e exclusão nas telas de solicitações e pedidos.
- [x] Cobrir regras de alteração e exclusão, incluindo bloqueio de histórico e estoque já expedidos.
- [x] Redesenhar o painel com cabeçalho superior, busca e navegação inspirados na referência, preservando a paleta do sistema.
- [x] Adicionar gráficos reais de pedidos, compras e fornecedores ao painel.
- [x] Validar a nova experiência em desktop e celular, incluindo os gráficos.
- [x] Especificar e exibir quais status não expedidos permitem editar ou excluir pedidos, preservando pedidos vinculados a solicitações por cancelamento.
- [x] Cobrir as regras e os controles de pedidos em rascunho, picking, cancelados e originados de solicitações.
- [x] Ocultar a exclusão em pedidos vinculados a solicitações e orientar o cancelamento diretamente na interface.
- [x] Testar os controles de pedido por status: rascunho, picking, cancelado, expedido e origem por solicitação.
- [x] Validar visualmente as ações corretas para pedidos manuais e pedidos originados de solicitações.
- [x] Registrar em teste de interface a ação exibida para pedidos manuais e pedidos originados de solicitações por status.
- [x] Testar a renderização dos botões de gestão administrativa para pedidos manuais e pedidos vinculados por status.
- [x] Redirecionar visitantes sem sessão de qualquer rota privada para a tela de login, preservando a rota de destino após autenticação.
- [x] Cobrir o bloqueio de rotas privadas e validar o redirecionamento no navegador.
- [x] Exibir ações claras de aceitar ou recusar para administradores em solicitações pendentes.
- [x] Testar e validar visualmente a aprovação e a recusa de solicitações na tela administrativa.
- [x] Modelar pedido de entrada manual com fornecedor, data, referência, itens, quantidades e custos.
- [x] Registrar a entrada manual de forma transacional, atualizando estoque, custo médio e movimentações.
- [x] Criar a tela administrativa para lançar e consultar pedidos de entrada manuais.
- [x] Cobrir e validar o fluxo de pedido de entrada manual em desktop e celular.
- [x] Atribuir SKU único e persistente a cada insumo do estoque, com geração para o cadastro existente.
- [x] Exibir SKU nos cadastros de insumos e selecionar itens por SKU no pedido de entrada.
- [x] Inspirar o formulário de entrada manual no cabeçalho e na grade de itens da referência enviada.
- [x] Cobrir em teste as validações e o envio do formulário de entrada manual.
- [x] Cobrir em teste as decisões administrativas de aceitar e recusar solicitações.
- [x] Validar visualmente em sessão autenticada a abertura do formulário de entrada e os controles administrativos de solicitação.
- [x] Adicionar testes funcionais de componente para o formulário de entrada manual e para as decisões de solicitações.
- [x] Consolidar e confirmar as informações mais recentes publicadas no sistema.

- [x] Adicionar status de compras Recebido, Aguardando conferência e Conferido com histórico de alteração.
- [x] Definir o status inicial das compras atuais e impedir duplicidade de entrada no estoque.
- [x] Atualizar automaticamente saldo, custo médio e movimentações ao concluir a conferência da compra.
- [x] Permitir que administradores alterem o status da compra na interface com confirmação e feedback.
- [x] Cobrir transições, permissões, duplicidade e atualização de estoque com testes automatizados.
- [x] Validar a tela de compras em desktop e mobile e publicar a atualização.

- [x] Alinhar compras históricas conferidas com a marca de saldo já considerado no estoque.
- [x] Cobrir especificamente a mutação de status contra colaborador e reconfirmação sem duplicar movimentações.

- [x] Testar explicitamente uma segunda confirmação de compra já aplicada sem criar nova movimentação.

- [x] Confirmar em sessão autenticada os três status de compras visíveis e operáveis em desktop e mobile.
- [x] Salvar checkpoint/publicação específico do fluxo de status de compras.

- [x] Cobrir com teste de componente os três status visíveis e o avanço autenticado até Conferido.
- [x] Consolidar a evidência verificável dos status antes do checkpoint final.

- [x] Exibir na tela de compras uma legenda verificável do fluxo Recebido, Aguardando conferência e Conferido.

- [x] Preparar pacote completo do projeto para transferência ao Claude, excluindo segredos e temporários.
- [x] Criar instruções de importação e versionamento no GitHub.
- [x] Entregar o arquivo compactado e a versão publicada ao usuário.

- [x] Recriar o pacote incluindo arquivos públicos necessários de `client/public/`.
- [x] Validar no ZIP final as pastas essenciais e configurações raiz.

- [x] Entregar ao usuário o ZIP de transferência e a referência da versão publicada.
- [x] Confirmar que o pacote inclui código, arquivos públicos, migrações, testes e instruções.

- [x] Exibir o valor unitário, valor por item e valor total nos pedidos de saída.
- [x] Levar o valor de saída para detalhe, picking/expedição, impressão e relatórios aplicáveis.
- [x] Cobrir o cálculo dos valores e validar a interface em desktop e mobile.

- [x] Exibir no detalhe principal do pedido valor unitário, valor por item e total do pedido.
- [x] Adicionar teste de componente para lista, detalhe e relatório com valores financeiros.
- [x] Registrar evidência autenticada das colunas e totais financeiros em desktop e mobile.

- [x] Confirmar autenticação real nas telas de pedidos e relatórios ou reforçar as asserções de perfil administrador.
