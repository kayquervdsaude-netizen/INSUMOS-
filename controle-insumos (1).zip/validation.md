# Registro de validação

## Dados importados

A carga inicial foi conferida após a remoção de cabeçalhos indevidamente identificados como registros. A base contém 20 fornecedores, 52 insumos, 147 pedidos de compra, 239 itens de pedido e 7 indicadores da aba de insumos refrigerados.

## Fluxos validados

O painel, os cadastros de insumos e fornecedores, a consulta de compras, a tela de notas XML, as movimentações e o resumo de refrigerados foram verificados em desktop e em mobile. As tabelas preservam a leitura por meio de rolagem horizontal em telas estreitas, enquanto filtros, formulários e blocos de indicadores permanecem em coluna única no mobile.

Em tablet e desktop, foram conferidos os filtros por categoria de fornecedor e por empresa/origem de compra, bem como os controles de detalhamento nas duas tabelas. A data original de atualização fornecida na planilha é exibida no cadastro de fornecedores.

Os testes automatizados confirmaram a normalização de insumos, a leitura de XML de NF-e, a correspondência de descrições equivalentes e o cálculo ponderado de saldo e custo médio após uma entrada de estoque.

## Atualização de acessos e baixas

A área de equipe foi verificada com um perfil administrativo ativo, contadores de acessos e o formulário de cadastro de colaboradores. A tela de movimentações apresenta a ação de baixa e mantém o histórico em tabela com rolagem horizontal para telas estreitas. Ambas as áreas foram conferidas em desktop e mobile.

## Identidade institucional

Os logotipos da LLT e da RVD Saúde foram inseridos na navegação e no acesso do sistema. A interface foi atualizada para combinar roxo institucional, azul-claro e superfícies brancas. A leitura de dados, os indicadores de destaque e a navegação foram verificados em desktop e mobile, mantendo contraste adequado.

Os formulários de cadastro de colaborador e de baixa de estoque também foram revisados visualmente em desktop. Os dados reais não foram alterados durante essa validação; as regras de envio e proteção de saldo/perfis permanecem cobertas por testes automatizados.

As validações controladas de envio confirmaram que um e-mail inválido para colaborador e uma quantidade zero para baixa são recusados antes de qualquer alteração na base operacional.
