ALTER TABLE `materials` ADD `sku` varchar(32);--> statement-breakpoint
ALTER TABLE `materials` ADD CONSTRAINT `materials_sku_unique` UNIQUE(`sku`);