CREATE TABLE `purchaseOrderStatusHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`purchaseOrderId` int NOT NULL,
	`previousStatus` enum('received','awaiting_confirmation','confirmed'),
	`nextStatus` enum('received','awaiting_confirmation','confirmed') NOT NULL,
	`changedByUserId` int NOT NULL,
	`changedAt` timestamp NOT NULL DEFAULT (now()),
	`notes` text,
	CONSTRAINT `purchaseOrderStatusHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `purchase_order_status_history_order_index` ON `purchaseOrderStatusHistory` (`purchaseOrderId`);--> statement-breakpoint
CREATE INDEX `purchase_order_status_history_date_index` ON `purchaseOrderStatusHistory` (`changedAt`);