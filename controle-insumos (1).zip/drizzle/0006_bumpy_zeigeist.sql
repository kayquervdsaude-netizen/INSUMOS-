CREATE TABLE `passwordCredentials` (
	`userId` int NOT NULL,
	`passwordHash` varchar(512) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `passwordCredentials_userId` PRIMARY KEY(`userId`)
);
--> statement-breakpoint
CREATE INDEX `password_credentials_updated_index` ON `passwordCredentials` (`updatedAt`);