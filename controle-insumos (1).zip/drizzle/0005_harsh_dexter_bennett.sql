CREATE TABLE `stockRequests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`materialId` int NOT NULL,
	`requestedByUserId` int NOT NULL,
	`quantity` decimal(14,3) NOT NULL,
	`reason` varchar(255) NOT NULL,
	`notes` text,
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`reviewedByUserId` int,
	`reviewedAt` timestamp,
	`reviewNotes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stockRequests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `stock_requests_material_index` ON `stockRequests` (`materialId`);--> statement-breakpoint
CREATE INDEX `stock_requests_requester_index` ON `stockRequests` (`requestedByUserId`);--> statement-breakpoint
CREATE INDEX `stock_requests_status_index` ON `stockRequests` (`status`);