CREATE TABLE `collaboratorInvites` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`email` varchar(320) NOT NULL,
	`role` enum('admin','user') NOT NULL DEFAULT 'user',
	`status` enum('pending','accepted','cancelled') NOT NULL DEFAULT 'pending',
	`invitedByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`acceptedAt` timestamp,
	CONSTRAINT `collaboratorInvites_id` PRIMARY KEY(`id`),
	CONSTRAINT `collaborator_invites_email_unique` UNIQUE(`email`)
);
--> statement-breakpoint
CREATE INDEX `collaborator_invites_status_index` ON `collaboratorInvites` (`status`);