ALTER TABLE `accessAuditLogs` MODIFY COLUMN `role` enum('user','admin','diretoria') NOT NULL;--> statement-breakpoint
ALTER TABLE `collaboratorInvites` MODIFY COLUMN `role` enum('admin','user','diretoria') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin','diretoria') NOT NULL DEFAULT 'user';