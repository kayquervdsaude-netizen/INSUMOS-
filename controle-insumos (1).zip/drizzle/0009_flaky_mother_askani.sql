CREATE TABLE `outboundOrderStatusHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`outboundOrderId` int NOT NULL,
	`previousStatus` enum('draft','picking','dispatched','cancelled'),
	`nextStatus` enum('draft','picking','dispatched','cancelled') NOT NULL,
	`changedByUserId` int,
	`notes` text,
	`changedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `outboundOrderStatusHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `outbound_order_status_history_order_index` ON `outboundOrderStatusHistory` (`outboundOrderId`);--> statement-breakpoint
CREATE INDEX `outbound_order_status_history_date_index` ON `outboundOrderStatusHistory` (`changedAt`);