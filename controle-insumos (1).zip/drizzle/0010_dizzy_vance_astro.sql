CREATE TABLE `accessAuditLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actorUserId` int NOT NULL,
	`action` varchar(128) NOT NULL,
	`role` enum('user','admin') NOT NULL,
	`occurredAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `accessAuditLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `access_audit_logs_actor_index` ON `accessAuditLogs` (`actorUserId`);--> statement-breakpoint
CREATE INDEX `access_audit_logs_date_index` ON `accessAuditLogs` (`occurredAt`);