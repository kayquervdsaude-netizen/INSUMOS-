import {
  decimal,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
    loginMethod: varchar("loginMethod", { length: 64 }),
    role: mysqlEnum("role", ["user", "admin", "diretoria"]).default("user").notNull(),
    sessionVersion: int("sessionVersion").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const accessAuditLogs = mysqlTable(
  "accessAuditLogs",
  {
    id: int("id").autoincrement().primaryKey(),
    actorUserId: int("actorUserId").notNull(),
    action: varchar("action", { length: 128 }).notNull(),
    role: mysqlEnum("role", ["user", "admin", "diretoria"]).notNull(),
    occurredAt: timestamp("occurredAt").defaultNow().notNull(),
  },
  table => [index("access_audit_logs_actor_index").on(table.actorUserId), index("access_audit_logs_date_index").on(table.occurredAt)]
);

export const dataSubjectRequests = mysqlTable(
  "dataSubjectRequests",
  {
    id: int("id").autoincrement().primaryKey(),
    requesterUserId: int("requesterUserId").notNull(),
    type: mysqlEnum("type", ["access", "correction", "deletion", "information"]).notNull(),
    message: text("message"),
    status: mysqlEnum("status", ["pending", "in_review", "completed"]).notNull().default("pending"),
    handledByUserId: int("handledByUserId"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    handledAt: timestamp("handledAt"),
  },
  table => [index("data_subject_requests_requester_index").on(table.requesterUserId), index("data_subject_requests_status_index").on(table.status)]
);

export const passwordCredentials = mysqlTable(
  "passwordCredentials",
  {
    userId: int("userId").primaryKey(),
    passwordHash: varchar("passwordHash", { length: 512 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [index("password_credentials_updated_index").on(table.updatedAt)]
);

export const collaboratorInvites = mysqlTable(
  "collaboratorInvites",
  {
    id: int("id").autoincrement().primaryKey(),
    name: varchar("name", { length: 255 }).notNull(),
    email: varchar("email", { length: 320 }).notNull(),
    role: mysqlEnum("role", ["admin", "user", "diretoria"]).notNull().default("user"),
    status: mysqlEnum("status", ["pending", "accepted", "cancelled"]).notNull().default("pending"),
    invitedByUserId: int("invitedByUserId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    acceptedAt: timestamp("acceptedAt"),
  },
  table => [uniqueIndex("collaborator_invites_email_unique").on(table.email), index("collaborator_invites_status_index").on(table.status)]
);

export const suppliers = mysqlTable(
  "suppliers",
  {
    id: int("id").autoincrement().primaryKey(),
    name: varchar("name", { length: 255 }).notNull(),
    email: text("email"),
    phone: varchar("phone", { length: 255 }),
    contact: varchar("contact", { length: 255 }),
    category: varchar("category", { length: 255 }),
    leadTime: varchar("leadTime", { length: 255 }),
    notes: text("notes"),
    sourceUpdatedAt: timestamp("sourceUpdatedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [uniqueIndex("suppliers_name_unique").on(table.name)]
);

export const materials = mysqlTable(
  "materials",
  {
    id: int("id").autoincrement().primaryKey(),
    sku: varchar("sku", { length: 32 }),
    name: varchar("name", { length: 255 }).notNull(),
    normalizedName: varchar("normalizedName", { length: 255 }).notNull(),
    category: varchar("category", { length: 255 }),
    unit: varchar("unit", { length: 32 }).notNull().default("Und"),
    defaultSupplierId: int("defaultSupplierId"),
    averageCost: decimal("averageCost", { precision: 14, scale: 2 }).notNull().default("0"),
    stockQuantity: decimal("stockQuantity", { precision: 14, scale: 3 }).notNull().default("0"),
    minimumStock: decimal("minimumStock", { precision: 14, scale: 3 }).notNull().default("0"),
    criticalStock: decimal("criticalStock", { precision: 14, scale: 3 }).notNull().default("0"),
    status: mysqlEnum("status", ["active", "inactive"]).notNull().default("active"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    uniqueIndex("materials_normalized_name_unique").on(table.normalizedName),
    uniqueIndex("materials_sku_unique").on(table.sku),
    index("materials_supplier_index").on(table.defaultSupplierId),
  ]
);

export const purchaseOrders = mysqlTable(
  "purchaseOrders",
  {
    id: int("id").autoincrement().primaryKey(),
    source: varchar("source", { length: 64 }).notNull().default("manual"),
    status: mysqlEnum("status", ["received", "awaiting_confirmation", "confirmed"]).notNull().default("confirmed"),
    stockAppliedAt: timestamp("stockAppliedAt"),
    supplierId: int("supplierId"),
    orderDate: timestamp("orderDate"),
    invoiceNumber: varchar("invoiceNumber", { length: 64 }),
    leadTime: varchar("leadTime", { length: 255 }),
    company: varchar("company", { length: 64 }),
    purchaseType: varchar("purchaseType", { length: 64 }),
    category: varchar("category", { length: 255 }),
    notes: text("notes"),
    totalPrice: decimal("totalPrice", { precision: 14, scale: 2 }).notNull().default("0"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("purchase_orders_supplier_index").on(table.supplierId),
    index("purchase_orders_date_index").on(table.orderDate),
    index("purchase_orders_invoice_index").on(table.invoiceNumber),
  ]
);

export const purchaseItems = mysqlTable(
  "purchaseItems",
  {
    id: int("id").autoincrement().primaryKey(),
    purchaseOrderId: int("purchaseOrderId").notNull(),
    materialId: int("materialId"),
    description: varchar("description", { length: 255 }).notNull(),
    unit: varchar("unit", { length: 32 }).notNull().default("Und"),
    quantity: decimal("quantity", { precision: 14, scale: 3 }).notNull().default("0"),
    unitPrice: decimal("unitPrice", { precision: 14, scale: 2 }).notNull().default("0"),
    totalPrice: decimal("totalPrice", { precision: 14, scale: 2 }).notNull().default("0"),
  },
  table => [
    index("purchase_items_order_index").on(table.purchaseOrderId),
    index("purchase_items_material_index").on(table.materialId),
  ]
);

export const purchaseOrderStatusHistory = mysqlTable(
  "purchaseOrderStatusHistory",
  {
    id: int("id").autoincrement().primaryKey(),
    purchaseOrderId: int("purchaseOrderId").notNull(),
    previousStatus: mysqlEnum("previousStatus", ["received", "awaiting_confirmation", "confirmed"]),
    nextStatus: mysqlEnum("nextStatus", ["received", "awaiting_confirmation", "confirmed"]).notNull(),
    changedByUserId: int("changedByUserId").notNull(),
    changedAt: timestamp("changedAt").defaultNow().notNull(),
    notes: text("notes"),
  },
  table => [
    index("purchase_order_status_history_order_index").on(table.purchaseOrderId),
    index("purchase_order_status_history_date_index").on(table.changedAt),
  ]
);

export const invoices = mysqlTable(
  "invoices",
  {
    id: int("id").autoincrement().primaryKey(),
    number: varchar("number", { length: 64 }).notNull(),
    accessKey: varchar("accessKey", { length: 64 }),
    issuerName: varchar("issuerName", { length: 255 }).notNull(),
    issuerDocument: varchar("issuerDocument", { length: 32 }),
    issueDate: timestamp("issueDate"),
    totalAmount: decimal("totalAmount", { precision: 14, scale: 2 }).notNull().default("0"),
    status: mysqlEnum("status", ["draft", "confirmed"]).notNull().default("draft"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    confirmedAt: timestamp("confirmedAt"),
  },
  table => [
    uniqueIndex("invoices_access_key_unique").on(table.accessKey),
    index("invoices_number_index").on(table.number),
    index("invoices_issuer_index").on(table.issuerDocument),
  ]
);

export const invoiceItems = mysqlTable(
  "invoiceItems",
  {
    id: int("id").autoincrement().primaryKey(),
    invoiceId: int("invoiceId").notNull(),
    materialId: int("materialId"),
    sourceCode: varchar("sourceCode", { length: 64 }),
    description: varchar("description", { length: 255 }).notNull(),
    ncm: varchar("ncm", { length: 32 }),
    unit: varchar("unit", { length: 32 }).notNull().default("Und"),
    quantity: decimal("quantity", { precision: 14, scale: 3 }).notNull().default("0"),
    unitPrice: decimal("unitPrice", { precision: 14, scale: 2 }).notNull().default("0"),
    totalPrice: decimal("totalPrice", { precision: 14, scale: 2 }).notNull().default("0"),
    matchStatus: mysqlEnum("matchStatus", ["matched", "unmatched", "confirmed"])
      .notNull()
      .default("unmatched"),
  },
  table => [
    index("invoice_items_invoice_index").on(table.invoiceId),
    index("invoice_items_material_index").on(table.materialId),
  ]
);

export const materialAliases = mysqlTable(
  "materialAliases",
  {
    id: int("id").autoincrement().primaryKey(),
    materialId: int("materialId").notNull(),
    label: varchar("label", { length: 255 }).notNull(),
    normalizedLabel: varchar("normalizedLabel", { length: 255 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    uniqueIndex("material_aliases_normalized_unique").on(table.normalizedLabel),
    index("material_aliases_material_index").on(table.materialId),
  ]
);

export const stockMovements = mysqlTable(
  "stockMovements",
  {
    id: int("id").autoincrement().primaryKey(),
    materialId: int("materialId").notNull(),
    invoiceId: int("invoiceId"),
    outboundOrderId: int("outboundOrderId"),
    type: mysqlEnum("type", ["entry", "exit", "adjustment"]).notNull(),
    quantity: decimal("quantity", { precision: 14, scale: 3 }).notNull(),
    balanceAfter: decimal("balanceAfter", { precision: 14, scale: 3 }).notNull(),
    unitCost: decimal("unitCost", { precision: 14, scale: 2 }),
    reference: varchar("reference", { length: 255 }),
    notes: text("notes"),
    occurredAt: timestamp("occurredAt").defaultNow().notNull(),
  },
  table => [
    index("stock_movements_material_index").on(table.materialId),
    index("stock_movements_invoice_index").on(table.invoiceId),
    index("stock_movements_outbound_order_index").on(table.outboundOrderId),
    index("stock_movements_date_index").on(table.occurredAt),
  ]
);

export const outboundOrders = mysqlTable(
  "outboundOrders",
  {
    id: int("id").autoincrement().primaryKey(),
    code: varchar("code", { length: 64 }).notNull(),
    recipientName: varchar("recipientName", { length: 255 }).notNull(),
    recipientDocument: varchar("recipientDocument", { length: 32 }),
    destination: varchar("destination", { length: 255 }),
    contact: varchar("contact", { length: 255 }),
    notes: text("notes"),
    status: mysqlEnum("status", ["draft", "picking", "dispatched", "cancelled"]).notNull().default("draft"),
    createdByUserId: int("createdByUserId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    pickingStartedAt: timestamp("pickingStartedAt"),
    dispatchedAt: timestamp("dispatchedAt"),
    cancelledAt: timestamp("cancelledAt"),
  },
  table => [
    uniqueIndex("outbound_orders_code_unique").on(table.code),
    index("outbound_orders_status_index").on(table.status),
    index("outbound_orders_created_at_index").on(table.createdAt),
  ]
);

export const outboundOrderItems = mysqlTable(
  "outboundOrderItems",
  {
    id: int("id").autoincrement().primaryKey(),
    outboundOrderId: int("outboundOrderId").notNull(),
    materialId: int("materialId").notNull(),
    unit: varchar("unit", { length: 32 }).notNull().default("Und"),
    requestedQuantity: decimal("requestedQuantity", { precision: 14, scale: 3 }).notNull(),
    pickedQuantity: decimal("pickedQuantity", { precision: 14, scale: 3 }).notNull().default("0"),
    unitCost: decimal("unitCost", { precision: 14, scale: 2 }).notNull().default("0"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    uniqueIndex("outbound_order_items_order_material_unique").on(table.outboundOrderId, table.materialId),
    index("outbound_order_items_order_index").on(table.outboundOrderId),
    index("outbound_order_items_material_index").on(table.materialId),
  ]
);

export const outboundOrderStatusHistory = mysqlTable(
  "outboundOrderStatusHistory",
  {
    id: int("id").autoincrement().primaryKey(),
    outboundOrderId: int("outboundOrderId").notNull(),
    previousStatus: mysqlEnum("previousStatus", ["draft", "picking", "dispatched", "cancelled"]),
    nextStatus: mysqlEnum("nextStatus", ["draft", "picking", "dispatched", "cancelled"]).notNull(),
    changedByUserId: int("changedByUserId"),
    notes: text("notes"),
    changedAt: timestamp("changedAt").defaultNow().notNull(),
  },
  table => [
    index("outbound_order_status_history_order_index").on(table.outboundOrderId),
    index("outbound_order_status_history_date_index").on(table.changedAt),
  ]
);

export const stockRequests = mysqlTable(
  "stockRequests",
  {
    id: int("id").autoincrement().primaryKey(),
    materialId: int("materialId").notNull(),
    requestedByUserId: int("requestedByUserId").notNull(),
    quantity: decimal("quantity", { precision: 14, scale: 3 }).notNull(),
    reason: varchar("reason", { length: 255 }).notNull(),
    notes: text("notes"),
    status: mysqlEnum("status", ["pending", "approved", "rejected"]).notNull().default("pending"),
    reviewedByUserId: int("reviewedByUserId"),
    reviewedAt: timestamp("reviewedAt"),
    reviewNotes: text("reviewNotes"),
    outboundOrderId: int("outboundOrderId"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    index("stock_requests_material_index").on(table.materialId),
    index("stock_requests_requester_index").on(table.requestedByUserId),
    index("stock_requests_status_index").on(table.status),
    uniqueIndex("stock_requests_outbound_order_unique").on(table.outboundOrderId),
  ]
);

export const refrigeratedUsage = mysqlTable(
  "refrigeratedUsage",
  {
    id: int("id").autoincrement().primaryKey(),
    materialId: int("materialId"),
    materialLabel: varchar("materialLabel", { length: 255 }).notNull(),
    totalQuantity: decimal("totalQuantity", { precision: 14, scale: 3 }).notNull().default("0"),
    totalConsumptionValue: decimal("totalConsumptionValue", { precision: 14, scale: 2 }).notNull().default("0"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => [
    uniqueIndex("refrigerated_usage_label_unique").on(table.materialLabel),
    index("refrigerated_usage_material_index").on(table.materialId),
  ]
);

export const stockAudits = mysqlTable(
  "stockAudits",
  {
    id: int("id").autoincrement().primaryKey(),
    code: varchar("code", { length: 64 }).notNull(),
    status: mysqlEnum("status", ["draft", "completed"]).notNull().default("draft"),
    startedByUserId: int("startedByUserId").notNull(),
    completedByUserId: int("completedByUserId"),
    notes: text("notes"),
    startedAt: timestamp("startedAt").defaultNow().notNull(),
    completedAt: timestamp("completedAt"),
  },
  table => [uniqueIndex("stock_audits_code_unique").on(table.code), index("stock_audits_status_index").on(table.status), index("stock_audits_date_index").on(table.startedAt)]
);

export const stockAuditItems = mysqlTable(
  "stockAuditItems",
  {
    id: int("id").autoincrement().primaryKey(),
    auditId: int("auditId").notNull(),
    materialId: int("materialId").notNull(),
    systemQuantity: decimal("systemQuantity", { precision: 14, scale: 3 }).notNull(),
    countedQuantity: decimal("countedQuantity", { precision: 14, scale: 3 }),
    difference: decimal("difference", { precision: 14, scale: 3 }),
    adjustmentAppliedAt: timestamp("adjustmentAppliedAt"),
  },
  table => [uniqueIndex("stock_audit_items_audit_material_unique").on(table.auditId, table.materialId), index("stock_audit_items_audit_index").on(table.auditId), index("stock_audit_items_material_index").on(table.materialId)]
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
