CREATE TABLE `dataSubjectRequests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`requesterUserId` int NOT NULL,
	`type` enum('access','correction','deletion','information') NOT NULL,
	`message` text,
	`status` enum('pending','in_review','completed') NOT NULL DEFAULT 'pending',
	`handledByUserId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`handledAt` timestamp,
	CONSTRAINT `dataSubjectRequests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `data_subject_requests_requester_index` ON `dataSubjectRequests` (`requesterUserId`);--> statement-breakpoint
CREATE INDEX `data_subject_requests_status_index` ON `dataSubjectRequests` (`status`);