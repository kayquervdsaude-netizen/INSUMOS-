ALTER TABLE `stockRequests` ADD `outboundOrderId` int;--> statement-breakpoint
ALTER TABLE `stockRequests` ADD CONSTRAINT `stock_requests_outbound_order_unique` UNIQUE(`outboundOrderId`);