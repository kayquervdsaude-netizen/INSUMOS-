CREATE TABLE `stockAuditItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`auditId` int NOT NULL,
	`materialId` int NOT NULL,
	`systemQuantity` decimal(14,3) NOT NULL,
	`countedQuantity` decimal(14,3),
	`difference` decimal(14,3),
	`adjustmentAppliedAt` timestamp,
	CONSTRAINT `stockAuditItems_id` PRIMARY KEY(`id`),
	CONSTRAINT `stock_audit_items_audit_material_unique` UNIQUE(`auditId`,`materialId`)
);
--> statement-breakpoint
CREATE TABLE `stockAudits` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(64) NOT NULL,
	`status` enum('draft','completed') NOT NULL DEFAULT 'draft',
	`startedByUserId` int NOT NULL,
	`completedByUserId` int,
	`notes` text,
	`startedAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	CONSTRAINT `stockAudits_id` PRIMARY KEY(`id`),
	CONSTRAINT `stock_audits_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE INDEX `stock_audit_items_audit_index` ON `stockAuditItems` (`auditId`);--> statement-breakpoint
CREATE INDEX `stock_audit_items_material_index` ON `stockAuditItems` (`materialId`);--> statement-breakpoint
CREATE INDEX `stock_audits_status_index` ON `stockAudits` (`status`);--> statement-breakpoint
CREATE INDEX `stock_audits_date_index` ON `stockAudits` (`startedAt`);