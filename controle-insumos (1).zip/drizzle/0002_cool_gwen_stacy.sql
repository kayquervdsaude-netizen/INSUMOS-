CREATE TABLE `refrigeratedUsage` (
	`id` int AUTO_INCREMENT NOT NULL,
	`materialId` int,
	`materialLabel` varchar(255) NOT NULL,
	`totalQuantity` decimal(14,3) NOT NULL DEFAULT '0',
	`totalConsumptionValue` decimal(14,2) NOT NULL DEFAULT '0',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `refrigeratedUsage_id` PRIMARY KEY(`id`),
	CONSTRAINT `refrigerated_usage_label_unique` UNIQUE(`materialLabel`)
);
--> statement-breakpoint
CREATE INDEX `refrigerated_usage_material_index` ON `refrigeratedUsage` (`materialId`);