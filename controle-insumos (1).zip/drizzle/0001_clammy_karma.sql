CREATE TABLE `invoiceItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`invoiceId` int NOT NULL,
	`materialId` int,
	`sourceCode` varchar(64),
	`description` varchar(255) NOT NULL,
	`ncm` varchar(32),
	`unit` varchar(32) NOT NULL DEFAULT 'Und',
	`quantity` decimal(14,3) NOT NULL DEFAULT '0',
	`unitPrice` decimal(14,2) NOT NULL DEFAULT '0',
	`totalPrice` decimal(14,2) NOT NULL DEFAULT '0',
	`matchStatus` enum('matched','unmatched','confirmed') NOT NULL DEFAULT 'unmatched',
	CONSTRAINT `invoiceItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `invoices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`number` varchar(64) NOT NULL,
	`accessKey` varchar(64),
	`issuerName` varchar(255) NOT NULL,
	`issuerDocument` varchar(32),
	`issueDate` timestamp,
	`totalAmount` decimal(14,2) NOT NULL DEFAULT '0',
	`status` enum('draft','confirmed') NOT NULL DEFAULT 'draft',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`confirmedAt` timestamp,
	CONSTRAINT `invoices_id` PRIMARY KEY(`id`),
	CONSTRAINT `invoices_access_key_unique` UNIQUE(`accessKey`)
);
--> statement-breakpoint
CREATE TABLE `materialAliases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`materialId` int NOT NULL,
	`label` varchar(255) NOT NULL,
	`normalizedLabel` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `materialAliases_id` PRIMARY KEY(`id`),
	CONSTRAINT `material_aliases_normalized_unique` UNIQUE(`normalizedLabel`)
);
--> statement-breakpoint
CREATE TABLE `materials` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`normalizedName` varchar(255) NOT NULL,
	`category` varchar(255),
	`unit` varchar(32) NOT NULL DEFAULT 'Und',
	`defaultSupplierId` int,
	`averageCost` decimal(14,2) NOT NULL DEFAULT '0',
	`stockQuantity` decimal(14,3) NOT NULL DEFAULT '0',
	`minimumStock` decimal(14,3) NOT NULL DEFAULT '0',
	`status` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `materials_id` PRIMARY KEY(`id`),
	CONSTRAINT `materials_normalized_name_unique` UNIQUE(`normalizedName`)
);
--> statement-breakpoint
CREATE TABLE `purchaseItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`purchaseOrderId` int NOT NULL,
	`materialId` int,
	`description` varchar(255) NOT NULL,
	`unit` varchar(32) NOT NULL DEFAULT 'Und',
	`quantity` decimal(14,3) NOT NULL DEFAULT '0',
	`unitPrice` decimal(14,2) NOT NULL DEFAULT '0',
	`totalPrice` decimal(14,2) NOT NULL DEFAULT '0',
	CONSTRAINT `purchaseItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `purchaseOrders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`source` varchar(64) NOT NULL DEFAULT 'manual',
	`supplierId` int,
	`orderDate` timestamp,
	`invoiceNumber` varchar(64),
	`leadTime` varchar(255),
	`company` varchar(64),
	`purchaseType` varchar(64),
	`category` varchar(255),
	`notes` text,
	`totalPrice` decimal(14,2) NOT NULL DEFAULT '0',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `purchaseOrders_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `stockMovements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`materialId` int NOT NULL,
	`invoiceId` int,
	`type` enum('entry','exit','adjustment') NOT NULL,
	`quantity` decimal(14,3) NOT NULL,
	`balanceAfter` decimal(14,3) NOT NULL,
	`unitCost` decimal(14,2),
	`reference` varchar(255),
	`notes` text,
	`occurredAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stockMovements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `suppliers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`email` text,
	`phone` varchar(255),
	`contact` varchar(255),
	`category` varchar(255),
	`leadTime` varchar(255),
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `suppliers_id` PRIMARY KEY(`id`),
	CONSTRAINT `suppliers_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE INDEX `invoice_items_invoice_index` ON `invoiceItems` (`invoiceId`);--> statement-breakpoint
CREATE INDEX `invoice_items_material_index` ON `invoiceItems` (`materialId`);--> statement-breakpoint
CREATE INDEX `invoices_number_index` ON `invoices` (`number`);--> statement-breakpoint
CREATE INDEX `invoices_issuer_index` ON `invoices` (`issuerDocument`);--> statement-breakpoint
CREATE INDEX `material_aliases_material_index` ON `materialAliases` (`materialId`);--> statement-breakpoint
CREATE INDEX `materials_supplier_index` ON `materials` (`defaultSupplierId`);--> statement-breakpoint
CREATE INDEX `purchase_items_order_index` ON `purchaseItems` (`purchaseOrderId`);--> statement-breakpoint
CREATE INDEX `purchase_items_material_index` ON `purchaseItems` (`materialId`);--> statement-breakpoint
CREATE INDEX `purchase_orders_supplier_index` ON `purchaseOrders` (`supplierId`);--> statement-breakpoint
CREATE INDEX `purchase_orders_date_index` ON `purchaseOrders` (`orderDate`);--> statement-breakpoint
CREATE INDEX `purchase_orders_invoice_index` ON `purchaseOrders` (`invoiceNumber`);--> statement-breakpoint
CREATE INDEX `stock_movements_material_index` ON `stockMovements` (`materialId`);--> statement-breakpoint
CREATE INDEX `stock_movements_invoice_index` ON `stockMovements` (`invoiceId`);--> statement-breakpoint
CREATE INDEX `stock_movements_date_index` ON `stockMovements` (`occurredAt`);