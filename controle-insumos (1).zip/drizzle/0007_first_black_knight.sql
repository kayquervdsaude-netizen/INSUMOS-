CREATE TABLE `outboundOrderItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`outboundOrderId` int NOT NULL,
	`materialId` int NOT NULL,
	`unit` varchar(32) NOT NULL DEFAULT 'Und',
	`requestedQuantity` decimal(14,3) NOT NULL,
	`pickedQuantity` decimal(14,3) NOT NULL DEFAULT '0',
	`unitCost` decimal(14,2) NOT NULL DEFAULT '0',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `outboundOrderItems_id` PRIMARY KEY(`id`),
	CONSTRAINT `outbound_order_items_order_material_unique` UNIQUE(`outboundOrderId`,`materialId`)
);
--> statement-breakpoint
CREATE TABLE `outboundOrders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(64) NOT NULL,
	`recipientName` varchar(255) NOT NULL,
	`recipientDocument` varchar(32),
	`destination` varchar(255),
	`contact` varchar(255),
	`notes` text,
	`status` enum('draft','picking','dispatched','cancelled') NOT NULL DEFAULT 'draft',
	`createdByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`pickingStartedAt` timestamp,
	`dispatchedAt` timestamp,
	`cancelledAt` timestamp,
	CONSTRAINT `outboundOrders_id` PRIMARY KEY(`id`),
	CONSTRAINT `outbound_orders_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
ALTER TABLE `stockMovements` ADD `outboundOrderId` int;--> statement-breakpoint
CREATE INDEX `outbound_order_items_order_index` ON `outboundOrderItems` (`outboundOrderId`);--> statement-breakpoint
CREATE INDEX `outbound_order_items_material_index` ON `outboundOrderItems` (`materialId`);--> statement-breakpoint
CREATE INDEX `outbound_orders_status_index` ON `outboundOrders` (`status`);--> statement-breakpoint
CREATE INDEX `outbound_orders_created_at_index` ON `outboundOrders` (`createdAt`);--> statement-breakpoint
CREATE INDEX `stock_movements_outbound_order_index` ON `stockMovements` (`outboundOrderId`);